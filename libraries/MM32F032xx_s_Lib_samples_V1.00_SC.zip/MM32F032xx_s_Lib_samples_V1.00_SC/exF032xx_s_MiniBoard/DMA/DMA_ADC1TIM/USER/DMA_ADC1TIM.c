////////////////////////////////////////////////////////////////////////////////
/// @file    DMA_ADC1TIM.c
/// @author  AE TEAM
/// @version v1.0.0
/// @date    2019-09-20
/// @brief   THIS FILE PROVIDES ALL THE SYSTEM FUNCTIONS.
////////////////////////////////////////////////////////////////////////////////
/// @attention
///
/// THE EXISTING FIRMWARE IS ONLY FOR REFERENCE, WHICH IS DESIGNED TO PROVIDE
/// CUSTOMERS WITH CODING INFORMATION ABOUT THEIR PRODUCTS SO THEY CAN SAVE
/// TIME. THEREFORE, MINDMOTION SHALL NOT BE LIABLE FOR ANY DIRECT, INDIRECT OR
/// CONSEQUENTIAL DAMAGES ABOUT ANY CLAIMS ARISING OUT OF THE CONTENT OF SUCH
/// HARDWARE AND/OR THE USE OF THE CODING INFORMATION CONTAINED HEREIN IN
/// CONNECTION WITH PRODUCTS MADE BY CUSTOMERS.
///
/// <H2><CENTER>&COPY; COPYRIGHT 2018-2019 MINDMOTION </CENTER></H2>
////////////////////////////////////////////////////////////////////////////////

// Define to prevent recursive inclusion  --------------------------------------
#define _DMA_ADC1TIM_C_

// Files includes  -------------------------------------------------------------

#include "DMA_ADC1TIM.h"


////////////////////////////////////////////////////////////////////////////////
/// @addtogroup MM32_Example_Layer
/// @{

////////////////////////////////////////////////////////////////////////////////
/// @addtogroup MM32_RESOURCE
/// @{

////////////////////////////////////////////////////////////////////////////////
/// @addtogroup MM32_Exported_Constants
/// @{


/// @}

////////////////////////////////////////////////////////////////////////////////
/// @brief  This function is main entrance.
/// @param  None.
/// @retval  0.
////////////////////////////////////////////////////////////////////////////////
int main(void)
{
    SetSystemClock(emSYSTICK_On, NULL);

    LED_Init();
    DMA_Config();
    TIM_Config();
    ADC_Config();
    while(1)
    {
        LED1_TOGGLE();
        LED2_TOGGLE();
        LED3_TOGGLE();
        LED4_TOGGLE();
        delay_ms(300);//running
    }
    //return 0;
}
u32 temp = 1000;
////////////////////////////////////////////////////////////////////////////////
/// @brief  Configures DMA1 channel3 to transfer data from
///         ADC1_DR_ADDRESS to TIM3_CCR1_ADDRESS
/// @param  None.
/// @retval None.
////////////////////////////////////////////////////////////////////////////////
//#define ADC1_DR_ADDRESS     0x40012440
//#define TIM3_CCR1_ADDRESS   ADC1-> 0x40000434
void DMA_Config(void)
{
    DMA_InitTypeDef           DMA_InitStructure;

    /* Enable DMA1 clock */
    RCC_AHBPeriphClockCmd(RCC_AHBPeriph_DMA1, ENABLE);

    DMA_DeInit(DMA1_Channel3);
    DMA_InitStructure.PeripheralBaseAddr = (uint32_t)(&temp);//(&(ADC1->DR));//_CCR1_ADDRESS;
    DMA_InitStructure.MemoryBaseAddr = (uint32_t)(&(TIM3->CCR1));
    DMA_InitStructure.DIR = DMA_DIR_PeripheralDST;
    DMA_InitStructure.BufferSize = 1;
    DMA_InitStructure.PeripheralInc = DMA_PeripheralInc_Disable;
    DMA_InitStructure.MemoryInc = DMA_MemoryInc_Disable;
    DMA_InitStructure.PeripheralDataSize = DMA_PeripheralDataSize_HalfWord;
    DMA_InitStructure.MemoryDataSize = DMA_MemoryDataSize_HalfWord;
    DMA_InitStructure.Mode = DMA_Mode_Circular;
    DMA_InitStructure.Priority = DMA_Priority_High;
    DMA_InitStructure.M2M = DMA_M2M_Disable;
    DMA_Init(DMA1_Channel3, &DMA_InitStructure);

    /* Enable DMA1 Channel3 */
    DMA_Cmd(DMA1_Channel3, ENABLE);
}
////////////////////////////////////////////////////////////////////////////////
/// @brief  DMA1 Channel 1 IRQ Handler
/// @param  None.
/// @retval None.
////////////////////////////////////////////////////////////////////////////////
void DMA1_Channel1_IRQHandler(void)
{
    if(DMA_GetITStatus(DMA1_IT_TC1))
    {
        DMA_ClearITPendingBit(DMA1_IT_TC1);
        dma1Flag = 0x1;
    }
}

////////////////////////////////////////////////////////////////////////////////
/// @brief  DMA1 Channel 2 and 3 IRQ Handler
/// @param  None.
/// @retval None.
////////////////////////////////////////////////////////////////////////////////
void DMA1_Channel2_3_IRQHandler(void)
{
    if(DMA_GetITStatus(DMA1_IT_TC2))
    {
        DMA_ClearITPendingBit(DMA1_IT_TC2);
        dma2Flag = 0x1;
    }

}

////////////////////////////////////////////////////////////////////////////////
/// @brief  Check DMA status
/// @param  DMA_FLAG  input check bits.
/// @retval None.
////////////////////////////////////////////////////////////////////////////////
void DMAcheckStatus(uint32_t DMA_FLAG)
{
    while(1)
    {
        if(DMA_GetFlagStatus(DMA_FLAG))
        {
            DMA_ClearFlag(DMA_FLAG);
            break;
        }
    }
}

////////////////////////////////////////////////////////////////////////////////
/// @brief  DMA Channel Disable
/// @param  DMAy_Channelx Channel number.
/// @retval None.
////////////////////////////////////////////////////////////////////////////////
void DMAdisable(DMA_Channel_TypeDef* DMAy_Channelx)
{
    DMA_Cmd(DMAy_Channelx, DISABLE);
}

typedef enum
{
    ADCch0                 = ADC_Channel_0,
    ADCch1                 = ADC_Channel_1,
    ADCch2                 = ADC_Channel_2,
    ADCch3                 = ADC_Channel_3,
    ADCch4                 = ADC_Channel_4,
    ADCch5                 = ADC_Channel_5,
    ADCch6                 = ADC_Channel_6,
    ADCch7                 = ADC_Channel_7,
    ADCch8                 = ADC_Channel_8,
    ADCch9                 = ADC_Channel_9,
    ADCchTemp              = ADC_Channel_TempSensor,
    ADCchVref              = ADC_Channel_VoltReference,
} ADCch;

////////////////////////////////////////////////////////////////////////////////
/// @brief  Initialization configuration CLOCK .
/// @note   None.
/// @param  ADC_Channel_x :ADC1 channel.
/// @retval None.
////////////////////////////////////////////////////////////////////////////////
void GPIO_Config_AIN(GPIO_TypeDef* GPIOx, u16 GPIO_Pin_n)
{
    GPIO_InitTypeDef GPIO_InitStructure;
    if(GPIOx == GPIOA)
    {
        RCC_AHBPeriphClockCmd(RCC_AHBPeriph_GPIOA, ENABLE);
    }
    if(GPIOx == GPIOB)
    {
        RCC_AHBPeriphClockCmd(RCC_AHBPeriph_GPIOB, ENABLE);
    }
    if(GPIOx == GPIOC)
    {
        RCC_AHBPeriphClockCmd(RCC_AHBPeriph_GPIOC, ENABLE);
    }
    if(GPIOx == GPIOD)
    {
        RCC_AHBPeriphClockCmd(RCC_AHBPeriph_GPIOD, ENABLE);
    }
    GPIO_InitStructure.GPIO_Pin  =  GPIO_Pin_n;
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AIN;
    GPIO_Init(GPIOx, &GPIO_InitStructure);
}

////////////////////////////////////////////////////////////////////////////////
/// @brief  Initialization configuration ADC1 .
/// @note   None.
/// @param  ADC_Channel_x :ADC1 channel.
/// @retval None.
////////////////////////////////////////////////////////////////////////////////
void ADCSingleChannelInit(ADCch ADC_Channel_x)
{
    ADC_InitTypeDef  ADC_InitStructure;
    ADC_StructInit(&ADC_InitStructure);

    //Initialize PA1 to analog input mode
    RCC_APB2PeriphClockCmd(RCC_APB2Periph_ADC1, ENABLE);

    ADC_InitStructure.ADC_Resolution = ADC_Resolution_12b;
    //ADC prescale factor
    ADC_InitStructure.ADC_PRESCARE = ADC_PCLK2_PRESCARE_16;
    //Set ADC mode to continuous conversion mode
    ADC_InitStructure.ADC_Mode = ADC_CR_CONTINUE;
    //AD data right-justified
    ADC_InitStructure.ADC_DataAlign = ADC_DataAlign_Right;
    ADC_InitStructure.ADC_ExternalTrigConv = ADC_ExternalTrigConv_T1_CC1;
    ADC_Init(ADC1, &ADC_InitStructure);

    //Block all channels
    ADC_RegularChannelConfig(ADC1, ADC_Channel_x, 0, ADC_Samctl_239_5);


    if((ADC_Channel_x == ADCchTemp) || (ADC_Channel_x == ADCchVref))
    {
        //Enable internal temperature & Vref sensor
        ADC_TempSensorVrefintCmd(ENABLE);
    }

    ADC_DMACmd(ADC1, ENABLE);
    ADC_Cmd(ADC1, ENABLE);
}

////////////////////////////////////////////////////////////////////////////////
/// @brief  Configures the ADC1 channel1 in continuous mode.
/// @note   This function always run any time.
/// @param  None.
/// @retval None.
////////////////////////////////////////////////////////////////////////////////
void ADCConfig(ADCch ADC_Channel)
{
    if( ADCch0 == ADC_Channel )
    {
        GPIO_Config_AIN(GPIOA, GPIO_Pin_0);
        ADCSingleChannelInit(ADCch0);
    }
    else if( ADCch1 == ADC_Channel )
    {
        GPIO_Config_AIN(GPIOA, GPIO_Pin_1);
    }
    else if( ADCch2 == ADC_Channel )
    {
        GPIO_Config_AIN(GPIOA, GPIO_Pin_2);
    }
    else if( ADCch3 == ADC_Channel )
    {
        GPIO_Config_AIN(GPIOA, GPIO_Pin_3);
    }
    else if( ADCch4 == ADC_Channel )
    {
        GPIO_Config_AIN(GPIOA, GPIO_Pin_4);
    }
    else if( ADCch5 == ADC_Channel )
    {
        GPIO_Config_AIN(GPIOA, GPIO_Pin_5);
    }
    else if( ADCch6 == ADC_Channel )
    {
        GPIO_Config_AIN(GPIOA, GPIO_Pin_6);
    }
    else if( ADCch7 == ADC_Channel )
    {
        GPIO_Config_AIN(GPIOA, GPIO_Pin_7);
    }
    else if( ADCch8 == ADC_Channel )
    {
        GPIO_Config_AIN(GPIOB, GPIO_Pin_0);
    }
    else if( ADCch9 == ADC_Channel )
    {
        GPIO_Config_AIN(GPIOB, GPIO_Pin_1);
    }
    else
    {
    }
    ADCSingleChannelInit(ADC_Channel);
}

////////////////////////////////////////////////////////////////////////////////
/// @brief  Configures the ADC1 channel1 in continuous mode.
/// @note   This function always run any time.
/// @param  None.
/// @retval None.
////////////////////////////////////////////////////////////////////////////////
void ADC_Config(void)
{
    ADCConfig(ADCch1);
}

////////////////////////////////////////////////////////////////////////////////
/// @brief  Configures the Time3 channel1 in continuous mode.
/// @note   This function always run any time.
/// @param  None.
/// @retval None.
////////////////////////////////////////////////////////////////////////////////
void TIM3CH1PA6_Init(void)
{
    GPIO_InitTypeDef  GPIO_InitStructure;

    GPIO_Clock_Set(GPIOA, ENABLE);

    GPIO_InitStructure.GPIO_Pin  =  GPIO_Pin_6;
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP;
    GPIO_Init(GPIOA, &GPIO_InitStructure);
    GPIO_PinAFConfig(GPIOA, GPIO_PinSource6, GPIO_AF_1);
}

////////////////////////////////////////////////////////////////////////////////
/// @brief  Configures the TIM3 channel1 in PWM mode.
/// @note   None.
/// @param  None.
/// @retval None.
////////////////////////////////////////////////////////////////////////////////
void TIM_Config(void)
{
    TIM_TimeBaseInitTypeDef   TIM_TimeBaseStructure;
    TIM_OCInitTypeDef         TIM_OCInitStructure;

    TIM3CH1PA6_Init();

    // Enable TIM3 clock
    RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM3, ENABLE);


    TIM_TimeBaseStructInit(&TIM_TimeBaseStructure);
    TIM_TimeBaseStructure.TIM_Period = 0xFF0;
    TIM_TimeBaseStructure.TIM_Prescaler = 0x0;
    TIM_TimeBaseStructure.TIM_ClockDivision = TIM_CKD_DIV1;
    TIM_TimeBaseStructure.TIM_CounterMode = TIM_CounterMode_Up;
    TIM_TimeBaseInit(TIM3, &TIM_TimeBaseStructure);

    // Channel1 Configuration in PWM mode
    TIM_OCInitStructure.TIM_OCMode = TIM_OCMode_PWM1;
    TIM_OCInitStructure.TIM_OutputState = TIM_OutputState_Enable;
    TIM_OCInitStructure.TIM_Pulse = 0xf0;
    TIM_OCInitStructure.TIM_OCPolarity = TIM_OCPolarity_High;
    TIM_OC1Init(TIM3, &TIM_OCInitStructure);


    TIM_DMACmd(TIM3, TIM_DMA_Update, ENABLE);

    TIM_Cmd(TIM3, ENABLE);
}

////////////////////////////////////////////////////////////////////////////////
/// @brief  Set GPIO port RCC clock
/// @note   It must be careful of the Chip Version.
/// @param  GPIOx GPIO port.
/// @param  NewState ENABLE and DISABLE.
/// @retval None.
////////////////////////////////////////////////////////////////////////////////
void GPIO_Clock_Set(GPIO_TypeDef* GPIOx, FunctionalState NewState)
{
    if(GPIOx == GPIOA)
    {
        RCC_AHBPeriphClockCmd(RCC_AHBPeriph_GPIOA, NewState);
    }
    if(GPIOx == GPIOB)
    {
        RCC_AHBPeriphClockCmd(RCC_AHBPeriph_GPIOB, NewState);
    }
    if(GPIOx == GPIOC)
    {
        RCC_AHBPeriphClockCmd(RCC_AHBPeriph_GPIOC, NewState);
    }
    if(GPIOx == GPIOD)
    {
        RCC_AHBPeriphClockCmd(RCC_AHBPeriph_GPIOD, NewState);
    }
}

////////////////////////////////////////////////////////////////////////////////
/// @brief  initialize LED GPIO pin
/// @note   if use jtag/swd interface GPIO PIN as LED, need to be careful,
///         can not debug or program.
/// @param  None.
/// @retval None.
////////////////////////////////////////////////////////////////////////////////
void LED_Init(void)
{
    GPIO_InitTypeDef  GPIO_InitStructure;

    GPIO_Clock_Set(GPIOA, ENABLE);
    GPIO_Clock_Set(GPIOB, ENABLE);
    GPIO_InitStructure.GPIO_Pin  =  GPIO_Pin_15;
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
    GPIO_Init(GPIOA, &GPIO_InitStructure);

    GPIO_InitStructure.GPIO_Pin  = GPIO_Pin_3 | GPIO_Pin_4 | GPIO_Pin_5;
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
    GPIO_Init(GPIOB, &GPIO_InitStructure);

    LED1_ON();
    LED2_ON();
    LED3_ON();
    LED4_ON();
}

////////////////////////////////////////////////////////////////////////////////
/// @brief  This function is called back by SysTick Handler
///         call series function to run systick cycle running
///         for example , delay, led blink, key in scan , etc.
/// @note   This function always run after power on.
/// @param  None.
/// @retval None.
////////////////////////////////////////////////////////////////////////////////
void SysTick_Handler_CALL(void)
{
    TimingDelay_Decrement();
}

////////////////////////////////////////////////////////////////////////////////
/// @brief  This function make delay count decrement as one systick
///         for example , delay (1ms)
/// @note   when decrement to zero�� it always 0.
/// @param  None.
/// @retval None.
////////////////////////////////////////////////////////////////////////////////
void TimingDelay_Decrement(void)
{
    if (TimingDelay > 0x00)
    {
        TimingDelay--;
    }
}

////////////////////////////////////////////////////////////////////////////////
/// @brief  delay nTime ms
/// @note   get x times.
/// @param  nTime  nTime ms.
/// @retval None.
////////////////////////////////////////////////////////////////////////////////
void delay_ms(__IO uint32_t nTime)
{
    TimingDelay = nTime;

    while(1)
    {
        nTime = TimingDelay;
        if(nTime == 0)
        {
            break;
        }
    }
}



/// @}

/// @}

/// @}
