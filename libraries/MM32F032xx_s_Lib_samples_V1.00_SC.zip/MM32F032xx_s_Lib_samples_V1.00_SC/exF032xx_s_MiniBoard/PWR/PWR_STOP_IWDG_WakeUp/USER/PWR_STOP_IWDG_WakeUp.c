////////////////////////////////////////////////////////////////////////////////
/// @file    PWR_STOP_IWDG_WakeUp.c
/// @author  AE TEAM
/// @version v1.0.0
/// @date    2019-09-20
/// @brief   Wake up(PA0) from standby mode using external interrupts.
////////////////////////////////////////////////////////////////////////////////
/// @attention
///
/// THE EXISTING FIRMWARE IS ONLY FOR REFERENCE, WHICH IS DESIGNED TO PROVIDE
/// CUSTOMERS WITH CODING INFORMATION ABOUT THEIR PRODUCTS SO THEY CAN SAVE
/// TIME. THEREFORE, MINDMOTION SHALL NOT BE LIABLE FOR ANY DIRECT, INDIRECT OR
/// CONSEQUENTIAL DAMAGES ABOUT ANY CLAIMS ARISING OUT OF THE CONTENT OF SUCH
/// HARDWARE AND/OR THE USE OF THE CODING INFORMATION CONTAINED HEREIN IN
/// CONNECTION WITH PRODUCTS MADE BY CUSTOMERS.
///
/// <H2><CENTER>&COPY; COPYRIGHT 2019 MINDMOTION </CENTER></H2>
////////////////////////////////////////////////////////////////////////////////
#include "PWR_STOP_IWDG_WakeUp.h"
#include "system_mm32.h"


char printBuf[100];


void CC103_RCC_AdjustHSICalibrationValue(unsigned char ucValue)
{
    RCC->CR = (RCC->CR & 0xFFFF00ff)| 0xf8 | (ucValue << 8);
}

int iwdg_flag = 0;


////////////////////////////////////////////////////////////////////////////////
// @brief  delay nTime ms
// @note   get x times.
/// @param  nTime  nTime ms.
/// @retval None.
////////////////////////////////////////////////////////////////////////////////
void delay_ms(__IO uint32_t nTime)
{   
    uint32_t  TimingDelay;
    TimingDelay =  nTimeOutCnt+nTime;
   
    while(1)
    { 
      if(TimingDelay==nTimeOutCnt)
      { 
        break;
      }
    
    }
}

////////////////////////////////////////////////////////////////////////////////
/// @brief  This function is main entrance.
/// @note   None.
/// @param  None.
/// @retval None.
////////////////////////////////////////////////////////////////////////////////
int main(void)
{
    int i,j;
    
    SetSystemClock(emSYSTICK_On, NULL);
    delay_ms(100);
    RCC_ConfigInit();
    GPIO_ConfigInit();

    Wwdg_irq_ON();
    Write_Iwdg_ON(IWDG_Prescaler_16,0xff);

    i = 100;
    while(i--);

    PWR_EnterSTOPMode(0, PWR_STOPEntry_WFI);

    while(1)
    {
        GPIOA->ODR ^= 1<<10;
        j = 30;
        while(j--);
        delay_ms(2);
      
    }
}



////////////////////////////////////////////////////////////////////////////////
/// @brief  Independent watchdog interrupt response function.
/// @note   None.
/// @param  None.
/// @retval None.
////////////////////////////////////////////////////////////////////////////////
void Wwdg_irq_ON(void)
{
    NVIC_InitTypeDef NVIC_InitStructure;
    EXTI_InitTypeDef EXTI_InitStructure;

    EXTI_DeInit();    
    EXTI_InitStructure.EXTI_Line = EXTI_Line24 ;		 
    EXTI_InitStructure.EXTI_Mode = EXTI_Mode_Interrupt ;  
    EXTI_InitStructure.EXTI_Trigger =   EXTI_Trigger_Rising_Falling  ;	
    EXTI_InitStructure.EXTI_LineCmd = ENABLE;		   
    EXTI_Init(&EXTI_InitStructure);				   
    EXTI_ClearITPendingBit(EXTI_Line24);

    NVIC_InitStructure.NVIC_IRQChannel = WWDG_IRQn;
    NVIC_InitStructure.NVIC_IRQChannelPriority = 0;
    NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
    NVIC_Init(&NVIC_InitStructure);

}

////////////////////////////////////////////////////////////////////////////////
/// @brief  Independent watchdog interrupt response function.
/// @note   None.
/// @param  None.
/// @retval None.
////////////////////////////////////////////////////////////////////////////////
void Write_Iwdg_ON(unsigned short int IWDG_Prescaler,unsigned short int Reload)
{
    /*�����ڲ�����ʱ��,�ȴ�ʱ�Ӿ���*/
    RCC_LSICmd(ENABLE);
    while(RCC_GetFlagStatus(RCC_FLAG_LSIRDY)==RESET);

    /*����ʱ��Ԥ��Ƶ*/
    PVU_CheckStatus();
    IWDG_WriteAccessCmd(0x5555);
    IWDG_SetPrescaler(IWDG_Prescaler);

    /*�������ؼĴ���ֵ*/
    RVU_CheckStatus();
    IWDG_WriteAccessCmd(0x5555);
    IWDG_SetReload(Reload&0xfff);

    IVU_CheckStatus();
    IWDG_WriteAccessCmd(0x5555);
    IWDG->IGEN = 0x20;

    /*װ�ز�ʹ�ܼ�����*/
    IWDG_ReloadCounter();
    IWDG_WriteAccessCmd(0x5555);
    IWDG->CR |= 1;
    IWDG_Enable();
}

void IVU_CheckStatus(void)
{
    while(1)
    {
        /*������ر�־״̬*/
        if(IWDG_GetFlagStatus(IWDG_FLAG_PVU)==RESET)
        {
            break;
        }
    }
}

void WWDG_IRQHandler(void)
{
    int i;
    Write_Iwdg_RL();


    IWDG->CR |= 2;

    IWDG_ReloadCounter();
    GPIOA->ODR ^= 0x1<<4;
    GPIOA->ODR ^= 0x1<<4;
    GPIOA->ODR ^= 0x1<<4;
    GPIOA->ODR ^= 0x1<<4;

    i = 1000;
    while(i--);
    EXTI_ClearFlag(EXTI_Line24);

}

void Write_Iwdg_RL(void)
{
    IWDG_ReloadCounter();
}



/////////////////////////////////////////////////////////////////////////////////////////////////////////
/*
eg.
RCC_ConfigInit();
*/
/////////////////////////////////////////////////////////////////////////////////////////////////////////
void RCC_ConfigInit(void)
{
    RCC_AHBPeriphClockCmd(RCC_AHBPeriph_GPIOA, ENABLE);
    RCC_APB1PeriphClockCmd( RCC_APB1Periph_PWR|RCC_APB1Periph_WWDG, ENABLE );
}
////////////////////////////////////////////////////////////////////////////////
/// @brief  GPIO ConfigInit.
/// @note   None.
/// @param  None.
/// @retval None.
////////////////////////////////////////////////////////////////////////////////
void GPIO_ConfigInit(void)
{
    GPIO_InitTypeDef GPIO_InitStructure;

    GPIO_InitStructure.GPIO_Pin  =  GPIO_Pin_9;
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IPU;
    GPIO_Init(GPIOA, &GPIO_InitStructure);

    GPIO_InitStructure.GPIO_Pin  =  GPIO_Pin_10|GPIO_Pin_4|GPIO_Pin_5;
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
    GPIO_Init(GPIOA, &GPIO_InitStructure);

}


/// @}

/// @}

/// @}
