////////////////////////////////////////////////////////////////////////////////
/// @file    PWR_PVD.c
/// @author  AE TEAM
/// @version v1.0.0
/// @date    2019-09-20
/// @brief   The LED lamp flickers rapidly when the VDD terminal voltage
///          is less than 3.9V.
////////////////////////////////////////////////////////////////////////////////
/// @attention
///
/// THE EXISTING FIRMWARE IS ONLY FOR REFERENCE, WHICH IS DESIGNED TO PROVIDE
/// CUSTOMERS WITH CODING INFORMATION ABOUT THEIR PRODUCTS SO THEY CAN SAVE
/// TIME. THEREFORE, MINDMOTION SHALL NOT BE LIABLE FOR ANY DIRECT, INDIRECT OR
/// CONSEQUENTIAL DAMAGES ABOUT ANY CLAIMS ARISING OUT OF THE CONTENT OF SUCH
/// HARDWARE AND/OR THE USE OF THE CODING INFORMATION CONTAINED HEREIN IN
/// CONNECTION WITH PRODUCTS MADE BY CUSTOMERS.
///
/// <H2><CENTER>&COPY; COPYRIGHT 2018-2019 MINDMOTION </CENTER></H2>
////////////////////////////////////////////////////////////////////////////////
#include "PWR_PVD.h"


u8 lowpowerflag = 0;

////////////////////////////////////////////////////////////////////////////////
/// @brief  This function is main entrance.
/// @note   Adjust mcu voltage generate PVD flag
/// @param  None.
/// @retval None.
////////////////////////////////////////////////////////////////////////////////
int main(void)
{
    u16 i;
    u32 dly;
    deleyNop(10000);

    LED_Init();

    for(i = 0; i < 10; i++)
    {
        LED2_TOGGLE();
        deleyNop(3000);
    }
    RCC_APB1PeriphClockCmd(RCC_APB1Periph_PWR, ENABLE);
    // Configure EXTI Line to generate an interrupt on falling edge
    RCC_AHBPeriphClockCmd(RCC_AHBPeriph_GPIOA, ENABLE);




    EXTI_Configuration();

    // NVIC configuration
    NVIC_Configuration();

    // Configure the PVD Level to 1.8 ~ 4.8V
//    PWR_PVDLevelConfig(PWR_CR_PLS_1V8);
//    PWR_PVDLevelConfig(PWR_CR_PLS_2V1);
//    PWR_PVDLevelConfig(PWR_CR_PLS_2V4);
//    PWR_PVDLevelConfig(PWR_CR_PLS_2V7);
//    PWR_PVDLevelConfig(PWR_CR_PLS_3V0);
//    PWR_PVDLevelConfig(PWR_CR_PLS_3V3);
//    PWR_PVDLevelConfig(PWR_CR_PLS_3V6);
    PWR_PVDLevelConfig(PWR_CR_PLS_3V9);
//    PWR_PVDLevelConfig(PWR_CR_PLS_4V2);
//    PWR_PVDLevelConfig(PWR_CR_PLS_4V5);
//    PWR_PVDLevelConfig(PWR_CR_PLS_4V8);
    /* Enable the PVD Output */
    PWR_PVDCmd(ENABLE);

    dly = 10000;
    while(1)
    {
        if(lowpowerflag == 1)
        {
            //fast Frequence toggle LED
            dly = 300;
        }
        LED2_TOGGLE();
        deleyNop(dly);
    }
}

////////////////////////////////////////////////////////////////////////////////
/// @brief  PVD IRQ.
/// @note   None.
/// @param  None.
/// @retval None.
////////////////////////////////////////////////////////////////////////////////
void PVD_IRQHandler(void)
{

    if(EXTI_GetITStatus(EXTI_Line16) != RESET)
    {
        // Clear the EXTI line pending bit
        EXTI_ClearITPendingBit(EXTI_Line16);
        lowpowerflag = 1;
    }
}

////////////////////////////////////////////////////////////////////////////////
/// @brief  EXTI config.
/// @note   None.
/// @param  None.
/// @retval None.
////////////////////////////////////////////////////////////////////////////////
void EXTI_Configuration(void)
{
    EXTI_InitTypeDef EXTI_InitStructure;

    // Configure EXTI Line16(PVD Output) to generate an interrupt on rising and
    //   falling edges
    EXTI_ClearITPendingBit(EXTI_Line16);
    // PVD map to EXTI_Line16
    EXTI_InitStructure.EXTI_Line = EXTI_Line16;
    EXTI_InitStructure.EXTI_Mode = EXTI_Mode_Interrupt;
    EXTI_InitStructure.EXTI_Trigger = EXTI_Trigger_Rising_Falling;
    EXTI_InitStructure.EXTI_LineCmd = ENABLE;
    EXTI_Init(&EXTI_InitStructure);
}

////////////////////////////////////////////////////////////////////////////////
/// @brief  NVIC config.
/// @note   None.
/// @param  None.
/// @retval None.
////////////////////////////////////////////////////////////////////////////////
void NVIC_Configuration(void)
{
    NVIC_InitTypeDef NVIC_InitStructure;

    /* Enable the PVD Interrupt */
    NVIC_InitStructure.NVIC_IRQChannel = PVD_IRQn;
    NVIC_InitStructure.NVIC_IRQChannelPriority = 0;
    NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
    NVIC_Init(&NVIC_InitStructure);
}

////////////////////////////////////////////////////////////////////////////////
/// @brief  delay config.
/// @note   None.
/// @param  None.
/// @retval None.
////////////////////////////////////////////////////////////////////////////////
static void deleyNop(u32 DlyTime)
{
    u32 i, j;
    for(i = 0; i < DlyTime; i++)
    {
        for(j = 0; j < 100; j++)
        {
            __NOP();
            __NOP();
            __NOP();
            __NOP();
            __NOP();
            __NOP();
            __NOP();
            __NOP();
            __NOP();
            __NOP();
            __NOP();
            __NOP();
            __NOP();
            __NOP();
            __NOP();
        }
    }
}


////////////////////////////////////////////////////////////////////////////////
/// @brief  Set GPIO port RCC clock
/// @note   It must be careful of the Chip Version.
/// @param  GPIOx GPIO port.
/// @param  NewState ENABLE and DISABLE.
/// @retval None.
////////////////////////////////////////////////////////////////////////////////
void GPIO_Clock_Set(GPIO_TypeDef* GPIOx, FunctionalState NewState)
{

    if(GPIOx == GPIOA)
    {
        RCC_AHBPeriphClockCmd(RCC_AHBPeriph_GPIOA, NewState);
    }
    if(GPIOx == GPIOB)
    {
        RCC_AHBPeriphClockCmd(RCC_AHBPeriph_GPIOB, NewState);
    }
    if(GPIOx == GPIOC)
    {
        RCC_AHBPeriphClockCmd(RCC_AHBPeriph_GPIOC, NewState);
    }
    if(GPIOx == GPIOD)
    {
        RCC_AHBPeriphClockCmd(RCC_AHBPeriph_GPIOD, NewState);
    }
}

////////////////////////////////////////////////////////////////////////////////
/// @brief  initialize LED GPIO pin
/// @note   if use jtag/swd interface GPIO PIN as LED, need to be careful,
///         can not debug or program.
/// @param  None.
/// @retval None.
////////////////////////////////////////////////////////////////////////////////
void LED_Init(void)
{

    GPIO_InitTypeDef  GPIO_InitStructure;

    GPIO_Clock_Set(GPIOA, ENABLE);
    GPIO_Clock_Set(GPIOB, ENABLE);
    GPIO_InitStructure.GPIO_Pin  =  GPIO_Pin_15;
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
    GPIO_Init(GPIOA, &GPIO_InitStructure);

    GPIO_InitStructure.GPIO_Pin  = GPIO_Pin_3 | GPIO_Pin_4 | GPIO_Pin_5;
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
    GPIO_Init(GPIOB, &GPIO_InitStructure);

    LED1_ON();
    LED2_ON();
    LED3_ON();
    LED4_ON();
}
/// @}

/// @}

/// @}
