////////////////////////////////////////////////////////////////////////////////
/// @file    Tamper.c
/// @author  AE TEAM
/// @version v1.0.0
/// @date    2019-09-20
/// @brief   THIS FILE PROVIDES ALL THE SYSTEM FUNCTIONS.
////////////////////////////////////////////////////////////////////////////////
/// @attention
///
/// THE EXISTING FIRMWARE IS ONLY FOR REFERENCE, WHICH IS DESIGNED TO PROVIDE
/// CUSTOMERS WITH CODING INFORMATION ABOUT THEIR PRODUCTS SO THEY CAN SAVE
/// TIME. THEREFORE, MINDMOTION SHALL NOT BE LIABLE FOR ANY DIRECT, INDIRECT OR
/// CONSEQUENTIAL DAMAGES ABOUT ANY CLAIMS ARISING OUT OF THE CONTENT OF SUCH
/// HARDWARE AND/OR THE USE OF THE CODING INFORMATION CONTAINED HEREIN IN
/// CONNECTION WITH PRODUCTS MADE BY CUSTOMERS.
///
/// <H2><CENTER>&COPY; COPYRIGHT 2019 MINDMOTION </CENTER></H2>
////////////////////////////////////////////////////////////////////////////////

// Define to prevent recursive inclusion  --------------------------------------
#define _TAMPER_C_

// Files includes  -------------------------------------------------------------

#include "Tamper.h"


////////////////////////////////////////////////////////////////////////////////
/// @addtogroup MM32_Example_Layer
/// @{

////////////////////////////////////////////////////////////////////////////////
/// @addtogroup MM32_RESOURCE
/// @{

////////////////////////////////////////////////////////////////////////////////
/// @addtogroup MM32_Exported_Constants
/// @{

/// @}
BKPDR_Typedef BKPDataReg[10] =
{
    BKP_DR1, BKP_DR2, BKP_DR3, BKP_DR4, BKP_DR5, BKP_DR6, BKP_DR7, BKP_DR8,
    BKP_DR9, BKP_DR10
};

////////////////////////////////////////////////////////////////////////////////
/// @brief  This function is main entrance.
/// @param  None.
/// @retval  0.
////////////////////////////////////////////////////////////////////////////////
int main(void)
{
    SetSystemClock(emSYSTICK_On, NULL);
    LED_Init();
    BKP_DATA();
    while(1)
    {

    }
}
////////////////////////////////////////////////////////////////////////////////
/// @brief  : Start intrusion detection
/// @param  : Portx , State
/// @retval : None
////////////////////////////////////////////////////////////////////////////////
void  BKP_DATA(void)
{
    NVIC_Configuration();
    // Enable PWR and BKP clock
    RCC_APB1PeriphClockCmd(RCC_APB1Periph_PWR, ENABLE);

    // Enable write access to Backup domain
    PWR_BackupAccessCmd(ENABLE);
    // Disable Tamper pin
    BKP_TamperPinCmd(DISABLE);

    // Disable Tamper interrupt
    BKP_ITConfig(DISABLE);

    // Tamper pin active on low level
    BKP_TamperPinLevelConfig(BKP_TamperPinLevel_Low);

    // Clear Tamper pin Event(TE) pending flag
    BKP_ClearFlag();

    // Enable Tamper interrupt
    BKP_ITConfig(ENABLE);
    // Enable Tamper pin
    BKP_TamperPinCmd(ENABLE);
    // Write data to register library
    WriteToBackupReg(0xabcd);
    // Check if the written data are correct
    if(CheckBackupReg(0xabcd) == 0x00)
    {
        // Turn off LED1
        LED1_OFF();//Correct data reading and writing
    }
    else
    {
        // Turn off LED3
        LED3_OFF();//Data read-write error
    }
}
////////////////////////////////////////////////////////////////////////////////
/// @brief  : Write data to register library
/// @param  : FirstBackupData
/// @retval : None
////////////////////////////////////////////////////////////////////////////////
void WriteToBackupReg(u16 FirstBackupData)
{
    uint32_t index = 0;

    for (index = 0; index < 10; index++)
    {
        // Write data into the corresponding register
        BKP_WriteBackupRegister(BKPDataReg[index], FirstBackupData);
    }
}
////////////////////////////////////////////////////////////////////////////////
/// @brief  : Determine if the write data is correct
/// @param  : FirstBackupData
/// @retval : index + 1,error
///           0,success
////////////////////////////////////////////////////////////////////////////////
u8 CheckBackupReg(u16 FirstBackupData)
{
    u32 index = 0;

    for (index = 0; index < 10; index++)
    {
        if (BKP_ReadBackupRegister(BKPDataReg[index]) != FirstBackupData)
        {
            return (index + 1);
        }
    }
    return 0;
}
////////////////////////////////////////////////////////////////////////////////
/// @brief  : Configure the NVIC
/// @param  : None
/// @retval : None
////////////////////////////////////////////////////////////////////////////////
void NVIC_Configuration(void)
{
    NVIC_InitTypeDef NVIC_InitStructure;

    // Enable TAMPER IRQChannel
    NVIC_InitStructure.NVIC_IRQChannel = RTC_BKP_IRQn;
    NVIC_InitStructure.NVIC_IRQChannelPriority = 0;
    NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
    NVIC_Init(&NVIC_InitStructure);
}

////////////////////////////////////////////////////////////////////////////////
/// @brief  : RCC clock set
/// @param  : Portx , State
/// @retval : None
////////////////////////////////////////////////////////////////////////////////
void GPIO_Clock_Set(GPIO_TypeDef* GPIOx, FunctionalState NewState)
{
    if(GPIOx == GPIOA)
    {
        RCC_AHBPeriphClockCmd(RCC_AHBPeriph_GPIOA, NewState);                   //GPIO clock starts
    }
    if(GPIOx == GPIOB)
    {
        RCC_AHBPeriphClockCmd(RCC_AHBPeriph_GPIOB, NewState);                   //GPIO clock starts
    }
    if(GPIOx == GPIOC)
    {
        RCC_AHBPeriphClockCmd(RCC_AHBPeriph_GPIOC, NewState);                   //GPIO clock starts
    }
    if(GPIOx == GPIOD)
    {
        RCC_AHBPeriphClockCmd(RCC_AHBPeriph_GPIOD, NewState);                   //GPIO clock starts
    }
}
////////////////////////////////////////////////////////////////////////////////
/// @brief  initialize LED GPIO pin
/// @note   if use jtag/swd interface GPIO PIN as LED, need to be careful, can not debug or program.
/// @param  None.
/// @retval None.
////////////////////////////////////////////////////////////////////////////////
void LED_Init(void)
{
    GPIO_InitTypeDef  GPIO_InitStructure;

    GPIO_Clock_Set(GPIOA, ENABLE);
    GPIO_Clock_Set(GPIOB, ENABLE);
    GPIO_InitStructure.GPIO_Pin  =  GPIO_Pin_15;
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
    GPIO_Init(GPIOA, &GPIO_InitStructure);

    GPIO_InitStructure.GPIO_Pin  = GPIO_Pin_3 | GPIO_Pin_4 | GPIO_Pin_5;
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
    GPIO_Init(GPIOB, &GPIO_InitStructure);

    LED1_ON();
    LED2_ON();
    LED3_ON();
    LED4_ON();
}


////////////////////////////////////////////////////////////////////////////////
/// @brief  This function is called back by SysTick Handler
///         call series function to run systick cycle running
///         for example , delay, led blink, key in scan , etc.
/// @note   This function always run after power on.
/// @param  None.
/// @retval None.
////////////////////////////////////////////////////////////////////////////////
void SysTick_Handler_CALL(void)
{
    TimingDelay_Decrement();
}
////////////////////////////////////////////////////////////////////////////////
/// @brief  This function make delay count decrement as one systick
///         for example , delay (1ms)
/// @note   when decrement to zero�� it always 0.
/// @param  None.
/// @retval None.
////////////////////////////////////////////////////////////////////////////////
void TimingDelay_Decrement(void)
{
    if (TimingDelay != 0x00)
    {
        TimingDelay--;
    }
}
////////////////////////////////////////////////////////////////////////////////
// @brief  delay nTime ms
// @note   get x times.
/// @param  nTime  nTime ms.
/// @retval None.
////////////////////////////////////////////////////////////////////////////////
void delay_ms(__IO uint32_t nTime)
{
    TimingDelay = nTime;

    while(TimingDelay != 0);
}
/// @}


/// @}

/// @}


