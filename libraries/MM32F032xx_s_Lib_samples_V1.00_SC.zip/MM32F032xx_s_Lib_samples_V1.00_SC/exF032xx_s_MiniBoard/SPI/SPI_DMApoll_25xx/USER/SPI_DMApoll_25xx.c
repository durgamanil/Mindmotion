////////////////////////////////////////////////////////////////////////////////
/// @file    ex_SPI_poll_ex25xxSPI2.c
/// @author  AE TEAM
/// @version v1.0.0
/// @date    2019-09-20
/// @brief   Use DMA to send and receive data, compare data, print
///          SPI2 WR 25xx Successful if read and write are consistent.
////////////////////////////////////////////////////////////////////////////////
/// @attention
///
/// THE EXISTING FIRMWARE IS ONLY FOR REFERENCE, WHICH IS DESIGNED TO PROVIDE
/// CUSTOMERS WITH CODING INFORMATION ABOUT THEIR PRODUCTS SO THEY CAN SAVE
/// TIME. THEREFORE, MINDMOTION SHALL NOT BE LIABLE FOR ANY DIRECT, INDIRECT OR
/// CONSEQUENTIAL DAMAGES ABOUT ANY CLAIMS ARISING OUT OF THE CONTENT OF SUCH
/// HARDWARE AND/OR THE USE OF THE CODING INFORMATION CONTAINED HEREIN IN
/// CONNECTION WITH PRODUCTS MADE BY CUSTOMERS.
///
/// <H2><CENTER>&COPY; COPYRIGHT 2019 MINDMOTION </CENTER></H2>
////////////////////////////////////////////////////////////////////////////////

#include "SPI_DMApoll_25xx.h"

#define LENGTH 16
//#pragma diag_suppress=Pe188
static unsigned char rxdata[LENGTH];
static unsigned char txdata[LENGTH] = \
{
    0x55, 0xaa, 0xbb, 0xdd, 0x33, 0x77, 0x22, 0x11, \
    0x55, 0xaa, 0xbb, 0xdd, 0x33, 0x77, 0x22, 0x11
};
extern uint32_t SystemCoreClock;
char printBuf[100];
unsigned char tmpdata[256];
unsigned char rxtmpdata[256];


////////////////////////////////////////////////////////////////////////////////
/// @brief  This function is main entrance.
/// @param  None.
/// @retval None.
////////////////////////////////////////////////////////////////////////////////
int main(void)
{

    Uart_ConfigInit(9600);
    UartSendGroup((u8*)printBuf, sprintf(printBuf, "\r\nsprintf ok\r\n"));
    UartSendGroup((u8*)printBuf, sprintf(printBuf, "\r\nStart SPI test\r\n"));

    SPI_TxRx_25xx_DMAPOLLing_Test();

    while(1)
    {

    }
}

////////////////////////////////////////////////////////////////////////////////
/// @brief  Turn off the data transmission direction of SPI in bidirectional mode
/// @note   None.
/// @param  SPIx:SPI1/SPI2.
/// @retval None.
////////////////////////////////////////////////////////////////////////////////
void SPIM_TXEn(SPI_TypeDef* SPIx)
{

    SPI_BiDirectionalLineConfig(SPIx, SPI_Direction_Tx);
}

////////////////////////////////////////////////////////////////////////////////
/// @brief  Turn off the data transmission direction of SPI in bidirectional mode
/// @note   None.
/// @param  SPIx:SPI1/SPI2.
/// @retval None.
////////////////////////////////////////////////////////////////////////////////
void SPIM_RXEn(SPI_TypeDef* SPIx)
{
    SPI_BiDirectionalLineConfig(SPIx, SPI_Direction_Rx);
}

////////////////////////////////////////////////////////////////////////////////
/// @brief  Reset internal NSS pins for selected SPI software
/// @note   None.
/// @param  None.
/// @retval None.
////////////////////////////////////////////////////////////////////////////////
void SPIM_CSLow(SPI_TypeDef* SPIx)
{

    SPI_CSInternalSelected(SPIx, ENABLE);

}

////////////////////////////////////////////////////////////////////////////////
/// @brief  Reset internal NSS pins for selected SPI software
/// @note   None.
/// @param  None.
/// @retval None.
////////////////////////////////////////////////////////////////////////////////
void SPIM_CSHigh(SPI_TypeDef* SPIx)
{

    SPI_CSInternalSelected(SPIx, DISABLE);

}


////////////////////////////////////////////////////////////////////////////////
/// @brief  Initialization of DMA Received Data.
/// @note   None.
/// @param  None.
/// @retval None.
////////////////////////////////////////////////////////////////////////////////
void SPI2_DMA_RX_Init()
{
    //DMA1  CHANNEL4
    DMA_InitTypeDef  DMA_InitStructure;
    RCC_AHBPeriphClockCmd(RCC_AHBPeriph_DMA1, ENABLE);
    DMA_DeInit(DMA1_Channel4);
    DMA_InitStructure.PeripheralBaseAddr = (uint32_t) & (SPI2->RDR);
    DMA_InitStructure.MemoryBaseAddr = (uint32_t)rxdata;
    DMA_InitStructure.DIR = DMA_DIR_PeripheralSRC;
    DMA_InitStructure.BufferSize = 1;
    DMA_InitStructure.PeripheralInc = DMA_PeripheralInc_Disable;
    DMA_InitStructure.MemoryInc = DMA_MemoryInc_Disable;
    DMA_InitStructure.PeripheralDataSize = DMA_PeripheralDataSize_Byte;
    DMA_InitStructure.MemoryDataSize = DMA_MemoryDataSize_Byte;
    DMA_InitStructure.Mode = DMA_Mode_Normal;
    DMA_InitStructure.Priority = DMA_Priority_VeryHigh;
    DMA_InitStructure.M2M = DMA_M2M_Disable;
    DMA_Init(DMA1_Channel4, &DMA_InitStructure);
}

////////////////////////////////////////////////////////////////////////////////
/// @brief  Initialization of DMA Send Data.
/// @note   None.
/// @param  None.
/// @retval None.
////////////////////////////////////////////////////////////////////////////////
void SPI2_DMA_TX_Init()
{
    //DMA1  CHANNEL5
    DMA_InitTypeDef  DMA_InitStructure;
    RCC_AHBPeriphClockCmd(RCC_AHBPeriph_DMA1, ENABLE);
    DMA_DeInit(DMA1_Channel5);
    DMA_InitStructure.PeripheralBaseAddr = (uint32_t) & (SPI2->TDR);
    DMA_InitStructure.MemoryBaseAddr = (uint32_t)txdata;
    DMA_InitStructure.DIR = DMA_DIR_PeripheralDST;
    DMA_InitStructure.BufferSize = 1;
    DMA_InitStructure.PeripheralInc = DMA_PeripheralInc_Disable;
    DMA_InitStructure.MemoryInc = DMA_MemoryInc_Disable;
    DMA_InitStructure.PeripheralDataSize = DMA_PeripheralDataSize_Byte;
    DMA_InitStructure.MemoryDataSize = DMA_MemoryDataSize_Byte;
    DMA_InitStructure.Mode = DMA_Mode_Normal;
    DMA_InitStructure.Priority = DMA_Priority_VeryHigh;
    DMA_InitStructure.M2M = DMA_M2M_Disable;
    DMA_Init(DMA1_Channel5, &DMA_InitStructure);
}
////////////////////////////////////////////////////////////////////////////////
/// @brief  Set the DMA Channeln's Peripheral address.
/// @param  channel : where n can be 1 to 7 for DMA1 to select the DMA Channel.
/// @param  length : Transmit lengths.
/// @retval : None
////////////////////////////////////////////////////////////////////////////////
void DMA_Set_TransmitLen(DMA_Channel_TypeDef* channel, u16 length)
{
    channel->CNDTR = length;
}

////////////////////////////////////////////////////////////////////////////////
/// @brief  Set the DMA Channeln's Peripheral address.
/// @param  channel : where n can be 1 to 7 for DMA1 to select the DMA Channel.
/// @param  address : DMA memery address.
/// @retval : None
////////////////////////////////////////////////////////////////////////////////
void DMA_Set_MemoryAddress(DMA_Channel_TypeDef* channel, u32 address)
{
    channel->CMAR = address;
}
////////////////////////////////////////////////////////////////////////////////
/// @brief  Set the DMA Channeln's Peripheral address.
/// @param  channel : where n can be 1 to 7 for DMA1 to select the DMA Channel.
/// @param  length : Transmit lengths.
/// @retval : None
////////////////////////////////////////////////////////////////////////////////
void DMA_Set_MemoryInc_Enable(DMA_Channel_TypeDef* channel, FunctionalState NewState)
{
    // Check the parameters
//    assert_param(IS_FUNCTIONAL_STATE(NewState));

    if(NewState == ENABLE)
    {
        channel->CCR |= DMA_MemoryInc_Enable;
    }
    else
    {
        channel->CCR  &= ~(DMA_MemoryInc_Enable);
    }
}
////////////////////////////////////////////////////////////////////////////////
/// @brief   DMA transmits packet
/// @param   ch: Pointer to a DMA channel.
/// @param   addr: The memory Buffer address.
/// @param   len: The length of data to be transferred.
/// @retval : None.
////////////////////////////////////////////////////////////////////////////////
void DRV_DMA_TransmitPacket(DMA_Channel_TypeDef* ch, u32 addr, u32 len)
{
    DMA_ITConfig(ch, DMA_IT_TC, ENABLE);
    DMA_Cmd(ch, DISABLE);
    DMA_Set_MemoryAddress(ch, addr);
    DMA_Set_TransmitLen(ch, len);
    DMA_Cmd(ch, ENABLE);
}


////////////////////////////////////////////////////////////////////////////////
/// @brief   DMA transmit and receive packet
/// @param   ptx_buf: Pointer to SPI DMA send buffer(include send and recv bytes).
/// @param   prx_buf: Pointer to SPI DMA recv buffer(include send and recv bytes).
/// @param   len: The length of data , length equal send + recv len).
/// @retval : None.
////////////////////////////////////////////////////////////////////////////////
void SPI2MasterWritebuf(u8 *ptx_buf,  u32 len)
{
    u32 uByte[2];
    DMA_Set_MemoryInc_Enable(DMA1_Channel5, ENABLE);
    DRV_DMA_TransmitPacket(DMA1_Channel5, (u32)ptx_buf, len);
    DMA_Set_MemoryInc_Enable(DMA1_Channel4, DISABLE);
    DRV_DMA_TransmitPacket(DMA1_Channel4, (u32)uByte, len);
    SPI_DMACmd(SPI2, ENABLE);
    while(!DMA_GetFlagStatus(DMA1_FLAG_TC5));
    DMA_ClearFlag(DMA1_FLAG_TC5);
    while(!DMA_GetFlagStatus(DMA1_FLAG_TC4));
    DMA_ClearFlag(DMA1_FLAG_TC4);
    SPI_DMACmd(SPI2, DISABLE);

}
////////////////////////////////////////////////////////////////////////////////
/// @brief   DMA transmit and receive packet
/// @param   ptx_buf: Pointer to SPI DMA send buffer(include send and recv bytes).
/// @param   prx_buf: Pointer to SPI DMA recv buffer(include send and recv bytes).
/// @param   len: The length of data , length equal send + recv len).
/// @retval : None.
////////////////////////////////////////////////////////////////////////////////
void SPI2MasterReadbuf( u8 *prx_buf, u32 len)
{
    u32 uByte[2];
    DMA_Set_MemoryInc_Enable(DMA1_Channel5, DISABLE);
    DRV_DMA_TransmitPacket(DMA1_Channel5, (u32)uByte, len);
    DMA_Set_MemoryInc_Enable(DMA1_Channel4, ENABLE);
    DRV_DMA_TransmitPacket(DMA1_Channel4, (u32)prx_buf, len);

    SPI_DMACmd(SPI2, ENABLE);

    while(!DMA_GetFlagStatus(DMA1_FLAG_TC4));
    DMA_ClearFlag(DMA1_FLAG_TC4);
    SPI_DMACmd(SPI2, DISABLE);

}

////////////////////////////////////////////////////////////////////////////////
/// @brief  Read data.
/// @note   None.
/// @param  pBuf:Rx buff.
/// @param  len:data length.
/// @retval None.
////////////////////////////////////////////////////////////////////////////////
uint8_t spiReadBurst(uint8_t* pBuf, uint16_t len)
{
    if(len == 0)
        return 0;
    SPI2MasterReadbuf(pBuf, len);
    return len;

}
////////////////////////////////////////////////////////////////////////////////
/// @brief  Write data.
/// @note   None.
/// @param  pBuf:tx buff.
/// @param  len:data length.
/// @retval None.
////////////////////////////////////////////////////////////////////////////////
void spiWriteBurst(uint8_t* pBuf, uint16_t len)
{
    if(len == 0)
        return ;
    SPI2MasterWritebuf(pBuf, len);
    return ;
}
//------------------------------------------------------------------------------
////////////////////////////////////////////////////////////////////////////////
/// @brief  check Status
/// @note   None.
/// @param  None.
/// @retval None.
////////////////////////////////////////////////////////////////////////////////
void SPI25xx_checkStatus(void)
{

    unsigned char temp[5];
    unsigned int i = 0;

    SPIM_CSLow(SPI2);
    temp[i++] = RDSR;
    spiWriteBurst(temp, i);
    while(1)
    {
        spiReadBurst(&temp[i], 1);
        if(((temp[i]) & 0x01) == 0x0)
            break;
    }
    SPIM_CSHigh(SPI2);

}

////////////////////////////////////////////////////////////////////////////////
/// @brief  Enable write
/// @note   None.
/// @param  None.
/// @retval None.
////////////////////////////////////////////////////////////////////////////////
void SPI25xx_WriteEnable(void)
{
    unsigned char temp[5];
    unsigned int i = 0;
    temp[i++] = WREN;
    //Spi cs assign to this pin,select
    SPIM_CSLow(SPI2);

    spiWriteBurst(temp, i);
    SPIM_CSHigh(SPI2);

}

////////////////////////////////////////////////////////////////////////////////
/// @brief  Read ID
/// @note   None.
/// @param  None.
/// @retval None.
////////////////////////////////////////////////////////////////////////////////
void SPI25xx_ReadID(void)
{
    unsigned char temp[5];
    unsigned int i = 0;
    temp[i++] = RDID;
    //Spi cs assign to this pin,select
    SPIM_CSLow(SPI2);

    spiWriteBurst(temp, i);
    spiReadBurst(&temp[i], 3);

    //Spi cs release
    SPIM_CSHigh(SPI2);
}

////////////////////////////////////////////////////////////////////////////////
/// @brief  SPI Sector Erase
/// @note   None.
/// @param  Addr:address.
/// @retval None.
////////////////////////////////////////////////////////////////////////////////
void SPI25xx_SectorErase(unsigned long address)
{
    unsigned char temp[5];
    unsigned int i = 0;

    address = address & 0xffff0000;
    temp[i++] = SE;
    temp[i++] = ((unsigned char)(address >> 16)) & 0xff;
    temp[i++] = ((unsigned char)(address >> 8)) & 0xff;
    temp[i++] = ((unsigned char)address) & 0xff;
    SPI25xx_WriteEnable();
    //Spi cs assign to this pin,select
    SPIM_CSLow(SPI2);
    spiWriteBurst(temp, i);
    //Spi cs release
    SPIM_CSHigh(SPI2);

    SPI25xx_checkStatus();
}

////////////////////////////////////////////////////////////////////////////////
/// @brief  SPI FLASH Read
/// @note   None.
/// @param  Address:address.
/// @param  number:length.
/// @param  p:data buff.
/// @retval None.
////////////////////////////////////////////////////////////////////////////////
void SPI25xx_PageRead(unsigned long address, unsigned char *p, unsigned int number)
{

    unsigned char temp[5];
    unsigned int i = 0;

    address = address & 0xffff0000;
    temp[i++] = READ;
    temp[i++] = ((unsigned char)(address >> 16)) & 0xff;
    temp[i++] = ((unsigned char)(address >> 8)) & 0xff;
    temp[i++] = ((unsigned char)address) & 0xff;
    SPI25xx_checkStatus();
    //Spi cs assign to this pin,select
    SPIM_CSLow(SPI2);
    spiWriteBurst(temp, i);
    spiReadBurst(p, number);


    SPIM_CSHigh(SPI2);
}

////////////////////////////////////////////////////////////////////////////////
/// @brief  SPI FLASH Write
/// @note   None.
/// @param  Address:address.
/// @param  number:length.
/// @param  p:data buff.
/// @retval None.
////////////////////////////////////////////////////////////////////////////////
void SPI25xx_PageProgram(unsigned long address, unsigned char *p, unsigned int number)
{
    unsigned char temp[5];
    unsigned int i = 0;

    address = address & 0xffff0000;
    temp[i++] = PP;
    temp[i++] = ((unsigned char)(address >> 16)) & 0xff;
    temp[i++] = ((unsigned char)(address >> 8)) & 0xff;
    temp[i++] = ((unsigned char)address) & 0xff;
    SPI25xx_WriteEnable();

    SPIM_CSLow(SPI2);
    spiWriteBurst(temp, i);
    spiWriteBurst(p, number);

    SPIM_CSHigh(SPI2);
    SPI25xx_checkStatus();
}

////////////////////////////////////////////////////////////////////////////////
/// @brief  Initialization DMA TX/RX
/// @note   None.
/// @param  None.
/// @retval None.
////////////////////////////////////////////////////////////////////////////////
void SPI25xxPolling_Init(void)
{
    SPI2_DMA_RX_Init();
    SPI2_DMA_TX_Init();
    SPIM_Init(SPI2, 0x04);
}

////////////////////////////////////////////////////////////////////////////////
/// @brief  Test program, using serial port to print 256 pages of data
/// @note   None.
/// @param  None.
/// @retval None.
////////////////////////////////////////////////////////////////////////////////
void SPI_TxRx_25xx_DMAPOLLing_Test(void)
{
    unsigned int i, result = 0;
    for(i = 0; i < 256; i++)
    {
        tmpdata[i] = i * 2;
    }
    {
        UartSendGroup((u8*)printBuf, sprintf(printBuf, "SPI2 test\r\n"));
        SPI25xxPolling_Init();
        i = 10;
        while(i--)
        {
            SPI25xx_ReadID();
        }

        SPI25xx_SectorErase(0);

        SPI25xx_PageProgram(0, tmpdata, 256);


        memset(rxtmpdata, 0x0, 256);

        SPI25xx_PageRead(0, rxtmpdata, 256);


        for(i = 0; i < 10; i++)
        {
            UartSendGroup((u8*)printBuf, sprintf(printBuf, "rx[%d]=0x%x\r\n", i, rxtmpdata[i]));
        }
        for(i = 0; i < 256; i++)
        {
            if(tmpdata[i] != rxtmpdata[i])
            {
                result = 1;
                break;
            }

        }
        if(result == 1)
        {
            UartSendGroup((u8*)printBuf, sprintf(printBuf, "SPI2 WR 25xx Fail\r\n"));
        }
        else
        {
            UartSendGroup((u8*)printBuf, sprintf(printBuf, "SPI2 WR 25xx Successful\r\n"));

        }
        UartSendGroup((u8*)printBuf, sprintf(printBuf, "SPI2 test over\r\n"));
    }

}


////////////////////////////////////////////////////////////////////////////////
/// @brief  initialize SPI2 MODE1(master)
/// @note   None.
/// @param  None.
/// @retval None.
////////////////////////////////////////////////////////////////////////////////
void SPI2GPIOPinConfig(void)
{
    GPIO_InitTypeDef  GPIO_InitStructure;

    RCC_AHBPeriphClockCmd(RCC_AHBPeriph_GPIOB, ENABLE);
    //spi2_cs  pb12
    GPIO_InitStructure.GPIO_Pin  = GPIO_Pin_12;
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP;
    GPIO_Init(GPIOB, &GPIO_InitStructure);
    //spi2_sck  pb13
    GPIO_InitStructure.GPIO_Pin  = GPIO_Pin_13;
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP;
    GPIO_Init(GPIOB, &GPIO_InitStructure);
    //spi2_mosi  pb15
    GPIO_InitStructure.GPIO_Pin  = GPIO_Pin_15;
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP;
    GPIO_Init(GPIOB, &GPIO_InitStructure);
    //spi2_miso  pb14
    GPIO_InitStructure.GPIO_Pin  = GPIO_Pin_14;
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IPU;
    GPIO_Init(GPIOB, &GPIO_InitStructure);
    GPIO_PinAFConfig(GPIOB, GPIO_PinSource12, GPIO_AF_0);
    GPIO_PinAFConfig(GPIOB, GPIO_PinSource13, GPIO_AF_0);
    GPIO_PinAFConfig(GPIOB, GPIO_PinSource14, GPIO_AF_0);
    GPIO_PinAFConfig(GPIOB, GPIO_PinSource15, GPIO_AF_0);

}

////////////////////////////////////////////////////////////////////////////////
/// @brief  Modifiable parameter initialization SPI.
/// @note   None.
/// @param  SPIx:SPI1/SPI2.
/// @param  spi_baud_div:Specifies the Baud Rate prescaler value which will be..
/// @retval None.
////////////////////////////////////////////////////////////////////////////////
void SPIM_Init(SPI_TypeDef* SPIx, unsigned short spi_baud_div)
{
    SPI_InitTypeDef SPI_InitStructure;

    if(SPIx == SPI2)
    {
        RCC_APB1PeriphClockCmd(RCC_APB1Periph_SPI2, ENABLE);
        SPI2GPIOPinConfig();
    }

    SPI_InitStructure.SPI_Mode = SPI_Mode_Master;
    SPI_InitStructure.SPI_DataSize = SPI_DataSize_8b;
    SPI_InitStructure.SPI_DataWidth = 8;
    SPI_InitStructure.SPI_CPOL = SPI_CPOL_Low;
    SPI_InitStructure.SPI_CPHA = SPI_CPHA_1Edge;
    SPI_InitStructure.SPI_NSS = SPI_NSS_Soft;
    SPI_InitStructure.SPI_BaudRatePrescaler = (SPI_BaudRatePrescaler_TypeDef)spi_baud_div;
    SPI_InitStructure.SPI_FirstBit = SPI_FirstBit_MSB;
    SPI_Init(SPIx, &SPI_InitStructure);
    SPIM_CSHigh(SPI2);
    SPI_Cmd(SPIx, ENABLE);
    SPIM_TXEn(SPIx);
    SPIM_RXEn(SPIx);
}

////////////////////////////////////////////////////////////////////////////////
/// @brief  Serial port initialization configuration
/// @note    It must be careful of the Chip Version.
/// @param  bound: Baud rate
/// @retval None.
////////////////////////////////////////////////////////////////////////////////
void Uart_ConfigInit(u32 bound)
{
    GPIO_InitTypeDef GPIO_InitStructure;
    UART_InitTypeDef UART_InitStructure;

    RCC_APB2PeriphClockCmd(RCC_APB2Periph_UART1, ENABLE);
    RCC_AHBPeriphClockCmd(RCC_AHBPeriph_GPIOA, ENABLE);
    //GPIO mapping function
    GPIO_PinAFConfig(GPIOA, GPIO_PinSource9, GPIO_AF_1);
    GPIO_PinAFConfig(GPIOA, GPIO_PinSource10, GPIO_AF_1);
    //Baud rate
    UART_InitStructure.BaudRate = bound;
    //The word length is in 8-bit data format.
    UART_InitStructure.WordLength = UART_WordLength_8b;
    UART_InitStructure.StopBits = UART_StopBits_1;
    //No even check bit.
    UART_InitStructure.Parity = UART_Parity_No;
    //No hardware data flow control.
    UART_InitStructure.HWFlowControl = UART_HWFlowControl_None;
    UART_InitStructure.Mode = UART_Mode_Rx | UART_Mode_Tx;

    UART_Init(UART1, &UART_InitStructure);
    UART_Cmd(UART1, ENABLE);

    //UART1_TX   GPIOA.9  Reuse push-pull output
    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_9;
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP;
    GPIO_Init(GPIOA, &GPIO_InitStructure);

    //UART1_RX	  GPIOA.10  Floated input
    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_10;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_FLOATING;
    GPIO_Init(GPIOA, &GPIO_InitStructure);
}

////////////////////////////////////////////////////////////////////////////////
/// @brief  Uart Send Byte
/// @note   None.
/// @param  dat: data
/// @retval None.
////////////////////////////////////////////////////////////////////////////////
void UartSendByte(u8 dat)
{
    UART_SendData( UART1, dat);
    while(!UART_GetFlagStatus(UART1, UART_FLAG_TXEPT));
}

////////////////////////////////////////////////////////////////////////////////
/// @brief  Uart Send Group
/// @note   None.
/// @param  buf: data buff
/// @param  len: length
/// @retval None.
////////////////////////////////////////////////////////////////////////////////
void UartSendGroup(u8* buf, u16 len)
{
    while(len--)
        UartSendByte(*buf++);
}


/// @}


/// @}

/// @}
