////////////////////////////////////////////////////////////////////////////////
/// @file    SPI_poll_ex25xx.c
/// @author  AE TEAM
/// @version v1.0.0
/// @date    2019-09-20
/// @brief   Use SPI2 to read and write 256 bytes, print and read 20 bytes.
////////////////////////////////////////////////////////////////////////////////
/// @attention
///
/// THE EXISTING FIRMWARE IS ONLY FOR REFERENCE, WHICH IS DESIGNED TO PROVIDE
/// CUSTOMERS WITH CODING INFORMATION ABOUT THEIR PRODUCTS SO THEY CAN SAVE
/// TIME. THEREFORE, MINDMOTION SHALL NOT BE LIABLE FOR ANY DIRECT, INDIRECT OR
/// CONSEQUENTIAL DAMAGES ABOUT ANY CLAIMS ARISING OUT OF THE CONTENT OF SUCH
/// HARDWARE AND/OR THE USE OF THE CODING INFORMATION CONTAINED HEREIN IN
/// CONNECTION WITH PRODUCTS MADE BY CUSTOMERS.
///
/// <H2><CENTER>&COPY; COPYRIGHT 2019 MINDMOTION </CENTER></H2>
////////////////////////////////////////////////////////////////////////////////

#include "SPI_poll_ex25xx.h"


char printBuf[100];


unsigned char tmpdata[256];
unsigned char rxtmpdata[256];


////////////////////////////////////////////////////////////////////////////////
/// @brief  This function is main entrance.
/// @param  None.
/// @retval None.
////////////////////////////////////////////////////////////////////////////////
int main(void)
{
    u32 i ;

    RCC_ConfigInit();
    Uart_ConfigInit(9600);
    UartSendGroup((u8*)printBuf, sprintf(printBuf, "\r\nsprintf ok\r\n"));
    SPIM_Init(SPI2, 0x30);
    for(i = 0; i < 256; i++)
    {
        tmpdata[i] = i * 2;
    }

    W25xx_ReadID(SPI2, rxtmpdata);
    UartSendGroup((u8*)printBuf, sprintf(printBuf, "\r\nW25xx_ReadID:\r\n"));
    for(i = 0; i < 4; i++)
    {
        UartSendGroup((u8*)printBuf, sprintf(printBuf, "%2x ", rxtmpdata[i]));
    }

    W25xx_SectorErase(SPI2, 0);
    W25xx_PageWrite(SPI2, 0, tmpdata, 256);

    for(i = 0; i < 256; i++)
    {
        rxtmpdata[i] = 0x0;
    }

    W25xx_SequentRead(SPI2, 0, 256, rxtmpdata);
    UartSendGroup((u8*)printBuf, sprintf(printBuf, "\r\nW25xx_SequentRead:\r\n"));
    for(i = 0; i < 20; i++)
    {
        UartSendGroup((u8*)printBuf, sprintf(printBuf, "%2x ", rxtmpdata[i]));
    }
    while(1)
    {

    }
}

////////////////////////////////////////////////////////////////////////////////
/// @brief  Read ID
/// @note   None.
/// @param  None.
/// @retval None.
////////////////////////////////////////////////////////////////////////////////
void W25xx_ReadID(SPI_TypeDef* SPIx, u8 *buf)
{
    SPIM_CSLow(SPIx);

    SPIM_WriteRead(SPIx, RDID);
    buf[0] = SPIM_WriteRead(SPIx, Dummy_Byte);
    buf[1] = SPIM_WriteRead(SPIx, Dummy_Byte);
    buf[2] = SPIM_WriteRead(SPIx, Dummy_Byte);

    SPIM_CSHigh(SPIx);
}

////////////////////////////////////////////////////////////////////////////////
/// @brief  Enable Read
/// @note   None.
/// @param  None.
/// @retval None.
////////////////////////////////////////////////////////////////////////////////
void W25xx_WriteEnable(SPI_TypeDef* SPIx)
{
    SPIM_CSLow(SPIx);
    SPIM_WriteRead(SPIx, WREN);
    SPIM_CSHigh(SPIx);
}

////////////////////////////////////////////////////////////////////////////////
/// @brief  check Status
/// @note   None.
/// @param  None.
/// @retval None.
////////////////////////////////////////////////////////////////////////////////
void W25xx_checkStatus(SPI_TypeDef* SPIx)
{
    unsigned char temp;
    SPIM_CSLow(SPIx);
    SPIM_WriteRead(SPIx, RDSR);
    while(1)
    {
        temp = SPIM_WriteRead(SPIx, Dummy_Byte);
        if((temp & 0x01) == 0x0)
            break;
    }
    SPIM_CSHigh(SPIx);
}

////////////////////////////////////////////////////////////////////////////////
/// @brief  SPI Write Disable
/// @note   None.
/// @param  SPIx:SPI1/SPI2.
/// @retval None.
////////////////////////////////////////////////////////////////////////////////
void W25xx_WriteDisable(SPI_TypeDef* SPIx)
{
    SPIM_CSLow(SPIx);
    SPIM_WriteRead(SPIx, WRDI);
    SPIM_CSHigh(SPIx);
}

////////////////////////////////////////////////////////////////////////////////
/// @brief  SPI Read The Flash Data
/// @note   None.
/// @param  SPIx:SPI1/SPI2.
/// @param  Addr:address.
/// @param  NumBytes:length.
/// @param  data:data buff.
/// @retval None.
////////////////////////////////////////////////////////////////////////////////
void W25xx_SequentRead(SPI_TypeDef* SPIx, u32 Addr, u32 NumBytes, void *data)
{
    u8 *Buffer = (u8 *) data;

    SPIM_CSLow(SPIx);


    SPIM_WriteRead(SPIx, ReadData);
    SPIM_WriteRead(SPIx, Addr >> 16);
    SPIM_WriteRead(SPIx, Addr >> 8);
    SPIM_WriteRead(SPIx, Addr);

    while (NumBytes--)
    {
        //Save the data read from flash into the specified array
        *Buffer = SPIM_WriteRead(SPIx, Dummy_Byte);
        Buffer++;
    }


    SPIM_CSHigh(SPIx);

}

////////////////////////////////////////////////////////////////////////////////
/// @brief  SPI FLASH Wait For Write
/// @note   None.
/// @param  SPIx:SPI1/SPI2.
/// @retval None.
////////////////////////////////////////////////////////////////////////////////
u8 W25xx_WaitForWrite(SPI_TypeDef* SPIx)
{
    unsigned char k;
    SPIM_CSLow(SPIx);
    //Read Status Register
    SPIM_WriteRead(SPIx, ReadStatusReg);
    k = SPIM_WriteRead(SPIx, Dummy_Byte);

    SPIM_CSHigh(SPIx);
    if(k & 0x01)
        return (W25X_BUSY);
    else
        return (W25X_NotBUSY);
}

////////////////////////////////////////////////////////////////////////////////
/// @brief  SPI FLASH Write
/// @note   None.
/// @param  SPIx:SPI1/SPI2.
/// @param  Address:address.
/// @param  PageSize:page number.
/// @param  data:data buff.
/// @retval None.
////////////////////////////////////////////////////////////////////////////////
void W25xx_PageWrite(SPI_TypeDef* SPIx, unsigned long address, unsigned char* data, u32 PageSize)
{
    int i;
    unsigned char addr0, addr1, addr2;
    u8 *Buffer = data;
    u32 count = ((address / FlashSize) + 1) * FlashSize;

    //Judge flash this layer is enough space left
    while((FlashSize - address) < PageSize)
    {

        W25xx_SectorErase(SPIx, count);
        count = count + FlashSize;
        address = count;
    }

    while(1)
    {
        //Waiting for the flash is not busy state
        if(W25xx_WaitForWrite(SPIx) == W25X_NotBUSY) break;
    }

    address = address & 0xffffff00;
    addr0 = (unsigned char)(address >> 16);
    addr1 = (unsigned char)(address >> 8);
    addr2 = (unsigned char)address;


    W25xx_WriteEnable(SPIx);
    SPIM_CSLow(SPIx);

    SPIM_WriteRead(SPIx, PP);
    SPIM_WriteRead(SPIx, addr0);
    SPIM_WriteRead(SPIx, addr1);
    SPIM_WriteRead(SPIx, addr2);

    for(i = 0; i < PageSize; i++)
    {
        SPIM_WriteRead(SPIx, *Buffer);
        Buffer++;
    }
    SPIM_CSHigh(SPIx);

    W25xx_checkStatus(SPIx);
}

////////////////////////////////////////////////////////////////////////////////
/// @brief  SPI Sector Erase
/// @note   None.
/// @param  SPIx:SPI1/SPI2.
/// @param  Addr:address.
/// @retval None.
////////////////////////////////////////////////////////////////////////////////
void W25xx_SectorErase(SPI_TypeDef* SPIx, unsigned long address)
{
    unsigned char addr0, addr1, addr2;
    address = address & 0xffff0000;
    addr0 = ((unsigned char)(address >> 16)) & 0xff;
    addr1 = ((unsigned char)(address >> 8)) & 0xff;
    addr2 = ((unsigned char)address) & 0xff;

    W25xx_WriteEnable(SPIx);

    SPIM_CSLow(SPIx);

    SPIM_WriteRead(SPIx, SE);
    SPIM_WriteRead(SPIx, addr0);
    SPIM_WriteRead(SPIx, addr1);
    SPIM_WriteRead(SPIx, addr2);
    SPIM_CSHigh(SPIx);
    //Check flash current status
    W25xx_checkStatus(SPIx);
}

////////////////////////////////////////////////////////////////////////////////
/// @brief  SPI Chip Erase
/// @note   None.
/// @param  SPIx:SPI1/SPI2.
/// @retval None.
////////////////////////////////////////////////////////////////////////////////
void W25xx_ChipErase(SPI_TypeDef* SPIx)
{


    W25xx_WriteEnable(SPIx);

    SPIM_CSLow(SPIx);

    SPIM_WriteRead(SPIx, ChipErase);
    SPIM_WriteRead(SPIx, Dummy_Byte);
    SPIM_WriteRead(SPIx, Dummy_Byte);
    SPIM_WriteRead(SPIx, Dummy_Byte);
    SPIM_CSHigh(SPIx);

    W25xx_checkStatus(SPIx);
}

////////////////////////////////////////////////////////////////////////////////
/// @brief  Reset internal NSS pins for selected SPI software
/// @note   None.
/// @param  None.
/// @retval None.
////////////////////////////////////////////////////////////////////////////////
void SPIM_CSLow(SPI_TypeDef* SPIx)
{

    SPI_CSInternalSelected(SPIx, ENABLE);
}

////////////////////////////////////////////////////////////////////////////////
/// @brief  Reset internal NSS pins for selected SPI software
/// @note   None.
/// @param  None.
/// @retval None.
////////////////////////////////////////////////////////////////////////////////
void SPIM_CSHigh(SPI_TypeDef* SPIx)
{
    SPI_CSInternalSelected(SPIx, DISABLE);
}

////////////////////////////////////////////////////////////////////////////////
/// @brief  Turn off the data transmission direction of SPI in bidirectional mode
/// @note   None.
/// @param  SPIx:SPI1/SPI2.
/// @retval None.
////////////////////////////////////////////////////////////////////////////////
void SPIM_TXEn(SPI_TypeDef* SPIx)
{

    SPI_BiDirectionalLineConfig(SPIx, SPI_Direction_Tx);
}

////////////////////////////////////////////////////////////////////////////////
/// @brief  Turn off the data transmission direction of SPI in bidirectional mode
/// @note   None.
/// @param  SPIx:SPI1/SPI2.
/// @retval None.
////////////////////////////////////////////////////////////////////////////////
void SPIM_RXEn(SPI_TypeDef* SPIx)
{
    SPI_BiDirectionalLineConfig(SPIx, SPI_Direction_Rx);
}

////////////////////////////////////////////////////////////////////////////////
/// @brief  SPI FLASH Write Read
/// @note   None.
/// @param  SPIx:SPI1/SPI2.
/// @param  tx_data:TX DATA
/// @retval None.
////////////////////////////////////////////////////////////////////////////////
unsigned int SPIM_WriteRead(SPI_TypeDef* SPIx, unsigned char tx_data)
{
    //Write data to TXREG
    SPI_SendData(SPIx, tx_data);
    while(!(SPIx->SR & SPI_FLAG_TXEPT));
    while(!(SPIx->SR & SPI_CSTAT_RXAVL));
    return (u32)SPIx->RDR;

}

////////////////////////////////////////////////////////////////////////////////
/// @brief  Modifiable parameter initialization SPI.
/// @note   None.
/// @param  datawidth:data byte length.
/// @retval None.
////////////////////////////////////////////////////////////////////////////////
void SPIM_Init(SPI_TypeDef* SPIx, unsigned short spi_baud_div)
{
    SPI_InitTypeDef SPI_InitStructure;
    GPIO_InitTypeDef  GPIO_InitStructure;


    if( SPIx == SPI1 )
    {
        RCC_APB2PeriphClockCmd(RCC_APB2Periph_SPI1, ENABLE);
        RCC_AHBPeriphClockCmd(RCC_AHBPeriph_GPIOA, ENABLE);
        //SPI_NSS   PA4
        GPIO_PinAFConfig(GPIOA, GPIO_PinSource4, GPIO_AF_0);
        //SPI_SCK   PA5
        GPIO_PinAFConfig(GPIOA, GPIO_PinSource5, GPIO_AF_0);
        //SPI_MISO  PA6
        GPIO_PinAFConfig(GPIOA, GPIO_PinSource6, GPIO_AF_0);
        //SPI_MOSI  PA7
        GPIO_PinAFConfig(GPIOA, GPIO_PinSource7, GPIO_AF_0);

        GPIO_InitStructure.GPIO_Pin  = GPIO_Pin_4;
        GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
        GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP;
        GPIO_Init(GPIOA, &GPIO_InitStructure);
        GPIO_InitStructure.GPIO_Pin  = GPIO_Pin_5;
        GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
        GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP;
        GPIO_Init(GPIOA, &GPIO_InitStructure);

        GPIO_InitStructure.GPIO_Pin  = GPIO_Pin_7;
        GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
        GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP;
        GPIO_Init(GPIOA, &GPIO_InitStructure);

        GPIO_InitStructure.GPIO_Pin  = GPIO_Pin_6;
        GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IPU;
        GPIO_Init(GPIOA, &GPIO_InitStructure);
    }
    else if( SPIx == SPI2 )
    {
        RCC_APB1PeriphClockCmd(RCC_APB1Periph_SPI2, ENABLE);
        RCC_AHBPeriphClockCmd(RCC_AHBPeriph_GPIOB, ENABLE);
        //SPI2_CS    PB12
        GPIO_InitStructure.GPIO_Pin  = GPIO_Pin_12;

        GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
        GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP;
        GPIO_Init(GPIOB, &GPIO_InitStructure);
        //spi2_SCK  pb13
        GPIO_InitStructure.GPIO_Pin  = GPIO_Pin_13;
        GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
        GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP;
        GPIO_Init(GPIOB, &GPIO_InitStructure);
        //spi2_mosi  pb15
        GPIO_InitStructure.GPIO_Pin  = GPIO_Pin_15;
        GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
        GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP;
        GPIO_Init(GPIOB, &GPIO_InitStructure);
        //spi2_miso  pb14
        GPIO_InitStructure.GPIO_Pin  = GPIO_Pin_14;
        GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
        GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IPU;
        GPIO_Init(GPIOB, &GPIO_InitStructure);

        GPIO_PinAFConfig(GPIOB, GPIO_PinSource12, GPIO_AF_0);
        GPIO_PinAFConfig(GPIOB, GPIO_PinSource13, GPIO_AF_0);
        GPIO_PinAFConfig(GPIOB, GPIO_PinSource14, GPIO_AF_0);
        GPIO_PinAFConfig(GPIOB, GPIO_PinSource15, GPIO_AF_0);
    }


    SPI_InitStructure.SPI_Mode = SPI_Mode_Master;
    SPI_InitStructure.SPI_DataSize = SPI_DataSize_8b;
    SPI_InitStructure.SPI_DataWidth = 8;
    SPI_InitStructure.SPI_CPOL = SPI_CPOL_Low;
    SPI_InitStructure.SPI_CPHA = SPI_CPHA_1Edge;
    SPI_InitStructure.SPI_NSS = SPI_NSS_Soft;
    SPI_InitStructure.SPI_BaudRatePrescaler = (SPI_BaudRatePrescaler_TypeDef)spi_baud_div;
    SPI_InitStructure.SPI_FirstBit = SPI_FirstBit_MSB;
    SPI_Init(SPIx, &SPI_InitStructure);

    SPI_Cmd(SPIx, ENABLE);
    SPIM_TXEn(SPIx);
    SPIM_RXEn(SPIx);
}

////////////////////////////////////////////////////////////////////////////////
/// @brief  RCC Config Init.
/// @note   None.
/// @param  None.
/// @retval None.
////////////////////////////////////////////////////////////////////////////////
void RCC_ConfigInit(void)
{

    RCC_AHBPeriphClockCmd(RCC_AHBPeriph_GPIOA, ENABLE);
    RCC_AHBPeriphClockCmd(RCC_AHBPeriph_GPIOB, ENABLE);
    RCC_AHBPeriphClockCmd(RCC_AHBPeriph_GPIOC, ENABLE);
    RCC_AHBPeriphClockCmd(RCC_AHBPeriph_GPIOD, ENABLE);
}

////////////////////////////////////////////////////////////////////////////////
/// @brief  Serial port initialization configuration
/// @note    It must be careful of the Chip Version.
/// @param  bound: Baud rate
/// @retval None.
////////////////////////////////////////////////////////////////////////////////
void Uart_ConfigInit(u32 bound)
{
    GPIO_InitTypeDef GPIO_InitStructure;
    UART_InitTypeDef UART_InitStructure;

    RCC_APB2PeriphClockCmd(RCC_APB2Periph_UART1, ENABLE);
    RCC_AHBPeriphClockCmd(RCC_AHBPeriph_GPIOA, ENABLE);
    //GPIO mapping function
    GPIO_PinAFConfig(GPIOA, GPIO_PinSource9, GPIO_AF_1);
    GPIO_PinAFConfig(GPIOA, GPIO_PinSource10, GPIO_AF_1);
    //Baud rate
    UART_InitStructure.BaudRate = bound;
    //The word length is in 8-bit data format.
    UART_InitStructure.WordLength = UART_WordLength_8b;
    UART_InitStructure.StopBits = UART_StopBits_1;
    //No even check bit.
    UART_InitStructure.Parity = UART_Parity_No;
    //No hardware data flow control.
    UART_InitStructure.HWFlowControl = UART_HWFlowControl_None;
    UART_InitStructure.Mode = UART_Mode_Rx | UART_Mode_Tx;

    UART_Init(UART1, &UART_InitStructure);
    UART_Cmd(UART1, ENABLE);

    //UART1_TX   GPIOA.9  Reuse push-pull output
    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_9;
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP;
    GPIO_Init(GPIOA, &GPIO_InitStructure);

    //UART1_RX	  GPIOA.10  Floated input
    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_10;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_FLOATING;
    GPIO_Init(GPIOA, &GPIO_InitStructure);

}

////////////////////////////////////////////////////////////////////////////////
/// @brief  Uart Send Byte
/// @note   None.
/// @param  dat: data
/// @retval None.
////////////////////////////////////////////////////////////////////////////////
void UartSendByte(u8 dat)
{
    UART_SendData( UART1, dat);
    while(!UART_GetFlagStatus(UART1, UART_FLAG_TXEPT));
}

////////////////////////////////////////////////////////////////////////////////
/// @brief  Uart Send Group
/// @note   None.
/// @param  buf: data buff
/// @param  len: length
/// @retval None.
////////////////////////////////////////////////////////////////////////////////
void UartSendGroup(u8* buf, u16 len)
{
    while(len--)
        UartSendByte(*buf++);
}


/// @}


/// @}

/// @}
