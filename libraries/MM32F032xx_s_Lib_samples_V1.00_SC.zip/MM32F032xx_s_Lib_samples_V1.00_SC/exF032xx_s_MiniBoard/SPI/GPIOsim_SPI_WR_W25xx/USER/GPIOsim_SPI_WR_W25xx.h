////////////////////////////////////////////////////////////////////////////////
/// @file    GPIOsim_SPI_WR_W25xx.h
/// @author  AE TEAM
/// @version v1.0.0
/// @date    2019-09-20
/// @brief   THIS FILE PROVIDES ALL THE SYSTEM FIRMWARE FUNCTIONS.
////////////////////////////////////////////////////////////////////////////////
/// @attention
///
/// THE EXISTING FIRMWARE IS ONLY FOR REFERENCE, WHICH IS DESIGNED TO PROVIDE
/// CUSTOMERS WITH CODING INFORMATION ABOUT THEIR PRODUCTS SO THEY CAN SAVE
/// TIME. THEREFORE, MINDMOTION SHALL NOT BE LIABLE FOR ANY DIRECT, INDIRECT OR
/// CONSEQUENTIAL DAMAGES ABOUT ANY CLAIMS ARISING OUT OF THE CONTENT OF SUCH
/// HARDWARE AND/OR THE USE OF THE CODING INFORMATION CONTAINED HEREIN IN
/// CONNECTION WITH PRODUCTS MADE BY CUSTOMERS.
///
/// <H2><CENTER>&COPY; COPYRIGHT 2019 MINDMOTION </CENTER></H2>
////////////////////////////////////////////////////////////////////////////////


// Define to prevent recursive inclusion  --------------------------------------
#ifndef __GPIOsim_SPI_WR_W25xx_H
#define __GPIOsim_SPI_WR_W25xx_H

// Files includes  -------------------------------------------------------------
#include "types.h"
#include "HAL_device.h"
#include "HAL_conf.h"
#include "stdio.h"
#include "string.h"


////////////////////////////////////////////////////////////////////////////////
/// @defgroup MM32_Example_Layer
/// @brief MM32 Example Layer
/// @{

////////////////////////////////////////////////////////////////////////////////
/// @defgroup MM32_RESOURCE
/// @brief MM32 Examples resource modules
/// @{

////////////////////////////////////////////////////////////////////////////////
/// @defgroup MM32_Exported_Constants
/// @{

#define LED1_Port  GPIOB
#define LED1_Pin   GPIO_Pin_5
#define LED2_Port  GPIOB
#define LED2_Pin   GPIO_Pin_4
#define LED3_Port  GPIOB
#define LED3_Pin   GPIO_Pin_3
#define LED4_Port  GPIOA
#define LED4_Pin   GPIO_Pin_15

#define LED1_ON()  GPIO_ResetBits(LED1_Port,LED1_Pin)
#define LED1_OFF()  GPIO_SetBits(LED1_Port,LED1_Pin)
#define LED1_TOGGLE()  (GPIO_ReadOutputDataBit(LED1_Port,LED1_Pin))?(GPIO_ResetBits(LED1_Port,LED1_Pin)):(GPIO_SetBits(LED1_Port,LED1_Pin))



#define LED2_ON()  GPIO_ResetBits(LED2_Port,LED2_Pin)
#define LED2_OFF()  GPIO_SetBits(LED2_Port,LED2_Pin)
#define LED2_TOGGLE()  (GPIO_ReadOutputDataBit(LED2_Port,LED2_Pin))?(GPIO_ResetBits(LED2_Port,LED2_Pin)):(GPIO_SetBits(LED2_Port,LED2_Pin))


#define LED3_ON()  GPIO_ResetBits(LED3_Port,LED3_Pin)
#define LED3_OFF()  GPIO_SetBits(LED3_Port,LED3_Pin)
#define LED3_TOGGLE()  (GPIO_ReadOutputDataBit(LED3_Port,LED3_Pin))?(GPIO_ResetBits(LED3_Port,LED3_Pin)):(GPIO_SetBits(LED3_Port,LED3_Pin))


#define LED4_ON()  GPIO_ResetBits(LED4_Port,LED4_Pin)
#define LED4_OFF()  GPIO_SetBits(LED4_Port,LED4_Pin)
#define LED4_TOGGLE()  (GPIO_ReadOutputDataBit(LED4_Port,LED4_Pin))?(GPIO_ResetBits(LED4_Port,LED4_Pin)):(GPIO_SetBits(LED4_Port,LED4_Pin))

#define SW1_GPIO_Port  GPIOC
#define SW1_Pin   GPIO_Pin_13
#define SW2_GPIO_Port  GPIOA
#define SW2_Pin   GPIO_Pin_0
#define SW3_GPIO_Port  GPIOB
#define SW3_Pin   GPIO_Pin_10
#define SW4_GPIO_Port  GPIOB
#define SW4_Pin   GPIO_Pin_11

#define KEY1                    GPIO_ReadInputDataBit(SW1_GPIO_Port,SW1_Pin)    //read key1
#define WK_UP                   GPIO_ReadInputDataBit(SW2_GPIO_Port,SW2_Pin)    //read key2 
#define KEY3                    GPIO_ReadInputDataBit(SW3_GPIO_Port,SW3_Pin)    //read key3
#define KEY4                    GPIO_ReadInputDataBit(SW4_GPIO_Port,SW4_Pin)    //read key4

#define KEY1_PRES               1                                               //KEY1 
#define WKUP_PRES               2                                               //WK_UP  
#define KEY3_PRES               3                                               //KEY3 
#define KEY4_PRES               4                                               //KEY4 


#define SectorErase           0x20
#define PP                    0x02
#define ReadData              0x03
#define ChipErase             0xC7
#define RDSR                  0x05
#define Dummy_Byte            0x00
#define W25X_BUSY             0
#define W25X_NotBUSY          1
#define FlashSize             0x400
#define ReadStatusReg         0x05


#define READ                  0x03
#define FAST_READ             0x0B
#define RDID                  0x9F
#define WREN                  0x06
#define WRDI                  0x04
#define SE                    0xD8
#define BE                    0xC7
#define PP                    0x02
#define RDSR                  0x05
#define WRSR                  0x01
#define DP                    0xB9
#define RES                   0xAB
#define GPIO_Pin_0_2  GPIO_Pin_2
#define CS_GPIOx              GPIOB
#define CS_Pin_x              GPIO_Pin_12
#define RCC_CS                RCC_AHBPeriph_GPIOB

#define CLK_GPIOx             GPIOB
#define CLK_Pin_x             GPIO_Pin_13
#define RCC_CLK               RCC_AHBPeriph_GPIOB

#define MOSI_GPIOx            GPIOB
#define MOSI_Pin_x            GPIO_Pin_15
#define RCC_MOSI              RCC_AHBPeriph_GPIOB


#define MISO_GPIOx            GPIOB
#define MISO_Pin_x            GPIO_Pin_14
#define RCC_MISO              RCC_AHBPeriph_GPIOB


#define MSB   1                                                                 // Open this MSB==1 set MSB enable, otherwise LSB
#define BITLENGTH   8                                                           //bits 4~16
#define SPI_MODE 3

#if    (SPI_MODE == 0)                                                          //(SPI_MODE == 1)
#define CPOL 0                                                                  // Open this CPOL=0
#define CPHA 0                                                                  // Open this CPHA=0
#elif  (SPI_MODE == 1)                                                          //(SPI_MODE == 1)
#define CPOL 1                                                                  // Open this CPOL=1
#define CPHA 0                                                                  // Open this CPHA=0
#elif  (SPI_MODE == 2)                                                          //(SPI_MODE == 2)
#define CPOL 0                                                                  // Open this CPOL=0
#define CPHA_1                                                                  // Open this CPHA=1
#else                                                                           //(SPI_MODE == 3)
#define CPOL 1                                                                  // Open this CPOL=1
#define CPHA 1                                                                  // Open this CPHA=1
#endif


//----------------- User Config -----------------//
#define CS_L           {CS_GPIOx->BRR = CS_Pin_x;}                              //GPIO_ResetBits(CS_GPIOx,CS_Pin_x)
#define CS_H           {CS_GPIOx->BSRR = CS_Pin_x;}                             //GPIO_SetBits(CS_GPIOx,CS_Pin_x)
#define SCK_L          {CLK_GPIOx->BRR = CLK_Pin_x;}                            //GPIO_ResetBits(CLK_GPIOx,CLK_Pin_x)
#define SCK_H          {CLK_GPIOx->BSRR = CLK_Pin_x;}                           //GPIO_SetBits(CLK_GPIOx,CLK_Pin_x)
#define MOSI_L         {MOSI_GPIOx->BRR = MOSI_Pin_x;}                          //GPIO_ResetBits(MOSI_GPIOx,MOSI_Pin_x)
#define MOSI_H         {MOSI_GPIOx->BSRR = MOSI_Pin_x;}                         //GPIO_SetBits(MOSI_GPIOx,MOSI_Pin_x)
#define MISO_IN        (MISO_GPIOx->IDR&MISO_Pin_x)                             //GPIO_ReadInputData(MISO_GPIOx,MISO_Pin_x)

/// @}

////////////////////////////////////////////////////////////////////////////////
/// @defgroup MM32_Exported_Enumeration
/// @{

////////////////////////////////////////////////////////////////////////////////
/// @brief XXXX enumerate definition.
/// @anchor XXXX
////////////////////////////////////////////////////////////////////////////////
typedef enum
{
    LED1,
    LED2,
    LED3,
    LED4
} Led_TypeDef;


/// @}

////////////////////////////////////////////////////////////////////////////////
/// @defgroup MM32_Exported_Variables
/// @{
#ifdef _SYSTICK_C_
#define GLOBAL







#else
#define GLOBAL extern







#endif

GLOBAL __IO  u32 TimingDelay;



#undef GLOBAL

/// @}


////////////////////////////////////////////////////////////////////////////////
/// @defgroup MM32_Exported_Functions
/// @{



void SPIM_Init(unsigned short spi_baud_div);

void SPI_Start(void);
void SPI_Stop(void);

void SPIM_Test(void);

void LED_Init(void);


/// @}


/// @}

/// @}


////////////////////////////////////////////////////////////////////////////////
#endif
////////////////////////////////////////////////////////////////////////////////
