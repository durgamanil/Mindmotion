////////////////////////////////////////////////////////////////////////////////
/// @file    ex_SPI_poll_ex25xxSPI2.c
/// @author  AE TEAM
/// @version v1.0.0
/// @date    2019-09-20
/// @brief   Using GPIO to simulate SPI.If read and
///          write data are consistent, the LED will be extinguished.
////////////////////////////////////////////////////////////////////////////////
/// @attention
///
/// THE EXISTING FIRMWARE IS ONLY FOR REFERENCE, WHICH IS DESIGNED TO PROVIDE
/// CUSTOMERS WITH CODING INFORMATION ABOUT THEIR PRODUCTS SO THEY CAN SAVE
/// TIME. THEREFORE, MINDMOTION SHALL NOT BE LIABLE FOR ANY DIRECT, INDIRECT OR
/// CONSEQUENTIAL DAMAGES ABOUT ANY CLAIMS ARISING OUT OF THE CONTENT OF SUCH
/// HARDWARE AND/OR THE USE OF THE CODING INFORMATION CONTAINED HEREIN IN
/// CONNECTION WITH PRODUCTS MADE BY CUSTOMERS.
///
/// <H2><CENTER>&COPY; COPYRIGHT 2019 MINDMOTION </CENTER></H2>
////////////////////////////////////////////////////////////////////////////////

#include "GPIOsim_SPI_WR_W25xx.h"


unsigned char tmpdata[256];
unsigned char rxtmpdata[256];
extern u8 SPIMReadWrite8Bits(u8 );

////////////////////////////////////////////////////////////////////////////////
/// @brief  This function is main entrance.
/// @param  None.
/// @retval  0.
////////////////////////////////////////////////////////////////////////////////
int main(void)
{
    LED_Init();
    SPIM_Test();
    while(1)
    {

    }
}

////////////////////////////////////////////////////////////////////////////////
/// @brief  Initialization  GPIO
/// @note   None.
/// @param  None.
/// @retval None.
////////////////////////////////////////////////////////////////////////////////
void SPIM_SimPinConfig(void)
{
    GPIO_InitTypeDef  GPIO_InitStructure;
    RCC_AHBPeriphClockCmd(RCC_AHBPeriph_GPIOB, ENABLE);
    //spi2_cs  pb12
    GPIO_InitStructure.GPIO_Pin  = GPIO_Pin_12;
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
    GPIO_Init(GPIOB, &GPIO_InitStructure);
    //spi2_sck  pb13
    GPIO_InitStructure.GPIO_Pin  = GPIO_Pin_13;
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
    GPIO_Init(GPIOB, &GPIO_InitStructure);
    //spi2_mosi  pb15
    GPIO_InitStructure.GPIO_Pin  = GPIO_Pin_15;
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
    GPIO_Init(GPIOB, &GPIO_InitStructure);
    //spi2_miso  pb14
    GPIO_InitStructure.GPIO_Pin  = GPIO_Pin_14;
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_FLOATING;
    GPIO_Init(GPIOB, &GPIO_InitStructure);


}

////////////////////////////////////////////////////////////////////////////////
/// @brief  start Initialization  GPIO
/// @note   None.
/// @param  None.
/// @retval None.
////////////////////////////////////////////////////////////////////////////////
void SPI_GPIO_Config(void)
{
    SPIM_SimPinConfig();
    SPI_Stop();
}

////////////////////////////////////////////////////////////////////////////////
/// @brief  start flag
/// @note   None.
/// @param  None.
/// @retval None.
////////////////////////////////////////////////////////////////////////////////
void SPI_Start(void)
{
    MOSI_L;
#if (CPOL == 0)
    SCK_L;
    CS_L;
#else
    SCK_H;
    CS_L;
#endif
}

////////////////////////////////////////////////////////////////////////////////
/// @brief  End flag
/// @note   None.
/// @param  None.
/// @retval None.
////////////////////////////////////////////////////////////////////////////////
void SPI_Stop(void)
{
#if (CPOL == 0)
    SCK_L;
    CS_H;
#else
    SCK_H;
    CS_H;
#endif
    MOSI_L;
}

////////////////////////////////////////////////////////////////////////////////
/// @brief  Select the Macro definition of SPI to select the mode
/// @note   //bits BITLENGTH = 1~8.
/// @param  senddata:TX data.
/// @retval RX data.
////////////////////////////////////////////////////////////////////////////////
u8 SPIMReadWrite8Bits(u8 senddata)
{
    unsigned char i = 0;
    unsigned char recvdata = 0x00;

    for(i = 0; i < BITLENGTH; i++)
    {
#if (((CPOL == 0)&&(CPHA == 0))||((CPOL == 1)&&(CPHA == 1)))
        SCK_L;
#else
        SCK_H;
#endif
#if ( MSB ==1)
        // Tx data use MSB mode
        if(senddata & ((0x01) << (BITLENGTH - 1)))
        {
            MOSI_H;
        }
        else
        {
            MOSI_L;
        }
        senddata <<= 1;

#else
        // Tx data use LSB mode
        if(senddata & 0x1)
        {
            MOSI_H;
        }
        else
        {
            MOSI_L;
        }
        senddata >>= 1;
#endif

#if (((CPOL == 0)&&(CPHA == 0))||((CPOL == 1)&&(CPHA == 1)))
        SCK_H;
#else
        SCK_L;
#endif

#if ( MSB ==1)               // Rx data use MSB mode
        recvdata <<= 1 ;
        if((MISO_IN) != 0)
        {
            recvdata++;
        }
#else
        if((MISO_IN) != 0)
        {
            recvdata = recvdata + (1 << i);// Rx data use LSB mode
        }
#endif
    }

    return recvdata;
}


////////////////////////////////////////////////////////////////////////////////
/// @brief  Select the Macro definition of SPI to select the mode
/// @note   bits BITLENGTH = 9~16.
/// @param  senddata:TX data.
/// @retval RX data.
////////////////////////////////////////////////////////////////////////////////
u16 SPIMReadWrite16Bits(u16 senddata)
{
    unsigned char i = 0;
    u16 recvdata = 0x00;

    for(i = 0; i < BITLENGTH; i++)
    {
#if (((CPOL == 0)&&(CPHA == 0))||((CPOL == 1)&&(CPHA == 1)))
        SCK_L;
#else
        SCK_H;
#endif
#if ( MSB ==1)
        // Tx data use MSB mode
        if(senddata & ((0x01) << (BITLENGTH - 1)))
        {
            MOSI_H;
        }
        else
        {
            MOSI_L;
        }
        senddata <<= 1;

#else
        // Tx data use LSB mode
        if(senddata & 0x1)
        {
            MOSI_H;
        }
        else
        {
            MOSI_L;
        }
        senddata >>= 1;
#endif

#if (((CPOL == 0)&&(CPHA == 0))||((CPOL == 1)&&(CPHA == 1)))
        SCK_H;
#else
        SCK_L;
#endif

#if ( MSB ==1)
        // Rx data use MSB mode
        recvdata <<= 1 ;
        if((MISO_IN) != 0)
        {
            recvdata++;
        }
#else
        if((MISO_IN) != 0)
        {
            // Rx data use LSB mode
            recvdata = recvdata + (1 << i);
        }
#endif
    }

    return recvdata;
}

////////////////////////////////////////////////////////////////////////////////
/// @brief  GPIO CONFIG
/// @note   None.
/// @param  spi_baud_div:Not use.
/// @retval None.
////////////////////////////////////////////////////////////////////////////////
void SPIM_Init(unsigned short spi_baud_div)
{
    SPI_GPIO_Config();
}


////////////////////////////////////////////////////////////////////////////////
/// @brief  Reset internal NSS pins for selected SPI software
/// @note   None.
/// @param  None.
/// @retval None.
////////////////////////////////////////////////////////////////////////////////
void SPIM_CSLow()
{
    //Spi cs assign to this pin,select
    SPI_Start();
}

////////////////////////////////////////////////////////////////////////////////
/// @brief  Reset internal NSS pins for selected SPI software
/// @note   None.
/// @param  None.
/// @retval None.
////////////////////////////////////////////////////////////////////////////////
void SPIM_CSHigh()
{
    //Spi cs release
    SPI_Stop();
}

////////////////////////////////////////////////////////////////////////////////
/// @brief  Transmit and receive data through peripheral SPIx for full duplex mode
///         (simultaneous transceiver)
/// @note   None.
/// @param  tx_data:send data.
/// @retval None.
////////////////////////////////////////////////////////////////////////////////
u8 SPIMReadWriteByte(u8 tx_data)
{
    return ((u8)SPIMReadWrite8Bits((u8)tx_data));
}

////////////////////////////////////////////////////////////////////////////////
/// @brief  Read ID
/// @note   None.
/// @param  None
/// @retval None.
////////////////////////////////////////////////////////////////////////////////
void SPIM_ReadID()
{
    __IO unsigned char temp[5];
    unsigned int i;

    SPIM_CSLow();
    SPIMReadWriteByte(RDID);

    for(i = 0; i < 3; i++)
    {
        temp[i] = SPIMReadWriteByte(0x01);
    }
    SPIM_CSHigh();
}

////////////////////////////////////////////////////////////////////////////////
/// @brief  Turn off the data transmission direction of SPI in bidirectional mode
/// @note   None.
/// @param  SPIx:SPI1/SPI2.
/// @retval None.
////////////////////////////////////////////////////////////////////////////////
void SPIM_WriteEnable()
{
    SPIM_CSLow();
    SPIMReadWriteByte(WREN);
    SPIM_CSHigh();
}

////////////////////////////////////////////////////////////////////////////////
/// @brief  check Status
/// @note   None.
/// @param  SPIx:SPI1/SPI2.
/// @retval None.
////////////////////////////////////////////////////////////////////////////////
void SPIM_checkStatus()
{
    unsigned char temp;
    SPIM_CSLow();
    SPIMReadWriteByte(RDSR);
    while(1)
    {
        temp = SPIMReadWriteByte(0x00);
        if((temp & 0x01) == 0x0)
            break;
    }
    SPIM_CSHigh();
}

////////////////////////////////////////////////////////////////////////////////
/// @brief  disable TX
/// @note   None.
/// @param  None.
/// @retval None.
////////////////////////////////////////////////////////////////////////////////
void SPIM_WriteDisable()
{
    SPIM_CSLow();
    SPIMReadWriteByte(WRDI);
    SPIM_CSHigh();
}

////////////////////////////////////////////////////////////////////////////////
/// @brief  SPI FLASH Read
/// @note   page = 256 bytes.
/// @param  Address:address.
/// @param  number:length.
/// @param  p:data buff.
/// @retval None.
////////////////////////////////////////////////////////////////////////////////
void SPIM_PageRead(unsigned long address, unsigned char *p, unsigned int number)
{
    unsigned char addr0, addr1, addr2;
    unsigned int i;
    //page address
    address = address & 0xffffff00;
    addr0 = (unsigned char)(address >> 16);
    addr1 = (unsigned char)(address >> 8);
    addr2 = (unsigned char)address;

    SPIM_CSLow();

    SPIMReadWriteByte(READ);
    SPIMReadWriteByte(addr0);
    SPIMReadWriteByte(addr1);
    SPIMReadWriteByte(addr2);

    for(i = 0; i < number; i++)
    {
        rxtmpdata[i] = SPIMReadWriteByte(0x00);
    }

    SPIM_CSHigh();
}


////////////////////////////////////////////////////////////////////////////////
/// @brief  SPI FLASH write
/// @note   page = 256 bytes.
/// @param  Address:address.
/// @param  number:length.
/// @param  p:data buff.
/// @retval None.
////////////////////////////////////////////////////////////////////////////////
void SPIM_PageProgram(unsigned long address, unsigned char *p, unsigned int number)
{
    unsigned int j;
    unsigned char addr0, addr1, addr2;
    //page address
    address = address & 0xffffff00;
    addr0 = (unsigned char)(address >> 16);
    addr1 = (unsigned char)(address >> 8);
    addr2 = (unsigned char)address;

    SPIM_WriteEnable();
    //Spi cs assign to this pin,select
    SPIM_CSLow();
    SPIMReadWriteByte(PP);
    SPIMReadWriteByte(addr0);
    SPIMReadWriteByte(addr1);
    SPIMReadWriteByte(addr2);
    for(j = 0; j < number; j++)
    {
        SPIMReadWriteByte(*p);
        p++;
    }

    SPIM_CSHigh();

    SPIM_checkStatus();
}

////////////////////////////////////////////////////////////////////////////////
/// @brief  SPI Sector Erase
/// @note   None.
/// @param  Addr:address.
/// @retval None.
////////////////////////////////////////////////////////////////////////////////
void SPIM_SectorErase(unsigned long address)
{
    unsigned char addr0, addr1, addr2;
    address = address & 0xffff0000;
    addr0 = ((unsigned char)(address >> 16)) & 0xff;
    addr1 = ((unsigned char)(address >> 8)) & 0xff;
    addr2 = ((unsigned char)address) & 0xff;

    SPIM_WriteEnable();
    SPIM_checkStatus();
    //Spi cs assign to this pin,select
    SPIM_CSLow();

    SPIMReadWriteByte(SE);
    SPIMReadWriteByte(addr0);
    SPIMReadWriteByte(addr1);
    SPIMReadWriteByte(addr2);
    SPIM_CSHigh();

    SPIM_checkStatus();
}

////////////////////////////////////////////////////////////////////////////////
/// @brief  SPI Sector Erase
/// @note   None.
/// @param  None.
/// @retval None.
////////////////////////////////////////////////////////////////////////////////
void SPIM_BlockErase()
{
    SPIM_WriteEnable();
    //Spi cs assign to this pin,select
    SPIM_CSLow();

    SPIMReadWriteByte(BE);

    SPIM_CSHigh();

    SPIM_checkStatus();
}

////////////////////////////////////////////////////////////////////////////////
/// @brief  STOP TX/RX
/// @note   None.
/// @param  None.
/// @retval None.
////////////////////////////////////////////////////////////////////////////////
void SPIM_Close()
{
    SPIM_CSHigh();
    SPIMReadWriteByte(0x01);
}

////////////////////////////////////////////////////////////////////////////////
/// @brief  Test program, using serial port to print 256 pages of data
/// @note   None.
/// @param  None.
/// @retval None.
////////////////////////////////////////////////////////////////////////////////
void SPIM_Test(void)
{
    int result = 0;
    unsigned int i;


    SPIM_Init(0x8);

    SPIM_ReadID();
    for(i = 0; i < 5; i++)
    {
        SPIM_ReadID();
    }
    SPIM_SectorErase(0x400);
    for(i = 0; i < 256; i++)
    {
        rxtmpdata[i] = 0x0;
    }
    SPIM_PageRead(0x400, rxtmpdata, 256);
    for(i = 0; i < 256; i++)
    {
        tmpdata[i] = i;
    }
    SPIM_PageProgram(0x400, tmpdata, 256);

    for(i = 0; i < 256; i++)
    {
        rxtmpdata[i] = 0x0;
    }
    SPIM_PageRead(0x400, rxtmpdata, 256);

    for(i = 0; i < 256; i++)
    {
        if(rxtmpdata[i] != tmpdata[i])
        {
            result = 1;
            break;
        }
    }
    SPIM_SectorErase(0x400);
    for(i = 0; i < 256; i++)
    {
        rxtmpdata[i] = 0x0;
    }
    SPIM_PageRead(0x400, rxtmpdata, 256);
    for(i = 0; i < 256; i++)
    {
        tmpdata[i] = 2 * i;
    }
    SPIM_PageProgram(0x400, tmpdata, 256);

    for(i = 0; i < 256; i++)
    {
        rxtmpdata[i] = 0x0;
    }
    SPIM_PageRead(0x400, rxtmpdata, 256);

    for(i = 0; i < 256; i++)
    {
        if(rxtmpdata[i] != tmpdata[i])
        {
            result = 1;
            break;
        }
    }
    if ( result == 1)
    {
        LED1_ON();
        LED2_ON();
        LED3_ON();
        LED4_ON();
    }
    else
    {
        LED1_OFF();
        LED2_OFF();
        LED3_OFF();
        LED4_OFF();
    }
}

////////////////////////////////////////////////////////////////////////////////
/// @brief  RCC clock set
/// @note   None.
/// @param  GPIOx:GPIOA/GPIOB/GPIOC/GPIOD...
/// @param  NewState:Enable/Disable
/// @retval None.
////////////////////////////////////////////////////////////////////////////////
void GPIO_Clock_Set(GPIO_TypeDef* GPIOx, FunctionalState NewState)
{

    if(GPIOx == GPIOA)
    {
        RCC_AHBPeriphClockCmd(RCC_AHBPeriph_GPIOA, NewState);
    }
    if(GPIOx == GPIOB)
    {
        RCC_AHBPeriphClockCmd(RCC_AHBPeriph_GPIOB, NewState);
    }
    if(GPIOx == GPIOC)
    {
        RCC_AHBPeriphClockCmd(RCC_AHBPeriph_GPIOC, NewState);
    }
    if(GPIOx == GPIOD)
    {
        RCC_AHBPeriphClockCmd(RCC_AHBPeriph_GPIOD, NewState);
    }
}

////////////////////////////////////////////////////////////////////////////////
/// @brief  Initialization LED
/// @note   None.
/// @param  None.
/// @retval None.
////////////////////////////////////////////////////////////////////////////////
void LED_Init(void)
{

    GPIO_InitTypeDef  GPIO_InitStructure;

    GPIO_Clock_Set(GPIOA, ENABLE);
    GPIO_Clock_Set(GPIOB, ENABLE);
    GPIO_InitStructure.GPIO_Pin  =  GPIO_Pin_15;
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
    GPIO_Init(GPIOA, &GPIO_InitStructure);

    GPIO_InitStructure.GPIO_Pin  = GPIO_Pin_3 | GPIO_Pin_4 | GPIO_Pin_5;
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
    GPIO_Init(GPIOB, &GPIO_InitStructure);

    LED1_ON();
    LED2_ON();
    LED3_ON();
    LED4_ON();
    LED1_TOGGLE();
    LED2_TOGGLE();
    LED3_TOGGLE();
    LED4_TOGGLE();

    LED1_TOGGLE();
    LED2_TOGGLE();
    LED3_TOGGLE();
    LED4_TOGGLE();
}

/// @}


/// @}

/// @}

