////////////////////////////////////////////////////////////////////////////////
/// @file    ex_SPI_1_32bit_TxRxLoop.c
/// @author  AE TEAM
/// @version v1.0.0
/// @date    2019-09-20
/// @brief   Connect PB14 PB15 with DuPont Line.
////////////////////////////////////////////////////////////////////////////////
/// @attention
///
/// THE EXISTING FIRMWARE IS ONLY FOR REFERENCE, WHICH IS DESIGNED TO PROVIDE
/// CUSTOMERS WITH CODING INFORMATION ABOUT THEIR PRODUCTS SO THEY CAN SAVE
/// TIME. THEREFORE, MINDMOTION SHALL NOT BE LIABLE FOR ANY DIRECT, INDIRECT OR
/// CONSEQUENTIAL DAMAGES ABOUT ANY CLAIMS ARISING OUT OF THE CONTENT OF SUCH
/// HARDWARE AND/OR THE USE OF THE CODING INFORMATION CONTAINED HEREIN IN
/// CONNECTION WITH PRODUCTS MADE BY CUSTOMERS.
///
/// <H2><CENTER>&COPY; COPYRIGHT 2019 MINDMOTION </CENTER></H2>
////////////////////////////////////////////////////////////////////////////////


#include "ex_SPI_1_32bit_TxRxLoop.h"

typedef enum
{
    SPIMODE0,
    SPIMODE3
} SPIMODDE;
//#define SPIUSELSB


char printBuf[100];
unsigned char tmpdata[256];
unsigned char rxtmpdata[256];

#define SPI_DataWidth_8b                  ((uint16_t)0x0008)

#define READ        	0x03
#define FAST_READ   	0x0B
#define RDID        	0x9F
#define WREN            0x06
#define WRDI            0x04
#define SE              0xD8
#define BE              0xC7
#define PP              0x02
#define RDSR            0x05
#define WRSR            0x01
#define DP              0xB9
#define RES             0xAB

////////////////////////////////////////////////////////////////////////////////
/// @brief  initialize SPI1 MODE1(master)
/// @note   None.
/// @param  None.
/// @retval None.
////////////////////////////////////////////////////////////////////////////////
void SPI1MasterPinCfgMode1(void)
{

    GPIO_InitTypeDef  GPIO_InitStructure;
    RCC_AHBPeriphClockCmd(RCC_AHBPeriph_GPIOA, ENABLE);
    GPIO_PinAFConfig(GPIOA, GPIO_PinSource4, GPIO_AF_0);
    GPIO_PinAFConfig(GPIOA, GPIO_PinSource5, GPIO_AF_0);
    GPIO_PinAFConfig(GPIOA, GPIO_PinSource6, GPIO_AF_0);
    GPIO_PinAFConfig(GPIOA, GPIO_PinSource7, GPIO_AF_0);

    GPIO_InitStructure.GPIO_Pin  = GPIO_Pin_4;
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP;
    GPIO_Init(GPIOA, &GPIO_InitStructure);

    GPIO_InitStructure.GPIO_Pin  = GPIO_Pin_5;
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP;
    GPIO_Init(GPIOA, &GPIO_InitStructure);

    GPIO_InitStructure.GPIO_Pin  = GPIO_Pin_7;
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP;
    GPIO_Init(GPIOA, &GPIO_InitStructure);

    GPIO_InitStructure.GPIO_Pin  = GPIO_Pin_6;
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IPU;
    GPIO_Init(GPIOA, &GPIO_InitStructure);
}
////////////////////////////////////////////////////////////////////////////////
/// @brief  initialize SPI2 MODE1(master)
/// @note   None.
/// @param  None.
/// @retval None.
////////////////////////////////////////////////////////////////////////////////
void SPI2MasterPinCfgMode1(void)
{
    GPIO_InitTypeDef  GPIO_InitStructure;

    RCC_AHBPeriphClockCmd(RCC_AHBPeriph_GPIOB, ENABLE);

    GPIO_PinAFConfig(GPIOB, GPIO_PinSource12, GPIO_AF_0);
    GPIO_PinAFConfig(GPIOB, GPIO_PinSource13, GPIO_AF_0);
    GPIO_PinAFConfig(GPIOB, GPIO_PinSource14, GPIO_AF_0);
    GPIO_PinAFConfig(GPIOB, GPIO_PinSource15, GPIO_AF_0);

    GPIO_InitStructure.GPIO_Pin  = GPIO_Pin_12;
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP;
    GPIO_Init(GPIOB, &GPIO_InitStructure);

    GPIO_InitStructure.GPIO_Pin  = GPIO_Pin_13;
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP;
    GPIO_Init(GPIOB, &GPIO_InitStructure);

    GPIO_InitStructure.GPIO_Pin  = GPIO_Pin_15;
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP;
    GPIO_Init(GPIOB, &GPIO_InitStructure);

    GPIO_InitStructure.GPIO_Pin  = GPIO_Pin_14;
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IPU;
    GPIO_Init(GPIOB, &GPIO_InitStructure);

}
////////////////////////////////////////////////////////////////////////////////
/// @brief  initialize SPI2 MODE2(master)
/// @note   None.
/// @param  None.
/// @retval None.
////////////////////////////////////////////////////////////////////////////////
void SPI2MasterPinCfgMode2(void)
{
    GPIO_InitTypeDef  GPIO_InitStructure;

    RCC_AHBPeriphClockCmd(RCC_AHBPeriph_GPIOB, ENABLE);

    GPIO_PinAFConfig(GPIOB, GPIO_PinSource12, GPIO_AF_1);
    GPIO_PinAFConfig(GPIOB, GPIO_PinSource13, GPIO_AF_1);
    GPIO_PinAFConfig(GPIOB, GPIO_PinSource14, GPIO_AF_1);
    GPIO_PinAFConfig(GPIOB, GPIO_PinSource15, GPIO_AF_1);


    GPIO_InitStructure.GPIO_Pin  = GPIO_Pin_12;
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP;
    GPIO_Init(GPIOB, &GPIO_InitStructure);

    GPIO_InitStructure.GPIO_Pin  = GPIO_Pin_13;
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IPU;
    GPIO_Init(GPIOB, &GPIO_InitStructure);

    GPIO_InitStructure.GPIO_Pin  = GPIO_Pin_15;
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP;
    GPIO_Init(GPIOB, &GPIO_InitStructure);

    GPIO_InitStructure.GPIO_Pin  = GPIO_Pin_14;
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP;
    GPIO_Init(GPIOB, &GPIO_InitStructure);

}
////////////////////////////////////////////////////////////////////////////////
/// @brief  initialize SPI2 MODE3(master)
/// @note   None.
/// @param  None.
/// @retval None.
////////////////////////////////////////////////////////////////////////////////
void SPI2MasterPinCfgMode3(void)
{
    GPIO_InitTypeDef  GPIO_InitStructure;

    RCC_AHBPeriphClockCmd(RCC_AHBPeriph_GPIOB, ENABLE);
    GPIO_PinAFConfig(GPIOB, GPIO_PinSource12, GPIO_AF_3);
    GPIO_PinAFConfig(GPIOB, GPIO_PinSource13, GPIO_AF_3);
    GPIO_PinAFConfig(GPIOB, GPIO_PinSource14, GPIO_AF_3);
    GPIO_PinAFConfig(GPIOB, GPIO_PinSource15, GPIO_AF_3);

    RCC_APB1PeriphClockCmd(RCC_APB1Periph_SPI2, ENABLE);
    GPIO_InitStructure.GPIO_Pin  = GPIO_Pin_12;
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP;
    GPIO_Init(GPIOB, &GPIO_InitStructure);

    GPIO_InitStructure.GPIO_Pin  = GPIO_Pin_13;
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP;
    GPIO_Init(GPIOB, &GPIO_InitStructure);

    GPIO_InitStructure.GPIO_Pin  = GPIO_Pin_15;
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IPU;
    GPIO_Init(GPIOB, &GPIO_InitStructure);

    GPIO_InitStructure.GPIO_Pin  = GPIO_Pin_14;
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP;
    GPIO_Init(GPIOB, &GPIO_InitStructure);
}
////////////////////////////////////////////////////////////////////////////////
/// @brief  initialize SPI2 MODE4(master)
/// @note   None.
/// @param  None.
/// @retval None.
////////////////////////////////////////////////////////////////////////////////
void SPI2MasterPinCfgMode4(void)
{
    GPIO_InitTypeDef  GPIO_InitStructure;

    RCC_AHBPeriphClockCmd(RCC_AHBPeriph_GPIOB, ENABLE);
    GPIO_PinAFConfig(GPIOB, GPIO_PinSource12, GPIO_AF_4);
    GPIO_PinAFConfig(GPIOB, GPIO_PinSource13, GPIO_AF_4);
    GPIO_PinAFConfig(GPIOB, GPIO_PinSource14, GPIO_AF_4);
    GPIO_PinAFConfig(GPIOB, GPIO_PinSource15, GPIO_AF_4);

    RCC_APB1PeriphClockCmd(RCC_APB1Periph_SPI2, ENABLE);
    GPIO_InitStructure.GPIO_Pin  = GPIO_Pin_12;
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IPU;
    GPIO_Init(GPIOB, &GPIO_InitStructure);

    GPIO_InitStructure.GPIO_Pin  = GPIO_Pin_13;
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP;
    GPIO_Init(GPIOB, &GPIO_InitStructure);

    GPIO_InitStructure.GPIO_Pin  = GPIO_Pin_15;
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP;
    GPIO_Init(GPIOB, &GPIO_InitStructure);

    GPIO_InitStructure.GPIO_Pin  = GPIO_Pin_14;
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP;
    GPIO_Init(GPIOB, &GPIO_InitStructure);
}

////////////////////////////////////////////////////////////////////////////////
/// @brief  Turn off the data transmission direction of SPI in bidirectional mode
/// @note   None.
/// @param  SPIx:SPI1/SPI2.
/// @retval None.
////////////////////////////////////////////////////////////////////////////////
void SPIM_TXEn(SPI_TypeDef* SPIx)
{
    //Transmit Enable bit TXEN
    SPI_BiDirectionalLineConfig(SPIx, SPI_Direction_Tx);
}
////////////////////////////////////////////////////////////////////////////////
/// @brief  Turn off the data transmission direction of SPI in bidirectional mode
/// @note   None.
/// @param  SPIx:SPI1/SPI2.
/// @retval None.
////////////////////////////////////////////////////////////////////////////////
void SPIM_RXEn(SPI_TypeDef* SPIx)
{
    //enable RXEN
    SPI_BiDirectionalLineConfig(SPIx, SPI_Direction_Rx);
}

////////////////////////////////////////////////////////////////////////////////
/// @brief  Reset internal NSS pins for selected SPI software
/// @note   None.
/// @param  None.
/// @retval None.
////////////////////////////////////////////////////////////////////////////////
void SPIM_CSLow()
{
    //Spi cs assign to this pin,select
    SPI_CSInternalSelected(SPI2, ENABLE);
}

////////////////////////////////////////////////////////////////////////////////
/// @brief  Reset internal NSS pins for selected SPI software
/// @note   None.
/// @param  None.
/// @retval None.
////////////////////////////////////////////////////////////////////////////////
void SPIM_CSHigh()
{
    //Spi cs release
    SPI_CSInternalSelected(SPI2, DISABLE);
}

////////////////////////////////////////////////////////////////////////////////
/// @brief  Initializes the SPIx peripheral according to the specified
///         parameters in the SPI_InitStruct
/// @note   None.
/// @param  SPIx: where x can be 0, 1 to select the SPI peripheral.
/// @param  SPI_InitStruct: pointer to a SPI_InitTypeDef structure that
///         contains the configuration information for the specified
///         SPI peripheral.
/// @retval None.
////////////////////////////////////////////////////////////////////////////////
void SPI_Initxbit(SPI_TypeDef *SPIx, SPI_InitTypeDef *SPI_InitStruct)
{
    uint32_t tmpreg = 0;


    //---------------------------- SPIx GCTL Configuration ---------------------
    // Get the SPIx GCTL value
    tmpreg = SPIx->GCR;
    // Clear csn_sel, dmamode, txtlf, rxtlf,data_sel, rxen, txen, mm, int_en, spien bits
    tmpreg &= ((uint16_t)0xF000);
    /* Configure SPIx: direction, NSS management, first transmitted bit,
     BaudRate prescalermaster/salve mode, CPOL and CPHA
     Set dat_sel bits according to SPI_DataSize value
     Set csn and csn_sel bits according to SPI_NSS value
     Set mm bit according to SPI_Mode value */
    tmpreg |= (uint32_t)((uint32_t)SPI_InitStruct->SPI_DataSize | SPI_InitStruct->SPI_NSS |
                         SPI_InitStruct->SPI_Mode);
    // Write to SPIx GCTL
    SPIx->GCR = tmpreg;
    //---------------------------- SPIx CCTL Configuration ---------------------
    tmpreg = SPIx->GCR;
    // Clear spilen, lsbfe, CPOL, CPHA bits
    tmpreg &= ((uint16_t)0xFFC0);
    // Set Spilen bit according to SPI_DataWidth value
    // Set LSBFirst bit according to SPI_FirstBit value
    // Set CPOL bit according to SPI_CPOL value
    // Set CPHA bit according to SPI_CPHA value
    tmpreg |= ((uint32_t)SPI_InitStruct->SPI_FirstBit | (uint32_t)SPI_InitStruct->SPI_CPOL |
                         (uint32_t)SPI_InitStruct->SPI_CPHA);

    // Write to SPIx CCTL
    SPIx->GCR = tmpreg | 0x18;

    //---------------------------- SPIx SPBRG Configuration ------------------
    tmpreg = SPIx->BRR;
    // Clear spbrg bits
    tmpreg &= (uint16_t)((uint16_t)0x0000);
    // Set BR bits according to SPI_BaudRatePrescaler value
    tmpreg |= (uint16_t)SPI_InitStruct->SPI_BaudRatePrescaler;
    // Write to SPIx SPBRG
    SPIx->BRR = tmpreg;

//    if ((SPI_InitStruct->SPI_DataWidth) != SPI_DataWidth_8b) {
//        SPIx->CCTL |= 1 << 2; //lsbfe
    SPIx->CCR |= 1 << 3; //spilen
//    }
    SPIx->ECR = SPI_InitStruct->SPI_DataWidth;
}

////////////////////////////////////////////////////////////////////////////////
/// @brief  Modifiable parameter initialization SPI.
/// @note   None.
/// @param  SPIx:SPI1/SPI2.
/// @param  spi_baud_div:Specifies the Baud Rate prescaler value which will be.
/// @param  datawidth:data byte length.
/// @param  mode    :SPI mode.
/// @retval None.
////////////////////////////////////////////////////////////////////////////////
void SPIM_Initxbit(SPI_TypeDef* SPIx, unsigned short spi_baud_div, u8 datawidth, SPIMODDE mode)
{

    SPI_InitTypeDef SPI_InitStructure;
    GPIO_InitTypeDef  GPIO_InitStructure;
    if( SPIx == SPI1 )
    {
        RCC_APB2PeriphClockCmd(RCC_APB2ENR_SPI1, ENABLE);
        RCC_AHBPeriphClockCmd(RCC_AHBPeriph_GPIOA, ENABLE);
        //SPI_NSS   PA4
        GPIO_PinAFConfig(GPIOA, GPIO_PinSource4, GPIO_AF_0);
        //SPI_SCK   PA5
        GPIO_PinAFConfig(GPIOA, GPIO_PinSource5, GPIO_AF_0);
        //SPI_MISO  PA6
        GPIO_PinAFConfig(GPIOA, GPIO_PinSource6, GPIO_AF_0);
        //SPI_MOSI  PA7
        GPIO_PinAFConfig(GPIOA, GPIO_PinSource7, GPIO_AF_0);

        //Push to avoid multiplexing output
        GPIO_InitStructure.GPIO_Pin  = GPIO_Pin_4;
        GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
        GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP;
        GPIO_Init(GPIOA, &GPIO_InitStructure);
        GPIO_InitStructure.GPIO_Pin  = GPIO_Pin_5;
        GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
        GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP;
        GPIO_Init(GPIOA, &GPIO_InitStructure);

        GPIO_InitStructure.GPIO_Pin  = GPIO_Pin_7;
        GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
        GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP;
        GPIO_Init(GPIOA, &GPIO_InitStructure);
        //Pull-up input
        GPIO_InitStructure.GPIO_Pin  = GPIO_Pin_6;
        GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IPU;
        GPIO_Init(GPIOA, &GPIO_InitStructure);
    }
    else if( SPIx == SPI2 )
    {
        //spi2_cs  pb12
        RCC_APB1PeriphClockCmd(RCC_APB1Periph_SPI2, ENABLE);
        RCC_AHBPeriphClockCmd(RCC_AHBPeriph_GPIOB, ENABLE);
        GPIO_InitStructure.GPIO_Pin  = GPIO_Pin_12;
        GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
        GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP;
        GPIO_Init(GPIOB, &GPIO_InitStructure);
        //spi2_sck  pb13
        GPIO_InitStructure.GPIO_Pin  = GPIO_Pin_13;
        GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
        GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP;
        GPIO_Init(GPIOB, &GPIO_InitStructure);
        //spi2_mosi  pb15
        GPIO_InitStructure.GPIO_Pin  = GPIO_Pin_15;
        GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
        GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP;
        GPIO_Init(GPIOB, &GPIO_InitStructure);
        //spi2_miso  pb14
        GPIO_InitStructure.GPIO_Pin  = GPIO_Pin_14;
        GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
        GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IPU;
        GPIO_Init(GPIOB, &GPIO_InitStructure);

        GPIO_PinAFConfig(GPIOB, GPIO_PinSource12, GPIO_AF_0);
        GPIO_PinAFConfig(GPIOB, GPIO_PinSource13, GPIO_AF_0);
        GPIO_PinAFConfig(GPIOB, GPIO_PinSource14, GPIO_AF_0);
        GPIO_PinAFConfig(GPIOB, GPIO_PinSource15, GPIO_AF_0);
    }


    SPI_InitStructure.SPI_Mode = SPI_Mode_Master;
    SPI_InitStructure.SPI_DataSize = SPI_DataSize_8b;
    SPI_InitStructure.SPI_DataWidth = SPI_DataWidth_8b;
    SPI_InitStructure.SPI_CPOL = SPI_CPOL_Low;
    SPI_InitStructure.SPI_CPHA = SPI_CPHA_1Edge;
    SPI_InitStructure.SPI_NSS = SPI_NSS_Soft;
    SPI_InitStructure.SPI_BaudRatePrescaler = (SPI_BaudRatePrescaler_TypeDef)spi_baud_div;
    SPI_InitStructure.SPI_FirstBit = SPI_FirstBit_MSB;
    SPI_Init(SPIx, &SPI_InitStructure);

    SPI_Cmd(SPIx, ENABLE);
    SPIM_TXEn(SPIx);
    SPIM_RXEn(SPIx);
}



#if 1

u32 Reverse32Bit(u32 n)
{
    n = (n & 0x55555555) << 1 | (n & 0xAAAAAAAA) >> 1;
    n = (n & 0x33333333) << 2 | (n & 0xCCCCCCCC) >> 2;
    n = (n & 0x0F0F0F0F) << 4 | (n & 0xF0F0F0F0) >> 4;
    n = (n & 0x00FF00FF) << 8 | (n & 0xFF00FF00) >> 8;
    n = (n & 0x0000FFFF) << 16 | (n & 0xFFFF0000) >> 16;
    return n;
}

////////////////////////////////////////////////////////////////////////////////
/// @brief  Transmits a Data through the SPIx peripheral.
/// @note   None.
/// @param  SPIx: SPI1/SPI2
/// @param  Data : Data to be transmitted.
/// @retval None.
////////////////////////////////////////////////////////////////////////////////
void SPI_Send_1_32bits(SPI_TypeDef *SPIx, uint32_t SendData)
{
    u8 temp = 0;
    u8 *puChars;

    puChars = (unsigned char*) &SendData;

    // Write in the TXREG register the data to be sent
    temp = SPIx->ECR;
    temp = temp & 0x1F;
#ifndef SPIUSELSB
    // use MSB
    if(temp == 0)
    {
        temp = 32;
    }
    else
    {
        SendData = SendData << (32 - temp);
    }

#ifdef USECORTEX_M3
    SendData = __rbit(SendData);
#else
    SendData = Reverse32Bit(SendData);
#endif


#endif
    // use LSB
    if(temp == 0)
    {
        temp = 32;
    }
    if(temp <= 8)
    {
        SPIx->TDR = puChars[0];
    }
    else if(temp <= 16)
    {
        SPIx->TDR = puChars[0];
        SPIx->TDR = puChars[1];
    }
    else if(temp <= 24)
    {
        SPIx->TDR = puChars[0];
        SPIx->TDR = puChars[1];
        SPIx->TDR = puChars[2];
    }
    else
    {
        SPIx->TDR = puChars[0];
        SPIx->TDR = puChars[1];
        SPIx->TDR = puChars[2];
        SPIx->TDR = puChars[3];
    }

}

////////////////////////////////////////////////////////////////////////////////
/// @brief   Returns the most recent received data by the SPIx peripheral.
/// @note    None.
/// @param   SPIx: SPI1/SPI2
/// @retval  The value of the received data.
////////////////////////////////////////////////////////////////////////////////
uint32_t SPI_Recv_1_32bits(SPI_TypeDef *SPIx)
{
    u8 temp = 0;
    u32 RecvData = 0;
    u8 *puChars;

    puChars = (unsigned char*) &RecvData;

    temp = SPIx->ECR;
    if(temp == 0)
    {
        temp = 32;
    }
    // use LSB
    if(temp <= 8)
    {
        puChars[0] = (u8)SPIx->RDR;
    }
    else if(temp <= 16)
    {
        puChars[0] = (u8)SPIx->RDR;
        puChars[1] = (u8)SPIx->RDR;
    }
    else if(temp <= 24)
    {
        puChars[0] = (u8)SPIx->RDR;
        puChars[1] = (u8)SPIx->RDR;
        puChars[2] = (u8)SPIx->RDR;
    }
    else
    {
        puChars[0] = (u8)SPIx->RDR;
        puChars[1] = (u8)SPIx->RDR;
        puChars[2] = (u8)SPIx->RDR;
        puChars[3] = (u8)SPIx->RDR;
    }
#ifndef SPIUSELSB
    // use MSB
#ifdef USECORTEX_M3
    SendData = __rbit(SendData);
#else
    RecvData = Reverse32Bit(RecvData);
#endif
    RecvData = RecvData >> (32 - temp);
#endif
    return RecvData;
}

#endif
#if 0
//MSB have issue


//#define DSPI_SendData(IP,SendData)  (IP->TXREG = (SendData))

////////////////////////////////////////////////////////////////////////////////
/// @brief  Transmits a Data through the SPIx peripheral..
/// @note    None.
/// @param   SPIx: SPI1/SPI2
/// @param   Data : Data to be transmitted.
/// @retval  None.
////////////////////////////////////////////////////////////////////////////////
void SPI_Send_1_32bits(SPI_TypeDef *SPIx, uint32_t SendData)
{
    u8 temp = 0;
    u8 *puChars;

    puChars = (unsigned char*) &SendData;

    // Write in the TXREG register the data to be sent
    temp = SPIx->EXTCTL;
    temp = temp & 0x1F;
#ifndef SPIUSELSB
    // use MSB
    if(temp == 0)
    {
        temp = 32;
    }
    else
    {
        SendData = SendData << (32 - temp);
    }
    if(temp <= 8)
    {
        SPIx->TXREG = puChars[3];
    }
    else if(temp <= 16)
    {
        SPIx->TXREG = puChars[3];
        SPIx->TXREG = puChars[2];
    }
    else if(temp <= 24)
    {
        SPIx->TXREG = puChars[3];
        SPIx->TXREG = puChars[2];
        SPIx->TXREG = puChars[1];
    }
    else
    {
        SPIx->TXREG = puChars[3];
        SPIx->TXREG = puChars[2];
        SPIx->TXREG = puChars[1];
        SPIx->TXREG = puChars[0];
    }
#else
    // use LSB
    if(temp == 0)
    {
        temp = 32;
    }
    if(temp <= 8)
    {
        SPIx->TXREG = puChars[0];
    }
    else if(temp <= 16)
    {
        SPIx->TXREG = puChars[0];
        SPIx->TXREG = puChars[1];
    }
    else if(temp <= 24)
    {
        SPIx->TXREG = puChars[0];
        SPIx->TXREG = puChars[1];
        SPIx->TXREG = puChars[2];
    }
    else
    {
        SPIx->TXREG = puChars[0];
        SPIx->TXREG = puChars[1];
        SPIx->TXREG = puChars[2];
        SPIx->TXREG = puChars[3];
    }
#endif
}

////////////////////////////////////////////////////////////////////////////////
/// @brief  Returns the most recent received data by the SPIx peripheral.
/// @note    None.
/// @param   SPIx: SPI1/SPI2
/// @param   None.
/// @retval  The value of the received data.
////////////////////////////////////////////////////////////////////////////////
uint32_t SPI_Recv_1_32bits(SPI_TypeDef *SPIx)
{
    u8 temp = 0;
    u32 RecvData = 0;
    u8 *puChars;

    puChars = (unsigned char*) &RecvData;

    temp = SPIx->EXTCTL;
    if(temp == 0)
    {
        temp = 32;
    }
#ifndef SPIUSELSB
    // use MSB
    if(temp <= 8)
    {
        puChars[3] = (u8)SPIx->RXREG;
    }
    else if(temp <= 16)
    {
        puChars[3] = (u8)SPIx->RXREG;
        puChars[2] = (u8)SPIx->RXREG;
    }
    else if(temp <= 24)
    {
        puChars[3] = (u8)SPIx->RXREG;
        puChars[2] = (u8)SPIx->RXREG;
        puChars[1] = (u8)SPIx->RXREG;
    }
    else
    {
        puChars[3] = (u8)SPIx->RXREG;
        puChars[2] = (u8)SPIx->RXREG;
        puChars[1] = (u8)SPIx->RXREG;
        puChars[0] = (u8)SPIx->RXREG;
    }
    RecvData = RecvData >> (32 - temp);
#else
    // use LSB
    if(temp <= 8)
    {
        puChars[0] = (u8)SPIx->RXREG;
    }
    else if(temp <= 16)
    {
        puChars[0] = (u8)SPIx->RXREG;
        puChars[1] = (u8)SPIx->RXREG;
    }
    else if(temp <= 24)
    {
        puChars[0] = (u8)SPIx->RXREG;
        puChars[1] = (u8)SPIx->RXREG;
        puChars[2] = (u8)SPIx->RXREG;
    }
    else
    {
        puChars[0] = (u8)SPIx->RXREG;
        puChars[1] = (u8)SPIx->RXREG;
        puChars[2] = (u8)SPIx->RXREG;
        puChars[3] = (u8)SPIx->RXREG;
    }
#endif
    return RecvData;
}
#endif
#if 0

////////////////////////////////////////////////////////////////////////////////
/// @brief  Returns the most recent received data by the SPIx peripheral.
/// @note    None.
/// @param   SPIx: SPI1/SPI2
/// @param   None.
/// @retval  The value of the received data.
////////////////////////////////////////////////////////////////////////////////
void SPI_Send_1_32bits(SPI_TypeDef *SPIx, uint32_t SendData)
{
    u8 temp = 0;
    /* Check the parameters */
    assert_param(IS_SPI_ALL_PERIPH(SPIx));

    /* Write in the TXREG register the data to be sent */
    temp = SPIx->EXTCTL;
    if(temp == 0)
    {
        temp = 32;
        //SPIx->GCTL |= SPI_DataSize_32b;
    }
    SPIx->TXREG = SendData;
    if (temp > 0x8   )
        SPIx->TXREG = SendData >> 8;
    if (temp > 0x10  )
        SPIx->TXREG = SendData >> 16;
    if (temp > 0x18  )
        SPIx->TXREG = SendData >> 24;
}

////////////////////////////////////////////////////////////////////////////////
/// @brief  Returns the most recent received data by the SPIx peripheral.
/// @note    None.
/// @param   SPIx: SPI1/SPI2
/// @param   None.
/// @retval  The value of the received data.
////////////////////////////////////////////////////////////////////////////////
uint32_t SPI_Recv_1_32bits(SPI_TypeDef *SPIx)
{
    u8 temp = 0;
    u32 RecvData = 0;
    // Check the parameters
    assert_param(IS_SPI_ALL_PERIPH(SPIx));
    temp = SPIx->EXTCTL;
    if(temp == 0)
    {
        temp = 32;
        //SPIx->GCTL |= SPI_DataSize_32b;
    }
    RecvData = (u32)SPIx->RXREG;
    if (temp > 0x8   )
        RecvData |= (u32)(SPIx->RXREG) << 8;
    if (temp > 0x10  )
        RecvData |= (u32)(SPIx->RXREG) << 16;
    if (temp > 0x18 )
        RecvData |= (u32)(SPIx->RXREG) << 24;

    return RecvData;
}
#endif

////////////////////////////////////////////////////////////////////////////////
/// @brief   Transmit and receive data through peripheral SPIx for full duplex mode.
/// @note    None.
/// @param   SPIx: SPI1/SPI2
/// @param   tx_data:send data.
/// @retval  None.
////////////////////////////////////////////////////////////////////////////////
unsigned int SPIMWriteRead_1_32bits(SPI_TypeDef* SPIx, unsigned int tx_data)
{
    unsigned int rx_data;
    SPI_Send_1_32bits(SPIx, tx_data);
    while (1)
    {
        if(SPI_GetFlagStatus(SPIx, SPI_FLAG_TXEPT))
        {
            break;
        }
    }

    while (1)
    {
        if(SPI_GetFlagStatus(SPIx, SPI_FLAG_RXAVL))
        {
            rx_data = SPI_Recv_1_32bits(SPIx);
            break;
        }
    }
    return rx_data;
}

unsigned char tx_data[10] = {0, 1, 2, 3, 4, 5, 6, 7, 8, 9};
unsigned char rx_data[10];

////////////////////////////////////////////////////////////////////////////////
/// @brief   Transceiver/Receiver Test.
/// @note    None.
/// @param   None.
/// @retval  None.
////////////////////////////////////////////////////////////////////////////////
void SPIM_1_32_loopbackTest(void)
{

    SPIM_Initxbit(SPI2, 0x2, 8, SPIMODE3);

    SPIM_CSLow();
    for(unsigned int t = 0; t < 10; t++)
    {
        rx_data[t] = SPIMWriteRead_1_32bits(SPI2, tx_data[t]);
        UartSendGroup((u8*)printBuf, sprintf(printBuf, "rx[%d]=0x%x\r\n", t, rx_data[t]));
    }
    SPIM_CSHigh();

    UartSendGroup((u8*)printBuf, sprintf(printBuf, "SPI2 test over\r\n"));

}


////////////////////////////////////////////////////////////////////////////////
/// @brief  This function is main entrance.
/// @param  None.
/// @retval  0.
////////////////////////////////////////////////////////////////////////////////
int main(void)
{
    uart_initwBaudRate(115200);
    SPIM_1_32_loopbackTest();
    while(1)
    {

    }
}

////////////////////////////////////////////////////////////////////////////////
/// @brief  Serial port initialization configuration
/// @note    It must be careful of the Chip Version.
/// @param  bound: Baud rate
/// @retval None.
////////////////////////////////////////////////////////////////////////////////
void uart_initwBaudRate(u32 bound)
{

    GPIO_InitTypeDef GPIO_InitStructure;
    UART_InitTypeDef UART_InitStructure;

    RCC_APB2PeriphClockCmd(RCC_APB2Periph_UART1, ENABLE);
    RCC_AHBPeriphClockCmd(RCC_AHBPeriph_GPIOA, ENABLE);
    //GPIO mapping function
    GPIO_PinAFConfig(GPIOA, GPIO_PinSource9, GPIO_AF_1);
    GPIO_PinAFConfig(GPIOA, GPIO_PinSource10, GPIO_AF_1);
    //Baud rate
    UART_InitStructure.BaudRate = bound;
    //The word length is in 8-bit data format.
    UART_InitStructure.WordLength = UART_WordLength_8b;
    UART_InitStructure.StopBits = UART_StopBits_1;
    //No even check bit.
    UART_InitStructure.Parity = UART_Parity_No;
    //No hardware data flow control.
    UART_InitStructure.HWFlowControl = UART_HWFlowControl_None;
    UART_InitStructure.Mode = UART_Mode_Rx | UART_Mode_Tx;

    UART_Init(UART1, &UART_InitStructure);
    UART_Cmd(UART1, ENABLE);

    //UART1_TX   GPIOA.9  Reuse push-pull output
    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_9;
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP;
    GPIO_Init(GPIOA, &GPIO_InitStructure);

    //UART1_RX	  GPIOA.10  Floated input
    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_10;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_FLOATING;
    GPIO_Init(GPIOA, &GPIO_InitStructure);

}

////////////////////////////////////////////////////////////////////////////////
/// @brief  Uart Send Byte
/// @note   None.
/// @param  dat: data
/// @retval None.
////////////////////////////////////////////////////////////////////////////////
void UartSendByte(u8 dat)
{
    UART_SendData( UART1, dat);
    while(!UART_GetFlagStatus(UART1, UART_FLAG_TXEPT));
}

////////////////////////////////////////////////////////////////////////////////
/// @brief  Uart Send Group
/// @note   None.
/// @param  buf: data buff
/// @param  len: length
/// @retval None.
////////////////////////////////////////////////////////////////////////////////
void UartSendGroup(u8* buf, u16 len)
{
    while(len--)
        UartSendByte(*buf++);
}

/// @}


/// @}

/// @}
