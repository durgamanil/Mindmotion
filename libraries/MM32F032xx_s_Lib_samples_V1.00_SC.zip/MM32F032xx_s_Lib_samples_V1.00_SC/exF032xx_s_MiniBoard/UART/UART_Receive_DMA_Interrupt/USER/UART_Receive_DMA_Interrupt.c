////////////////////////////////////////////////////////////////////////////////
/// @file    UART_Receive_DMA_Interrupt.c
/// @author  AE TEAM
/// @version v1.0.0
/// @date    2019-09-20
/// @brief   DMA Interrupt receive mode.
////////////////////////////////////////////////////////////////////////////////
/// @attention
///
/// THE EXISTING FIRMWARE IS ONLY FOR REFERENCE, WHICH IS DESIGNED TO PROVIDE
/// CUSTOMERS WITH CODING INFORMATION ABOUT THEIR PRODUCTS SO THEY CAN SAVE
/// TIME. THEREFORE, MINDMOTION SHALL NOT BE LIABLE FOR ANY DIRECT, INDIRECT OR
/// CONSEQUENTIAL DAMAGES ABOUT ANY CLAIMS ARISING OUT OF THE CONTENT OF SUCH
/// HARDWARE AND/OR THE USE OF THE CODING INFORMATION CONTAINED HEREIN IN
/// CONNECTION WITH PRODUCTS MADE BY CUSTOMERS.
///
/// <H2><CENTER>&COPY; COPYRIGHT 2019 MINDMOTION </CENTER></H2>
////////////////////////////////////////////////////////////////////////////////


#include "UART_Receive_DMA_Interrupt.h"

u8 DST_Buffer[10] = {0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
//DMA transmission completion flag bit
u8 TestStatus = 0;
char printBuf[100];


////////////////////////////////////////////////////////////////////////////////
/// @brief  This function is main entrance.
/// @param  None.
/// @retval None.
////////////////////////////////////////////////////////////////////////////////
int main(void)
{

    u8 i;

    uart_initwBaudRate(115200);
    DMA_Configuration();
    UartSendGroup((u8*)printBuf, sprintf(printBuf, "������10������!\r\n"));
    UartSendGroup((u8*)printBuf, sprintf(printBuf, "�������ֲ��ܹ�ѡ��������!\r\n"));
    while(1)
    {
        if(TestStatus == 1)
        {
            TestStatus = 0;
            for(i = 0; i < 10; i++)
                UartSendGroup((u8*)printBuf, sprintf(printBuf, "DST_Buffer[%d]==%d\r\n", i, (DST_Buffer[i] - 0x30)));
            UartSendGroup((u8*)printBuf, sprintf(printBuf, "\r\n"));
        }
    }
}

////////////////////////////////////////////////////////////////////////////////
/// @brief  Serial port initialization configuration
/// @note    It must be careful of the Chip Version.
/// @param  bound: Baud rate
/// @retval None.
////////////////////////////////////////////////////////////////////////////////
void uart_initwBaudRate(u32 bound)
{

    GPIO_InitTypeDef GPIO_InitStructure;
    UART_InitTypeDef UART_InitStructure;

    RCC_APB2PeriphClockCmd(RCC_APB2Periph_UART1, ENABLE);
    RCC_AHBPeriphClockCmd(RCC_AHBPeriph_GPIOA, ENABLE);

    GPIO_PinAFConfig(GPIOA, GPIO_PinSource9, GPIO_AF_1);
    GPIO_PinAFConfig(GPIOA, GPIO_PinSource10, GPIO_AF_1);

    UART_InitStructure.BaudRate = bound;
    UART_InitStructure.WordLength = UART_WordLength_8b;
    UART_InitStructure.StopBits = UART_StopBits_1;
    UART_InitStructure.Parity = UART_Parity_No;
    UART_InitStructure.HWFlowControl = UART_HWFlowControl_None;
    UART_InitStructure.Mode = UART_Mode_Rx | UART_Mode_Tx;

    UART_Init(UART1, &UART_InitStructure);
    UART_Cmd(UART1, ENABLE);

    //UART1_TX   GPIOA.9
    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_9;
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP;
    GPIO_Init(GPIOA, &GPIO_InitStructure);

    //UART1_RX	  GPIOA.10
    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_10;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_FLOATING;
    GPIO_Init(GPIOA, &GPIO_InitStructure);

}

////////////////////////////////////////////////////////////////////////////////
/// @brief  Interrupt service function
/// @note   The received data is terminated by a carriage return sign.
/// @param  None.
/// @retval None.
////////////////////////////////////////////////////////////////////////////////
void DMA1_Channel2_3_IRQHandler(void)
{
    if(DMA_GetITStatus(DMA1_IT_TC3))
    {
        DMA_ClearITPendingBit(DMA1_IT_GL3);
        // Check the received buffer
        TestStatus = 1;
    }
}

////////////////////////////////////////////////////////////////////////////////
/// @brief  DMA and interrupt priority configuration
/// @note   Configure parameters according to requirements.
/// @param  DMA_CHx (channel).
/// @param  cpar    (UART address).
/// @param  cmar    (data address).
/// @param  cndtr   (data length).
/// @retval None.
////////////////////////////////////////////////////////////////////////////////
void DMA_Configuration(void)
{
    DMA_InitTypeDef  DMA_InitStructure;
    NVIC_InitTypeDef  NVIC_InitStructure;
    RCC_AHBPeriphClockCmd(RCC_AHBPeriph_DMA1, ENABLE);
    // UARTy_DMA1_Channel Config
    DMA_DeInit(DMA1_Channel3);
    DMA_InitStructure.PeripheralBaseAddr = (u32) & (UART1->RDR);
    DMA_InitStructure.MemoryBaseAddr = (u32)DST_Buffer;
    DMA_InitStructure.DIR = DMA_DIR_PeripheralSRC;
    DMA_InitStructure.BufferSize = 10;
    DMA_InitStructure.PeripheralInc = DMA_PeripheralInc_Disable;
    DMA_InitStructure.MemoryInc = DMA_MemoryInc_Enable;
    DMA_InitStructure.PeripheralDataSize = DMA_PeripheralDataSize_Byte;
    DMA_InitStructure.MemoryDataSize = DMA_MemoryDataSize_Byte;
    DMA_InitStructure.Mode = DMA_Mode_Circular;
    DMA_InitStructure.Priority = DMA_Priority_Low;
    DMA_InitStructure.M2M = DMA_M2M_Disable;
    DMA_Init(DMA1_Channel3, &DMA_InitStructure);

    SCB->AIRCR = 0x05FA0000 | 0x600;

    // Enable the UARTy_DMA1_IRQn Interrupt
    NVIC_InitStructure.NVIC_IRQChannel = DMA1_Channel2_3_IRQn;
    NVIC_InitStructure.NVIC_IRQChannelPriority = 0;
    NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
    NVIC_Init(&NVIC_InitStructure);
    // Enable UARTy_DMA1_Channel Transfer complete interrupt
    DMA_ITConfig(DMA1_Channel3, DMA_IT_TC, ENABLE);

    UART_DMACmd(UART1, UART_DMAReq_EN, ENABLE);
    // UARTy_DMA1_Channel enable
    DMA_Cmd(DMA1_Channel3, ENABLE);
}

////////////////////////////////////////////////////////////////////////////////
/// @brief  UART send byte.
/// @note   None.
/// @param  dat(A byte data).
/// @retval None.
////////////////////////////////////////////////////////////////////////////////
void UartSendByte(u8 dat)
{
    UART_SendData(UART1, dat);
    while(!UART_GetFlagStatus(UART1, UART_FLAG_TXEPT));
}

////////////////////////////////////////////////////////////////////////////////
/// @brief  UART send byte.
/// @note   None.
/// @param  buf:buffer address.
/// @param  len:data length.
/// @retval None.
////////////////////////////////////////////////////////////////////////////////
void UartSendGroup(u8* buf, u16 len)
{
    while(len--)
        UartSendByte(*buf++);
}

/// @}


/// @}

/// @}
