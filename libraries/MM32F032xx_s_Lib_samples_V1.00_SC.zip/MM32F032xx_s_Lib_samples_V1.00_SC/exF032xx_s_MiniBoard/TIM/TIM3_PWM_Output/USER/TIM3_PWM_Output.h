////////////////////////////////////////////////////////////////////////////////
/// @file    TIM3_PWM_Output.h
/// @author  AE TEAM
/// @version v1.0.0
/// @date    2019-09-20
/// @brief   THIS FILE PROVIDES ALL THE SYSTEM FIRMWARE FUNCTIONS.
////////////////////////////////////////////////////////////////////////////////
/// @attention
///
/// THE EXISTING FIRMWARE IS ONLY FOR REFERENCE, WHICH IS DESIGNED TO PROVIDE
/// CUSTOMERS WITH CODING INFORMATION ABOUT THEIR PRODUCTS SO THEY CAN SAVE
/// TIME. THEREFORE, MINDMOTION SHALL NOT BE LIABLE FOR ANY DIRECT, INDIRECT OR
/// CONSEQUENTIAL DAMAGES ABOUT ANY CLAIMS ARISING OUT OF THE CONTENT OF SUCH
/// HARDWARE AND/OR THE USE OF THE CODING INFORMATION CONTAINED HEREIN IN
/// CONNECTION WITH PRODUCTS MADE BY CUSTOMERS.
///
/// <H2><CENTER>&COPY; COPYRIGHT 2019 MINDMOTION </CENTER></H2>
////////////////////////////////////////////////////////////////////////////////


// Define to prevent recursive inclusion  --------------------------------------
#ifndef __TIM3_PWM_Output_H
#define __TIM3_PWM_Output_H

// Files includes  -------------------------------------------------------------
#include "types.h"
#include "system_mm32.h"
#include "hal_conf.h"
#include <string.h>
#include "types.h"
#include "mm32.h"
#include "HAL_tim.h"
#include "HAL_gpio.h"
#include "HAL_rcc.h"


////////////////////////////////////////////////////////////////////////////////
/// @defgroup MM32_Example_Layer
/// @brief MM32 Example Layer
/// @{

////////////////////////////////////////////////////////////////////////////////
/// @defgroup MM32_RESOURCE
/// @brief MM32 Examples resource modules
/// @{

////////////////////////////////////////////////////////////////////////////////
/// @defgroup MM32_Exported_Constants
/// @{

#define LED1_Port  GPIOB
#define LED1_Pin   GPIO_Pin_5
#define LED2_Port  GPIOB
#define LED2_Pin   GPIO_Pin_4
#define LED3_Port  GPIOB
#define LED3_Pin   GPIO_Pin_3
#define LED4_Port  GPIOA
#define LED4_Pin   GPIO_Pin_15

#define LED1_ON()  GPIO_ResetBits(LED1_Port,LED1_Pin)
#define LED1_OFF()  GPIO_SetBits(LED1_Port,LED1_Pin)
#define LED1_TOGGLE()  (GPIO_ReadOutputDataBit(LED1_Port,LED1_Pin))?(GPIO_ResetBits(LED1_Port,LED1_Pin)):(GPIO_SetBits(LED1_Port,LED1_Pin))



#define LED2_ON()  GPIO_ResetBits(LED2_Port,LED2_Pin)
#define LED2_OFF()  GPIO_SetBits(LED2_Port,LED2_Pin)
#define LED2_TOGGLE()  (GPIO_ReadOutputDataBit(LED2_Port,LED2_Pin))?(GPIO_ResetBits(LED2_Port,LED2_Pin)):(GPIO_SetBits(LED2_Port,LED2_Pin))


#define LED3_ON()  GPIO_ResetBits(LED3_Port,LED3_Pin)
#define LED3_OFF()  GPIO_SetBits(LED3_Port,LED3_Pin)
#define LED3_TOGGLE()  (GPIO_ReadOutputDataBit(LED3_Port,LED3_Pin))?(GPIO_ResetBits(LED3_Port,LED3_Pin)):(GPIO_SetBits(LED3_Port,LED3_Pin))


#define LED4_ON()  GPIO_ResetBits(LED4_Port,LED4_Pin)
#define LED4_OFF()  GPIO_SetBits(LED4_Port,LED4_Pin)
#define LED4_TOGGLE()  (GPIO_ReadOutputDataBit(LED4_Port,LED4_Pin))?(GPIO_ResetBits(LED4_Port,LED4_Pin)):(GPIO_SetBits(LED4_Port,LED4_Pin))

#define SW1_GPIO_Port  GPIOC
#define SW1_Pin   GPIO_Pin_13
#define SW2_GPIO_Port  GPIOA
#define SW2_Pin   GPIO_Pin_0
#define SW3_GPIO_Port  GPIOB
#define SW3_Pin   GPIO_Pin_10
#define SW4_GPIO_Port  GPIOB
#define SW4_Pin   GPIO_Pin_11

#define KEY1                    GPIO_ReadInputDataBit(SW1_GPIO_Port,SW1_Pin)    //read key1
#define WK_UP                   GPIO_ReadInputDataBit(SW2_GPIO_Port,SW2_Pin)    //read key2 
#define KEY3                    GPIO_ReadInputDataBit(SW3_GPIO_Port,SW3_Pin)    //read key3
#define KEY4                    GPIO_ReadInputDataBit(SW4_GPIO_Port,SW4_Pin)    //read key4

#define KEY1_PRES               1                                               //KEY1 
#define WKUP_PRES               2                                               //WK_UP  
#define KEY3_PRES               3                                               //KEY3 
#define KEY4_PRES               4                                               //KEY4 


void SysTick_Handler_CALL(void);
void TimingDelay_Decrement(void);
void delay_ms(__IO uint32_t nTime);

/// @}

////////////////////////////////////////////////////////////////////////////////
/// @defgroup MM32_Exported_Enumeration
/// @{

////////////////////////////////////////////////////////////////////////////////
/// @brief XXXX enumerate definition.
/// @anchor XXXX
////////////////////////////////////////////////////////////////////////////////
typedef enum
{
    LED1,
    LED2,
    LED3,
    LED4
} Led_TypeDef;


/// @}

////////////////////////////////////////////////////////////////////////////////
/// @defgroup MM32_Exported_Variables
/// @{
#ifdef _MAIN_C_
#define GLOBAL







#else
#define GLOBAL extern







#endif





#undef GLOBAL

/// @}


////////////////////////////////////////////////////////////////////////////////
/// @defgroup MM32_Exported_Functions
/// @{





void TIM3_PWM_Init(u16 arr, u16 psc);



/// @}


/// @}

/// @}


////////////////////////////////////////////////////////////////////////////////
#endif
////////////////////////////////////////////////////////////////////////////////
