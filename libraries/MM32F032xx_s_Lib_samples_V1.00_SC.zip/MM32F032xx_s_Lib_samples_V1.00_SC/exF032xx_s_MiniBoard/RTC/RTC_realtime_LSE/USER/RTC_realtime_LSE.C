////////////////////////////////////////////////////////////////////////////////
/// @file    RTC_realtime.c
/// @author  AE TEAM
/// @version v1.0.0
/// @date    2019-09-20
/// @brief   Read and write flash using SPI2 and print the first ten characters.
////////////////////////////////////////////////////////////////////////////////
/// @attention
///
/// THE EXISTING FIRMWARE IS ONLY FOR REFERENCE, WHICH IS DESIGNED TO PROVIDE
/// CUSTOMERS WITH CODING INFORMATION ABOUT THEIR PRODUCTS SO THEY CAN SAVE
/// TIME. THEREFORE, MINDMOTION SHALL NOT BE LIABLE FOR ANY DIRECT, INDIRECT OR
/// CONSEQUENTIAL DAMAGES ABOUT ANY CLAIMS ARISING OUT OF THE CONTENT OF SUCH
/// HARDWARE AND/OR THE USE OF THE CODING INFORMATION CONTAINED HEREIN IN
/// CONNECTION WITH PRODUCTS MADE BY CUSTOMERS.
///
/// <H2><CENTER>&COPY; COPYRIGHT 2019 MINDMOTION </CENTER></H2>
////////////////////////////////////////////////////////////////////////////////
#define _RTC_realtime_C_
#include "RTC_realtime_LSE.h"
#include "system_mm32.h"
#include "HAL_device.h"
#include "HAL_rcc.h"
#include "HAL_rtc.h"
#include "stdio.h"
#include "string.h"
#include "HAL_conf.h"

char printBuf[100];
const u8 table_week[12] = {0, 3, 3, 6, 1, 4, 6, 2, 5, 0, 3, 5};
const u8 mon_table[12] = {31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31};
////////////////////////////////////////////////////////////////////////////////
/// @brief  This function is main entrance.
/// @param  None.
/// @retval None.
////////////////////////////////////////////////////////////////////////////////
int main(void)
{
    u8 t;
    SetSystemClock(emSYSTICK_On, NULL);
    delay_ms(10);
    uart_initwBaudRate(9600);

    if(1 == RTC_Init())
    {
        UartSendGroup((u8*)printBuf, sprintf(printBuf, "RTC ERROR!"));
        delay_ms(1000);
        UartSendGroup((u8*)printBuf, sprintf(printBuf, "RTC Trying..."));
    }
    else
    {
        UartSendGroup((u8*)printBuf, sprintf(printBuf, "RTC Init finish!"));
    }

    while(1)
    {
        if(t != calendar.sec)
        {
            t = calendar.sec;
            UartSendGroup((u8*)printBuf, sprintf(printBuf, "%d", calendar.w_year));
            UartSendGroup((u8*)printBuf, sprintf(printBuf, "%d", calendar.w_month));
            UartSendGroup((u8*)printBuf, sprintf(printBuf, "%d", calendar.w_date));
            UartSendGroup((u8*)printBuf, sprintf(printBuf, "%d", calendar.hour));
            UartSendGroup((u8*)printBuf, sprintf(printBuf, "%d", calendar.min));
            UartSendGroup((u8*)printBuf, sprintf(printBuf, "%d", calendar.sec));
        }
        delay_ms(10);
    }
//    while(1);
}


void RTC_NVIC_Config(void)
{
    NVIC_InitTypeDef NVIC_InitStructure;
    NVIC_InitStructure.NVIC_IRQChannel = RTC_BKP_IRQn;
    NVIC_InitStructure.NVIC_IRQChannelPriority = 0;
    NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
    NVIC_Init(&NVIC_InitStructure);
}


////////////////////////////////////////////////////////////////////////////////
/// @brief  Initialize RTC clock and check whether it works properly
/// @note    It must be careful of the Chip Version.
/// @param  None.
/// @retval None.
////////////////////////////////////////////////////////////////////////////////
u8 RTC_Init(void)
{
    //Check if the clock is configured for the first time
    u8 temp = 0;
    RCC_APB1PeriphClockCmd(RCC_APB1Periph_PWR | RCC_APB1Periph_BKP, ENABLE);
    //Enabling backup register access
    PWR_BackupAccessCmd(ENABLE);
    //Read data from a specified backup register: Read data that is not identical
    //to the specified data written
    if (BKP_ReadBackupRegister(BKP_DR1) != 0x5050)
    {
        //Reset backup area
        BKP_DeInit();

        RCC_LSEConfig(RCC_LSE_ON);

        delay_ms(2000);
        //Check whether the specified RCC marker is set or not, and wait for the
        //low-speed crystal oscillator to be ready
        while (RCC_GetFlagStatus(RCC_FLAG_LSERDY) == RESET)
        {
            temp++;
            if(temp >= 250)
                return 1;
            delay_ms(10);
        }

        //Setting RTC Clock
        RCC_RTCCLKConfig(RCC_RTCCLKSource_LSE);
        RCC_RTCCLKCmd(ENABLE);
        //Waiting for the last write to RTC registers to complete
        RTC_WaitForLastTask();
        //Waiting for RTC register synchronization
        RTC_WaitForSynchro();
        RTC_ITConfig(RTC_IT_SEC, ENABLE);
        //Allow configuration
        RTC_WaitForLastTask();
//        RTC_EnterConfigMode();
        //Setting the value of RTC pre-frequency Division
        RTC_SetPrescaler(32767);
        RTC_WaitForLastTask();
        RTC_WaitForSynchro();
        //Setup time
        RTC_Set(2019, 9, 20, 10, 30, 55);
        //Exit configuration mode
//        RTC_ExitConfigMode();
        //Write user program data to a specified backup register
        BKP_WriteBackupRegister(BKP_DR1, 0X5050);
        RTC_WaitForLastTask();
    }
    //System Continuation Timing
    else
    {

        RTC_WaitForSynchro();
        RTC_ITConfig(RTC_IT_SEC, ENABLE);
        RTC_WaitForLastTask();
    }
    //Update time
    RTC_NVIC_Config();
//    RTC_Get();
    return 0;

}

////////////////////////////////////////////////////////////////////////////////
/// @brief  RTC Clock Interruption
/// @note    None.
/// @param  bound: Baud rate
/// @retval None.
////////////////////////////////////////////////////////////////////////////////
void RTC_BKP_IRQHandler(void)
{
    //Seconds interrupt
    if (RTC_GetITStatus(RTC_IT_SEC) != RESET)
    {
        //Update time
        RTC_Get();
    }
    //Alarm clock interrupt
    if(RTC_GetITStatus(RTC_IT_ALR) != RESET)
    {
        RTC_ClearITPendingBit(RTC_IT_ALR);
    }
    RTC_ClearITPendingBit((RTC_IT_TypeDef)(RTC_IT_SEC | RTC_IT_OW));
    RTC_WaitForLastTask();
}

////////////////////////////////////////////////////////////////////////////////
/// @brief  Judging whether it is a leap year function
/// @note    None.
/// @param  year
/// @retval None.
////////////////////////////////////////////////////////////////////////////////
u8 Is_Leap_Year(u16 year)
{
    if(year % 4 == 0)
    {
        if(year % 100 == 0)
        {
            if(year % 400 == 0)return 1;
            else return 0;
        }
        else return 1;
    }
    else return 0;
}

////////////////////////////////////////////////////////////////////////////////
/// @brief  Monthly data sheet
/// @note    None.
/// @param  year
/// @retval None.
////////////////////////////////////////////////////////////////////////////////

u8 RTC_Set(u16 syear, u8 smon, u8 sday, u8 hour, u8 min, u8 sec)
{
    u16 t;
    u32 seccount = 0;
    if(syear < 1970 || syear > 2099)return 1;
    //Add up the seconds of all the years
    for(t = 1970; t < syear; t++)
    {
        //The number of seconds in leap years
        if(Is_Leap_Year(t))seccount += 31622400;
        else seccount += 31536000;
    }
    smon -= 1;
    //Add up the seconds of the previous month
    for(t = 0; t < smon; t++)
    {
        seccount += (u32)mon_table[t] * 86400;
        if(Is_Leap_Year(syear) && t == 1)seccount += 86400;
    }
    //Add up the seconds of the previous date
    seccount += (u32)(sday - 1) * 86400;
    seccount += (u32)hour * 3600;
    seccount += (u32)min * 60;
    seccount += sec;

    RCC_APB1PeriphClockCmd(RCC_APB1Periph_PWR | RCC_APB1Periph_BKP, ENABLE);
    //Enabling RTC and backup register access
    PWR_BackupAccessCmd(ENABLE);
    //Setting the value of RTC counter
    RTC_SetCounter(seccount);

    RTC_WaitForLastTask();
    RTC_Get();
    return 0;
}

////////////////////////////////////////////////////////////////////////////////
/// @brief  Get the current time
/// @note    None.
/// @param  year
/// @retval None.
////////////////////////////////////////////////////////////////////////////////
u8 RTC_Get(void)
{
    static u16 daycnt = 0;
    u32 timecount = 0;
    u32 temp = 0;
    u16 temp1 = 0;
    timecount = RTC_GetCounter();
    //day
    temp = timecount / 86400;
    if(daycnt != temp)
    {
        daycnt = temp;
        temp1 = 1970;
        while(temp >= 365)
        {
            if(Is_Leap_Year(temp1))
            {
                if(temp >= 366)temp -= 366;
                else {temp1++; break;}
            }
            else temp -= 365;
            temp1++;
        }
        calendar.w_year = temp1;
        temp1 = 0;
        while(temp >= 28)
        {
            if(Is_Leap_Year(calendar.w_year) && temp1 == 1)
            {
                if(temp >= 29)temp -= 29;
                else break;
            }
            else
            {
                if(temp >= mon_table[temp1])temp -= mon_table[temp1];
                else break;
            }
            temp1++;
        }
        calendar.w_month = temp1 + 1;
        calendar.w_date = temp + 1;
    }
    temp = timecount % 86400;
    calendar.hour = temp / 3600;
    calendar.min = (temp % 3600) / 60;
    calendar.sec = (temp % 3600) % 60;
    calendar.week = RTC_Get_Week(calendar.w_year, calendar.w_month, calendar.w_date);
    return 0;
}

////////////////////////////////////////////////////////////////////////////////
/// @brief  Get the current time week
/// @note    None.
/// @param  year
/// @retval None.
////////////////////////////////////////////////////////////////////////////////
u8 RTC_Get_Week(u16 year, u8 month, u8 day)
{
    u16 temp2;
    u8 yearH, yearL;

    yearH = year / 100;	yearL = year % 100;

    if (yearH > 19)yearL += 100;

    temp2 = yearL + yearL / 4;
    temp2 = temp2 % 7;
    temp2 = temp2 + day + table_week[month - 1];
    if (yearL % 4 == 0 && month < 3)temp2--;
    return(temp2 % 7);
}

////////////////////////////////////////////////////////////////////////////////
/// @brief  Uart Send Byte
/// @note   None.
/// @param  dat: data
/// @retval None.
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
void UartSendByte(u8 dat)
{
    UART_SendData(UART1, dat);
    while(!UART_GetFlagStatus(UART1, UART_FLAG_TXEPT));
}

////////////////////////////////////////////////////////////////////////////////
/// @brief  UART send byte.
/// @note   None.
/// @param  buf:buffer address.
/// @param  len:data length.
/// @retval None.
////////////////////////////////////////////////////////////////////////////////
void UartSendGroup(u8* buf, u16 len)
{
    while(len--)
        UartSendByte(*buf++);
}

////////////////////////////////////////////////////////////////////////////////
/// @brief  Serial port initialization configuration
/// @note    It must be careful of the Chip Version.
/// @param  bound: Baud rate
/// @retval None.
////////////////////////////////////////////////////////////////////////////////
void uart_initwBaudRate(u32 bound)
{

    GPIO_InitTypeDef GPIO_InitStructure;
    UART_InitTypeDef UART_InitStructure;

    RCC_APB2PeriphClockCmd(RCC_APB2Periph_UART1, ENABLE);
    RCC_AHBPeriphClockCmd(RCC_AHBPeriph_GPIOA, ENABLE);
    //GPIO mapping function
    GPIO_PinAFConfig(GPIOA, GPIO_PinSource9, GPIO_AF_1);
    GPIO_PinAFConfig(GPIOA, GPIO_PinSource10, GPIO_AF_1);
    //Baud rate
    UART_InitStructure.BaudRate = bound;
    //The word length is in 8-bit data format.
    UART_InitStructure.WordLength = UART_WordLength_8b;
    UART_InitStructure.StopBits = UART_StopBits_1;
    //No even check bit.
    UART_InitStructure.Parity = UART_Parity_No;
    //No hardware data flow control.
    UART_InitStructure.HWFlowControl = UART_HWFlowControl_None;
    UART_InitStructure.Mode = UART_Mode_Rx | UART_Mode_Tx;

    UART_Init(UART1, &UART_InitStructure);
    UART_Cmd(UART1, ENABLE);

    //UART1_TX   GPIOA.9  Reuse push-pull output
    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_9;
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP;
    GPIO_Init(GPIOA, &GPIO_InitStructure);

    //UART1_RX	  GPIOA.10  Floated input
    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_10;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_FLOATING;
    GPIO_Init(GPIOA, &GPIO_InitStructure);

}



////////////////////////////////////////////////////////////////////////////////
/// @brief  This function make delay count decrement as one systick
///         for example , delay (1ms)
/// @note   when decrement to zero?? it always 0.
/// @param  None.
/// @retval None.
////////////////////////////////////////////////////////////////////////////////
void TimingDelay_Decrement(void)
{
    if (TimingDelay != 0x00)
    {
        TimingDelay--;
    }
}

////////////////////////////////////////////////////////////////////////////////
/// @brief  This function is called back by SysTick Handler
///         call series function to run systick cycle running
///         for example , delay, led blink, key in scan , etc.
/// @note   This function always run after power on.
/// @param  None.
/// @retval None.
////////////////////////////////////////////////////////////////////////////////
void SysTick_Handler_CALL(void)
{
    TimingDelay_Decrement();
}

////////////////////////////////////////////////////////////////////////////////
/// @brief  delay nTime ms
/// @note   get x times.
/// @param  nTime  nTime ms.
/// @retval None.
////////////////////////////////////////////////////////////////////////////////
void delay_ms(__IO uint32_t nTime)
{
    TimingDelay = nTime;
    for(;;)
    {
        if(TimingDelay == 0)
            break;
    }
}



/// @}

/// @}

/// @}


