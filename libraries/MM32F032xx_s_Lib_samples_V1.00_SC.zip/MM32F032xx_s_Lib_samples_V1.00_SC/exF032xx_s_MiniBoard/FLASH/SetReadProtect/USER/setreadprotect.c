////////////////////////////////////////////////////////////////////////////////
/// @file    setreadprotect.c
/// @author  AE TEAM
/// @version v1.0.0
/// @date    2019-09-20
/// @brief   THIS FILE PROVIDES ALL THE SYSTEM FUNCTIONS.
////////////////////////////////////////////////////////////////////////////////
/// @attention
///
/// THE EXISTING FIRMWARE IS ONLY FOR REFERENCE, WHICH IS DESIGNED TO PROVIDE
/// CUSTOMERS WITH CODING INFORMATION ABOUT THEIR PRODUCTS SO THEY CAN SAVE
/// TIME. THEREFORE, MINDMOTION SHALL NOT BE LIABLE FOR ANY DIRECT, INDIRECT OR
/// CONSEQUENTIAL DAMAGES ABOUT ANY CLAIMS ARISING OUT OF THE CONTENT OF SUCH
/// HARDWARE AND/OR THE USE OF THE CODING INFORMATION CONTAINED HEREIN IN
/// CONNECTION WITH PRODUCTS MADE BY CUSTOMERS.
///
/// <H2><CENTER>&COPY; COPYRIGHT 2019 MINDMOTION </CENTER></H2>
////////////////////////////////////////////////////////////////////////////////

// Define to prevent recursive inclusion  --------------------------------------
#define _SETREADPROTECT_C_

// Files includes  -------------------------------------------------------------
#include "HAL_device.h"
#include "HAL_conf.h"
#include "setreadprotect.h"

uint32_t Data = 0x12345679;

volatile FLASH_Status FLASHStatus = FLASH_COMPLETE;


////////////////////////////////////////////////////////////////////////////////
/// @brief  This function is soft reset.
/// @param  None.
/// @retval None.
////////////////////////////////////////////////////////////////////////////////
void SoftReset(void)
{
    //__set_FAULTMASK(1);//For Cortex-M3,M4  Disable Interrupt
    NVIC_SystemReset();//Reset

}

////////////////////////////////////////////////////////////////////////////////
/// @brief  This function is main entrance.
/// @param  None.
/// @retval None.
////////////////////////////////////////////////////////////////////////////////
int main(void)
{
    int status;
    u32 t = 0;
    u32 getresult = 0;
    LED_Init();

    // Enable the Read Protect
    t = CheckReadProtect();
    if (t == 0)   //not protect
    {
        FLASH_Unlock();
        status = FLASH_EnableFullMainFlashReadOutProtect();
        FLASH_Lock();
        if (status == 0)
        {
            getresult = 0;
        }
        else
        {
            getresult = 1;//set read protect failure
        }

    }
    else
    {
        //chip is set protect before
        getresult = 1;
        //TO DO
        //need to Set ReadProtectDisable
    }

    if (getresult == 0)   //success
    {
        {
            LED1_TOGGLE();
            LED2_TOGGLE();
            LED3_TOGGLE();
            LED4_TOGGLE();
            delay_ms(2000);
        }
    }
    else     //fail
    {
        while (1)
        {
            LED1_TOGGLE();
            LED2_TOGGLE();
            LED3_TOGGLE();
            LED4_TOGGLE();
            delay_ms(200);
        }
    }
    while (1)
    {
        LED3_TOGGLE();
        LED4_TOGGLE();
        delay_ms(100);
    }
}
////////////////////////////////////////////////////////////////////////////////
/// @brief  This function is check the write protect status.
/// @note   None.
/// @param  None.
/// @retval protectstatus.
////////////////////////////////////////////////////////////////////////////////
u32 CheckWriteProtectblank(void)
{

    uint32_t protectstatus = 0;
    u16 data1;
    int i = 0;

    for (i = 0; i < 4; i++)
    {
        data1 = *(u16 *)(0x1ffff808 + i * 2); //Address must be an integer multiple of 2
        if (data1 != 0xFFFF)
        {
            protectstatus = 1;
            break;
        }
    }
    return protectstatus;
}

////////////////////////////////////////////////////////////////////////////////
/// @brief  This function is check the read protect status.
/// @note   None.
/// @param  None.
/// @retval protectstatus.
////////////////////////////////////////////////////////////////////////////////
u32 CheckReadProtect(void)
{

    uint32_t protectstatus = 0;
    u16 data1;
    int i = 0;



    if ((FLASH->OBR & 0x02) != (uint32_t)RESET)
    {
        // Read Protect on 0x1FFFF800 is set
        protectstatus = 1;
    }
    else
    {
        for (i = 0; i < 8; i++)
        {
            data1 = *(u16 *)(0x1ffe0000 + i * 2); //Address must be an integer multiple of 2
            if (data1 != 0xFFFF)
            {
                protectstatus = 2;
                break;
            }
        }
    }
    return protectstatus;

}
////////////////////////////////////////////////////////////////////////////////
/// @brief  This function is portect Full main Flash enable.
/// @note   None.
/// @param  None.
/// @retval ret.
////////////////////////////////////////////////////////////////////////////////
//
int FLASH_EnableFullMainFlashReadOutProtect(void)
{
    FLASH_Status status = FLASH_COMPLETE;
    int ret = 0;
    status = FLASH_ProgramOptionHalfWord(0x1ffe0000, 0x7F80);
    if (status != FLASH_COMPLETE)
        ret = 1;
    status = FLASH_ProgramOptionHalfWord(0x1ffe0002, 0xFF00);
    if (status != FLASH_COMPLETE)
        ret = 1;
    return ret;
}

////////////////////////////////////////////////////////////////////////////////
/// @brief  This function is called back by SysTick Handler
///         call series function to run systick cycle running
///         for example , delay, led blink, key in scan , etc.
/// @note   This function always run after power on.
/// @param  None.
/// @retval None.
////////////////////////////////////////////////////////////////////////////////
void SysTick_Handler_CALL(void)
{
    TimingDelay_Decrement();
}
////////////////////////////////////////////////////////////////////////////////
/// @brief  This function make delay count decrement as one systick
///         for example , delay (1ms)
/// @note   when decrement to zero�� it always 0.
/// @param  None.
/// @retval None.
////////////////////////////////////////////////////////////////////////////////
void TimingDelay_Decrement(void)
{
    if (TimingDelay != 0x00)
    {
        TimingDelay--;
    }
}
////////////////////////////////////////////////////////////////////////////////
/// @brief  delay nTime ms
/// @note   get x times.
/// @param  nTime  nTime ms.
/// @retval None.
////////////////////////////////////////////////////////////////////////////////
void delay_ms(__IO uint32_t nTime)
{
    TimingDelay = nTime;

    while(TimingDelay > 0)
    {
        nTime = TimingDelay;
        if(nTime == 0)
        {
            break;
        }

    }
}



////////////////////////////////////////////////////////////////////////////////
/// @brief  RCC GPIO_Clock_Set
/// @note   must define different Core Version.
/// @param  GPIOx     GPIO port
///         NewState  ENABLE or DISABLE
/// @retval None.
////////////////////////////////////////////////////////////////////////////////
void GPIO_Clock_Set(GPIO_TypeDef* GPIOx, FunctionalState NewState)
{
    if(GPIOx == GPIOA)
    {
        RCC_AHBPeriphClockCmd(RCC_AHBPeriph_GPIOA, NewState);
    }
    if(GPIOx == GPIOB)
    {
        RCC_AHBPeriphClockCmd(RCC_AHBPeriph_GPIOB, NewState);
    }
    if(GPIOx == GPIOC)
    {
        RCC_AHBPeriphClockCmd(RCC_AHBPeriph_GPIOC, NewState);
    }
    if(GPIOx == GPIOD)
    {
        RCC_AHBPeriphClockCmd(RCC_AHBPeriph_GPIOD, NewState);
    }
}

////////////////////////////////////////////////////////////////////////////////
/// @brief  initialize LED GPIO pin
/// @note   if use jtag/swd interface GPIO PIN as LED, need to be careful,
///         can not debug or program.
/// @param  None.
/// @retval None.
////////////////////////////////////////////////////////////////////////////////
void LED_Init(void)
{
    GPIO_InitTypeDef  GPIO_InitStructure;

    GPIO_Clock_Set(GPIOA, ENABLE);
    GPIO_Clock_Set(GPIOB, ENABLE);
    GPIO_InitStructure.GPIO_Pin  =  GPIO_Pin_15;
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
    GPIO_Init(GPIOA, &GPIO_InitStructure);

    GPIO_InitStructure.GPIO_Pin  = GPIO_Pin_3 | GPIO_Pin_4 | GPIO_Pin_5;
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
    GPIO_Init(GPIOB, &GPIO_InitStructure);

    LED1_ON();
    LED2_ON();
    LED3_ON();
    LED4_ON();
}

/// @}

/// @}

/// @}


