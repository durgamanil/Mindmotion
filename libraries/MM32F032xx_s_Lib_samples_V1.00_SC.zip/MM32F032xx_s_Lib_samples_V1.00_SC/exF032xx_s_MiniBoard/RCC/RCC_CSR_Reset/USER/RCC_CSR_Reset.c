////////////////////////////////////////////////////////////////////////////////
/// @file     RCC_CSR_Reset.c
/// @author   AE TEAM
/// @version  v1.0.0
/// @date     2019-09-20
/// @brief    DMA mode send data.
////////////////////////////////////////////////////////////////////////////////
/// @attention
///
/// THE EXISTING FIRMWARE IS ONLY FOR REFERENCE, WHICH IS DESIGNED TO PROVIDE
/// CUSTOMERS WITH CODING INFORMATION ABOUT THEIR PRODUCTS SO THEY CAN SAVE
/// TIME. THEREFORE, MINDMOTION SHALL NOT BE LIABLE FOR ANY DIRECT, INDIRECT OR
/// CONSEQUENTIAL DAMAGES ABOUT ANY CLAIMS ARISING OUT OF THE CONTENT OF SUCH
/// HARDWARE AND/OR THE USE OF THE CODING INFORMATION CONTAINED HEREIN IN
/// CONNECTION WITH PRODUCTS MADE BY CUSTOMERS.
///
/// <H2><CENTER>&COPY; COPYRIGHT 2018-2019 MINDMOTION </CENTER></H2>
////////////////////////////////////////////////////////////////////////////////
#define _RCC_CSR_Reset_C_
#include "RCC_CSR_Reset.h"



char printBuf[100];


////////////////////////////////////////////////////////////////////////////////
/// @brief  This function is main entrance.
/// @param  None.
/// @retval  0.
////////////////////////////////////////////////////////////////////////////////
int main(void)
{
    static u8 i = 0;
    //i=0;
    //i=1;
    i = 2;
    //i=3;
    deleyNop(300);
    uart_initwBaudRate(115200);
    UartSendGroup((u8 *)printBuf, sprintf(printBuf, "uart ok!\r\n"));
    LED_Init();
    if (i == 1)
    {
        WWDG_Reset_Test();
    }
    else if (i == 2)
    {
        IWDG_Reset_Test();
    }
    else if (i == 3)
    {
        Soft_Reset_Test();
    }
    else
    {
        PinAndPOR_Reset_Test();
    }
    while (1)
    {
        deleyNop(1);
    }
}

////////////////////////////////////////////////////////////////////////////////
/// @brief   Interrupt handler
/// @note    Interrupt is entered when the decrement counter equals 0x40
///          The counter parameter must be less than 0x7f and greater than 0x40,
///          and close to 0x40 May enter this interrupt frequently
/// @param   None
/// @retval None.
////////////////////////////////////////////////////////////////////////////////
void WWDG_IRQHandler(void)
{
    if (WWDG_GetFlagStatus())
    {
        WWDG_ClearFlag();
        WWDG_SetCounter(0x66);
    }
}
////////////////////////////////////////////////////////////////////////////////
/// @brief  Wwdg_reset_test
/// @note   When the system starts, the watchdog is disabled. After the watchdog
///         is disabled, it cannot be closed manually. After reset, the watchdog
///         is disabled
/// @param  ucTcnt:which is 7-bit data and the value is 0x40~0x7f
/// @param  ucWcnt: The guard dog counts
/// @retval None.
////////////////////////////////////////////////////////////////////////////////
void Wwdg_reset_ON(unsigned char ucTcnt, unsigned char ucWcnt)
{
    //Disabled window watchdog clock
    RCC_APB1PeriphClockCmd(RCC_APB1Periph_WWDG, ENABLE);

    //WWDG_Prescaler_x,x can be 1,2,4,8
    WWDG_SetPrescaler(WWDG_Prescaler_8);
    WWDG_SetWindowValue(ucWcnt);

    //Assigns a value to the watchdog autodecrement counter
    WWDG_Enable(ucTcnt);
}
////////////////////////////////////////////////////////////////////////////////
/// @brief  RCC GPIO_Clock_Set
/// @note   must define different Core Version.
/// @param  GPIOx     GPIO port
///         NewState  ENABLE or DISABLE
/// @retval None.
////////////////////////////////////////////////////////////////////////////////
void GPIO_Clock_Set(GPIO_TypeDef* GPIOx, FunctionalState NewState)
{
    if(GPIOx == GPIOA)
    {
        RCC_AHBPeriphClockCmd(RCC_AHBPeriph_GPIOA, NewState);
    }
    if(GPIOx == GPIOB)
    {
        RCC_AHBPeriphClockCmd(RCC_AHBPeriph_GPIOB, NewState);
    }
    if(GPIOx == GPIOC)
    {
        RCC_AHBPeriphClockCmd(RCC_AHBPeriph_GPIOC, NewState);
    }
    if(GPIOx == GPIOD)
    {
        RCC_AHBPeriphClockCmd(RCC_AHBPeriph_GPIOD, NewState);
    }
}
////////////////////////////////////////////////////////////////////////////////
/// @brief  initialize LED GPIO pin
/// @note   if use jtag/swd interface GPIO PIN as LED, need to be careful, can not debug or program.
/// @param  None.
/// @retval None.
////////////////////////////////////////////////////////////////////////////////
void LED_Init(void)
{
    GPIO_InitTypeDef  GPIO_InitStructure;

    GPIO_Clock_Set(GPIOA, ENABLE);
    GPIO_Clock_Set(GPIOB, ENABLE);
    GPIO_InitStructure.GPIO_Pin  =  GPIO_Pin_15;
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
    GPIO_Init(GPIOA, &GPIO_InitStructure);

    GPIO_InitStructure.GPIO_Pin  = GPIO_Pin_3 | GPIO_Pin_4 | GPIO_Pin_5;
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
    GPIO_Init(GPIOB, &GPIO_InitStructure);

    LED1_ON();
    LED2_ON();
    LED3_ON();
    LED4_ON();
}

////////////////////////////////////////////////////////////////////////////////
/// @brief   Window watchdog Immediate reset
/// @note    Need an immediate reset to consider this function
/// @param   None
/// @retval  None
////////////////////////////////////////////////////////////////////////////////
void Wwdg_ExterslReloadReset_ON(void)
{
    RCC_APB1PeriphClockCmd(RCC_APB1Periph_WWDG, ENABLE);
    WWDG_SetPrescaler(WWDG_Prescaler_8);
    //The assignment is less than 0x80
    WWDG_SetWindowValue(0x70);
    //The assignment is between 0x7f and 0x40
    WWDG_Enable(0x75);
}

////////////////////////////////////////////////////////////////////////////////
/// @brief ��Window watchdog interrupt configuration
/// @note    None
/// @param   None
/// @retval : None
////////////////////////////////////////////////////////////////////////////////
void Wwdg_irq_ON(void)
{
    NVIC_InitTypeDef NVIC_InitStructure;

    NVIC_InitStructure.NVIC_IRQChannel = WWDG_IRQn;
    NVIC_InitStructure.NVIC_IRQChannelPriority = 1;
    NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
    NVIC_Init(&NVIC_InitStructure);

    RCC_APB1PeriphClockCmd(RCC_APB1Periph_WWDG, ENABLE);
    WWDG_SetWindowValue(0x70);
    WWDG_EnableIT();
    //For configuration here, the parameter value must be less than the window
    //value, otherwise reset will occur immediately
    WWDG_Enable(0x66);
}

////////////////////////////////////////////////////////////////////////////////
/// @name   : Write_Iwdg_ON
/// @brief  : Write_Iwdg_ON
/// @param  : None
/// @retval : None
////////////////////////////////////////////////////////////////////////////////
void Write_Iwdg_ON(u16 IWDG_Prescaler, u16 Reload)
{

    RCC_LSICmd(ENABLE);                                                         //enable LSI
    while (RCC_GetFlagStatus(RCC_FLAG_LSIRDY) == RESET);

    PVU_CheckStatus();                                                          //get IWDG status
    IWDG_WriteAccessCmd(0x5555);
    IWDG_SetPrescaler(IWDG_Prescaler);

    RVU_CheckStatus();                                                          //get IWDG status
    IWDG_WriteAccessCmd(0x5555);
    IWDG_SetReload(Reload & 0xfff);

    IWDG_ReloadCounter();                                                       //load and enable IWDG
    IWDG_Enable();
}

////////////////////////////////////////////////////////////////////////////////
/// @brief   Write_Iwdg_RL
/// @param   None
/// @retval  None
////////////////////////////////////////////////////////////////////////////////
void Write_Iwdg_RL(void)
{
    IWDG_ReloadCounter();
}

////////////////////////////////////////////////////////////////////////////////
/// @brief   WWDG reset
/// @note    RCC_CSR 24 RMVF rw 0 RMVF�� clear reset flag
///          The software sets' 1 'to clear the reset flag.
/// @param   None
/// @retval  None
////////////////////////////////////////////////////////////////////////////////

int WWDG_Reset_Test(void)
{
    UartSendGroup((u8 *)printBuf, sprintf(printBuf, "WWDG Reset Test!\r\n"));
    UartSendGroup((u8 *)printBuf, sprintf(printBuf, "1.RCC->CSR =0x%x\r\n", RCC->CSR));
    deleyNop(100);
    RCC->CSR |= 1 << 24;
    deleyNop(100);
    UartSendGroup((u8 *)printBuf, sprintf(printBuf, "2.RCC->CSR =0x%x\r\n", RCC->CSR));
    deleyNop(2000);
    //Reset in microseconds to milliseconds
    Wwdg_reset_ON(0x7e, 0x7f);
    while (1)
    {
        //A watchdog feeds a dog and is out of position
        //WWDG_SetCounter(0x7e);
        deleyNop(1);
    }
}
////////////////////////////////////////////////////////////////////////////////
/// @brief   IWDG reset
/// @note    RCC_CSR 24 RMVF rw 0 RMVF�� clear reset flag
///          The software sets' 1 'to clear the reset flag.
/// @param   None
/// @retval  None
////////////////////////////////////////////////////////////////////////////////
int IWDG_Reset_Test(void)
{
    UartSendGroup((u8 *)printBuf, sprintf(printBuf, "IWDG Reset Test!\r\n"));
    UartSendGroup((u8 *)printBuf, sprintf(printBuf, "1.RCC->CSR =0x%x\r\n", RCC->CSR));
    deleyNop(100);
    RCC->CSR |= 1 << 24;

    deleyNop(100);
    UartSendGroup((u8 *)printBuf, sprintf(printBuf, "2.RCC->CSR =0x%x\r\n", RCC->CSR));
    deleyNop(2000);
    Write_Iwdg_ON(IWDG_Prescaler_256, 0xff);
    while (1)
    {
        //A  independent watchdog feeds a dog and is out of position
        //Write_Iwdg_RL();
        deleyNop(1);
    }
}
////////////////////////////////////////////////////////////////////////////////
/// @brief   soft reset
/// @note    RCC_CSR 24 RMVF rw 0 RMVF�� clear reset flag
///          The software sets' 1 'to clear the reset flag.
/// @param   None
/// @retval  None
////////////////////////////////////////////////////////////////////////////////
int Soft_Reset_Test(void)
{
    UartSendGroup((u8 *)printBuf, sprintf(printBuf, "SOFT Reset Test!\r\n"));
    UartSendGroup((u8 *)printBuf, sprintf(printBuf, "1.RCC->CSR =0x%x\r\n", RCC->CSR));
    deleyNop(100);
    RCC->CSR |= 1 << 24;
    deleyNop(100);
    UartSendGroup((u8 *)printBuf, sprintf(printBuf, "2.RCC->CSR =0x%x\r\n", RCC->CSR));
    deleyNop(2000);
    NVIC_SystemReset();
    while (1)
    {
        //Do not run here, the software has been reset
        deleyNop(1);
    }
}
////////////////////////////////////////////////////////////////////////////////
/// @brief   key or Repeat the electricity to reset
/// @note    RCC_CSR 24 RMVF rw 0 RMVF�� clear reset flag
///          The software sets' 1 'to clear the reset flag.
/// @param   None
/// @retval  None
////////////////////////////////////////////////////////////////////////////////
int PinAndPOR_Reset_Test(void)
{
    UartSendGroup((u8 *)printBuf, sprintf(printBuf, "Pin and POR Reset Test!\r\n"));
    UartSendGroup((u8 *)printBuf, sprintf(printBuf, "1.RCC->CSR =0x%x\r\n", RCC->CSR));
    deleyNop(100);
    RCC->CSR |= 1 << 24;
    deleyNop(100);
    UartSendGroup((u8 *)printBuf, sprintf(printBuf, "2.RCC->CSR =0x%x\r\n", RCC->CSR));
    deleyNop(2000);

    while (1)
    {
        //Wait for the button or reset
        deleyNop(1);
    }
}
////////////////////////////////////////////////////////////////////////////////
/// @brief  delay nTime
/// @note   get x times.
/// @param  DlyTime  nTime .
/// @retval None.
////////////////////////////////////////////////////////////////////////////////
static void deleyNop(u32 DlyTime)
{
    u32 i, j;
    for(i = 0; i < DlyTime; i++)
    {
        for(j = 0; j < 100; j++)
        {
            __NOP();
            __NOP();
            __NOP();
            __NOP();
            __NOP();
            __NOP();
            __NOP();
            __NOP();
            __NOP();
            __NOP();
            __NOP();
            __NOP();
            __NOP();
            __NOP();
            __NOP();
        }
    }
}

////////////////////////////////////////////////////////////////////////////////
/// @brief  Serial port initialization configuration
/// @note    It must be careful of the Chip Version.
/// @param  bound: Baud rate
/// @retval None.
////////////////////////////////////////////////////////////////////////////////
void uart_initwBaudRate(u32 bound)
{

    GPIO_InitTypeDef GPIO_InitStructure;
    UART_InitTypeDef UART_InitStructure;

    RCC_APB2PeriphClockCmd(RCC_APB2Periph_UART1, ENABLE);
    RCC_AHBPeriphClockCmd(RCC_AHBPeriph_GPIOA, ENABLE);

    GPIO_PinAFConfig(GPIOA, GPIO_PinSource9, GPIO_AF_1);
    GPIO_PinAFConfig(GPIOA, GPIO_PinSource10, GPIO_AF_1);

    //Baud rate
    UART_InitStructure.BaudRate = bound;
    //The word length is in 8-bit data format.
    UART_InitStructure.WordLength = UART_WordLength_8b;
    UART_InitStructure.StopBits = UART_StopBits_1;
    //No even check bit.
    UART_InitStructure.Parity = UART_Parity_No;
    //No hardware data flow control.
    UART_InitStructure.HWFlowControl = UART_HWFlowControl_None;
    UART_InitStructure.Mode = UART_Mode_Rx | UART_Mode_Tx;

    UART_Init(UART1, &UART_InitStructure);
    UART_Cmd(UART1, ENABLE);

    //UART1_TX   GPIOA.9  Reuse push-pull output
    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_9;
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP;
    GPIO_Init(GPIOA, &GPIO_InitStructure);

    //UART1_RX	  GPIOA.10 Floated input
    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_10;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_FLOATING;
    GPIO_Init(GPIOA, &GPIO_InitStructure);

}

////////////////////////////////////////////////////////////////////////////////
/// @brief  UART send byte.
/// @note   None.
/// @param  dat(A byte data).
/// @retval None.
////////////////////////////////////////////////////////////////////////////////
void UartSendByte(u8 dat)
{
    UART_SendData(UART1, dat);
    while (!UART_GetFlagStatus(UART1, UART_FLAG_TXEPT));
}

////////////////////////////////////////////////////////////////////////////////
/// @brief  UART send byte.
/// @note   None.
/// @param  buf:buffer address.
/// @param  len:data length.
/// @retval None.
////////////////////////////////////////////////////////////////////////////////
void UartSendGroup(u8 *buf, int len)
{
    while (len--)
        UartSendByte(*buf++);
}

/// @}


/// @}

/// @}

