////////////////////////////////////////////////////////////////////////////////
/// @file     GPIOsim_I2C_WR_EEPROM.c
/// @author   AE TEAM
/// @version v1.0.0
/// @date     2019-09-20
/// @brief    This sample show how to use MM32 write read EEPROM AT2404 through
///           GPIO pin to simulate I2C interface.
////////////////////////////////////////////////////////////////////////////////
/// @attention
///
/// THE EXISTING FIRMWARE IS ONLY FOR REFERENCE, WHICH IS DESIGNED TO PROVIDE
/// CUSTOMERS WITH CODING INFORMATION ABOUT THEIR PRODUCTS SO THEY CAN SAVE
/// TIME. THEREFORE, MINDMOTION SHALL NOT BE LIABLE FOR ANY DIRECT, INDIRECT OR
/// CONSEQUENTIAL DAMAGES ABOUT ANY CLAIMS ARISING OUT OF THE CONTENT OF SUCH
/// HARDWARE AND/OR THE USE OF THE CODING INFORMATION CONTAINED HEREIN IN
/// CONNECTION WITH PRODUCTS MADE BY CUSTOMERS.
///
/// <H2><CENTER>&COPY; COPYRIGHT 2018-2019 MINDMOTION </CENTER></H2>
////////////////////////////////////////////////////////////////////////////////
#define _GPIOsim_I2C_WR_EEPROM_C_
#include "GPIOsim_I2C_WR_EEPROM.h"


void LED_Init(void);





// Write/Read 24C02-Flash
#define EEPROM_ADDR 0xA0
#define FALSE    0
#define TRUE    1



u8 buffer0[128] = {0xab, 0xbb, 0xcc, 0xdd, 0xee, 0xff, 0x11, 0x22, 0x33, 0x44, 0x55, 0x66, 0x77, 0x88, 0x99};
u8 buffer1[128];


#define I2C1_SCL_PORT               GPIOB
#define I2C1_SCL_PIN                GPIO_Pin_8
#define I2C1_SCL_BUSCLK             RCC_AHBPeriph_GPIOB

#define I2C1_SDA_PORT               GPIOB
#define I2C1_SDA_PIN                GPIO_Pin_9
#define I2C1_SDA_BUSCLK             RCC_AHBPeriph_GPIOB

#define SCL_H                       I2C1_SCL_PORT->BSRR = I2C1_SCL_PIN
#define SCL_L                       I2C1_SCL_PORT->BRR  = I2C1_SCL_PIN
#define SCL_read                    (I2C1_SCL_PORT-IDR  & I2C1_SCL_PIN)

#define	SDA_H	                    I2C1_SDA_PORT->BSRR	= I2C1_SDA_PIN
#define SDA_L	                    I2C1_SDA_PORT->BRR	= I2C1_SDA_PIN
#define SDA_read                    (I2C1_SDA_PORT->IDR & I2C1_SDA_PIN)

void I2C_GPIO_Config(void);
bool EEPROM_ByteWrite(u8 SendByte, u16 WriteAddress, u8 DeviceAddress);
bool EEPROM_SequentialRead(u8 *pBuffer, u8 length, u16 ReadAddress, u8 DeviceAddress);
#define I2C_PageSize 16//8
void delay_ms(__IO uint32_t nTime);
#define Systick_Delay_1ms delay_ms
#ifndef NULL
#define NULL  _NULL
#endif

////////////////////////////////////////////////////////////////////////////////
/// @brief  This function make delay count decrement as one systick
///         for example , delay (1ms)
/// @note   when decrement to zero�� it always 0.
/// @param  None.
/// @retval None.
////////////////////////////////////////////////////////////////////////////////
void TimingDelay_Decrement(void)
{
    if (TimingDelay > 0x00)
    {
        TimingDelay--;
    }
}

////////////////////////////////////////////////////////////////////////////////
/// @brief  This function is called back by SysTick Handler
///         call series function to run systick cycle running
///         for example , delay, led blink, key in scan , etc.
/// @note   This function always run after power on.
/// @param  None.
/// @retval None.
////////////////////////////////////////////////////////////////////////////////
void SysTick_Handler_CALL(void)
{
    TimingDelay_Decrement();
}

////////////////////////////////////////////////////////////////////////////////
/// @brief  delay nTime ms
/// @note   get x times.
/// @param  nTime  nTime ms.
/// @retval None.
////////////////////////////////////////////////////////////////////////////////
void delay_ms(__IO uint32_t nTime)
{
    TimingDelay = nTime;

    while(TimingDelay > 0)
    {
    }
}

////////////////////////////////////////////////////////////////////////////////
/// @brief  Pin initialization configuration
/// @note   None.
/// @param  None.
/// @retval None.
////////////////////////////////////////////////////////////////////////////////
void I2C_GPIO_Config(void)
{
    GPIO_InitTypeDef GPIO_InitStructure;
    //Configure I2C1 Pins:SCL and SDA
    RCC_AHBPeriphClockCmd(I2C1_SCL_BUSCLK, ENABLE);
    RCC_AHBPeriphClockCmd(I2C1_SDA_BUSCLK, ENABLE);
    GPIO_InitStructure.GPIO_Pin = I2C1_SCL_PIN ;
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_10MHz;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_OD;
    GPIO_Init(I2C1_SCL_PORT, &GPIO_InitStructure);
    GPIO_InitStructure.GPIO_Pin = I2C1_SDA_PIN;
    GPIO_Init(I2C1_SDA_PORT, &GPIO_InitStructure);
}

////////////////////////////////////////////////////////////////////////////////
/// @brief  Pin delay.
/// @note   Setting according to the selected clock.
/// @param  None.
/// @retval None.
////////////////////////////////////////////////////////////////////////////////
static void I2C_delay(void)
{
    //set I2C SCL speed
    u8 i = 13;

    while(i)
    {
        i--;
    }
}

////////////////////////////////////////////////////////////////////////////////
/// @brief  IIC start flag.
/// @note   Pay attention to start and end sequence diagrams when problems arise.
/// @param  None.
/// @retval None.
////////////////////////////////////////////////////////////////////////////////
bool I2C_Start(void)
{
    I2C_delay();
    SDA_H;
    SCL_H;
    I2C_delay();
    //If the SDA line is low level, the bus will fail and quit.
    if(!SDA_read) return FALSE;

    SDA_L;
    I2C_delay();
    //If the SDA line is high level, the bus will fail and quit.
    if(SDA_read) return FALSE;

    SDA_L;
    I2C_delay();
    return TRUE;
}

////////////////////////////////////////////////////////////////////////////////
/// @brief  IIC stop flag.
/// @note   Pay attention to start and end sequence diagrams when problems arise.
/// @param  None.
/// @retval None.
////////////////////////////////////////////////////////////////////////////////
void I2C_Stop(void)
{
    SCL_L;
    I2C_delay();
    SDA_L;
    I2C_delay();
    SCL_H;
    I2C_delay();
    SDA_H;
    I2C_delay();
}

////////////////////////////////////////////////////////////////////////////////
/// @brief  IIC ACK flag.
/// @note   Pay attention to diagrams when problems arise.
/// @param  None.
/// @retval None.
////////////////////////////////////////////////////////////////////////////////
void I2C_Ack(void)
{
    SCL_L;
    I2C_delay();
    SDA_L;
    I2C_delay();
    SCL_H;
    I2C_delay();
    SCL_L;
    I2C_delay();
}

////////////////////////////////////////////////////////////////////////////////
/// @brief  IIC ACK flag.
/// @note   Pay attention to diagrams when problems arise.
/// @param  None.
/// @retval None.
////////////////////////////////////////////////////////////////////////////////
void I2C_NoAck(void)
{
    SCL_L;
    I2C_delay();
    SDA_H;
    I2C_delay();
    SCL_H;
    I2C_delay();
    SCL_L;
    I2C_delay();
}

////////////////////////////////////////////////////////////////////////////////
/// @brief  Wait IIC ACK flag.
/// @note   Pay attention to diagrams when problems arise.
/// @param  None.
/// @retval None.
////////////////////////////////////////////////////////////////////////////////
bool I2C_WaitAck(void)
{
    bool bstatus;
    SCL_L;
    I2C_delay();
    SDA_H;
    I2C_delay();
    SCL_H;
    I2C_delay();
    if(SDA_read)
    {
        //  No ack
        bstatus = FALSE;
    }
    else
    {
        //  ack
        bstatus = TRUE;
    }
    SCL_L;
    return bstatus;

}

////////////////////////////////////////////////////////////////////////////////
/// @brief  Send data.
/// @note   Data from high to low.
/// @param  SendByte(send a byte data ).
/// @retval None.
////////////////////////////////////////////////////////////////////////////////
void I2C_SendByte(u8 SendByte)
{
    u8 i = 8;
    while(i--)
    {
        SCL_L;
        I2C_delay();
        if(SendByte & 0x80)
            SDA_H;
        else
            SDA_L;
        SendByte <<= 1;
        I2C_delay();
        SCL_H;
        I2C_delay();

    }
    SCL_L;
}

////////////////////////////////////////////////////////////////////////////////
/// @brief  Receive data.
/// @note   Data from high to low.
/// @param  None.
/// @retval ReceiveByte(receive a byte data ).
////////////////////////////////////////////////////////////////////////////////
u8 I2C_ReceiveByte(void)
{
    u8 i = 8;
    u8 ReceiveByte = 0;

    SDA_H;
    while(i--)
    {
        ReceiveByte <<= 1;
        SCL_L;
        I2C_delay();
        SCL_H;
        I2C_delay();
        if(SDA_read)
        {
            ReceiveByte |= 0x01;
        }
    }
    SCL_L;
    return ReceiveByte;
}

////////////////////////////////////////////////////////////////////////////////
/// @brief  Write data to EEPROM.
/// @note   None.
/// @param  SendByte(send a byte data ).
/// @param  WriteAddress(Starting address ).
/// @param  DeviceAddress(Equipment Address ).
/// @retval None.
////////////////////////////////////////////////////////////////////////////////
bool EEPROM_ByteWrite(u8 SendByte, u16 WriteAddress, u8 DeviceAddress)
{
    if(!I2C_Start()) return FALSE;

    //Setting High Start Address + Device Address.
    I2C_SendByte(((WriteAddress & 0x0700) >> 7) | (DeviceAddress & 0xFE));

    if(!I2C_WaitAck())
    {
        I2C_Stop();
        return FALSE;
    }
    //Setting Low Start Address
    I2C_SendByte((u8)(WriteAddress & 0x00FF));
    I2C_WaitAck();
    I2C_SendByte(SendByte);
    I2C_WaitAck();
    I2C_Stop();
    //Because you are waiting for the EERPOM write to complete, you can use
    //query or latency��10ms��
    Systick_Delay_1ms(10);
    return TRUE;
}

////////////////////////////////////////////////////////////////////////////////
/// @brief  Write data to EEPROM.
/// @note   None.
/// @param  SendByte(send a byte data ).
/// @param  WriteAddress(Starting address ).
/// @param  DeviceAddress(Equipment Address ).
/// @retval None.
////////////////////////////////////////////////////////////////////////////////
bool EEPROM_PageWrite(u8 *pBuffer, u8 length, u16 WriteAddress, u8 DeviceAddress)
{
    if((length + WriteAddress % I2C_PageSize) > I2C_PageSize) return FALSE;
    if(!I2C_Start()) return FALSE;
    //Setting High Start Address + Device Address.
    I2C_SendByte(((WriteAddress & 0x0700) >> 7) | (DeviceAddress & 0xFE));

    if(!I2C_WaitAck())
    {
        I2C_Stop();
        return FALSE;
    }
    //Setting Low Start Address
    I2C_SendByte((u8)(WriteAddress & 0x00FF));
    I2C_WaitAck();

    while(length--)
    {
        I2C_SendByte(*pBuffer);
        I2C_WaitAck();
        pBuffer++;
    }
    I2C_Stop();
    //Because you are waiting for the EERPOM write to complete, you can use
    //query or latency��10ms��
    Systick_Delay_1ms(10);
    return TRUE;
}

////////////////////////////////////////////////////////////////////////////////
/// @brief  Write data to EEPROM.
/// @note   None.
/// @param  SendByte(send a byte data ).
/// @param  WriteAddress(Starting address ).
/// @param  DeviceAddress(Equipment Address ).
/// @retval None.
////////////////////////////////////////////////////////////////////////////////
void EEPROM_BufferWrite(u8 *pBuffer, u16 length, u16 WriteAddress, u8 DeviceAddress )
{
    u16 i;
    u16 Addr = 0, count = 0;
    //Write address is the first page of the start page.
    Addr = WriteAddress % I2C_PageSize;
    //Number of entries to be written on the start page
    count = I2C_PageSize - Addr;
    if(length <= count)
    {
        //Write only one page of data
        EEPROM_PageWrite(pBuffer, length, WriteAddress, DeviceAddress);
    }
    else
    {
        //Write the data on the first page first.
        EEPROM_PageWrite(pBuffer, count, WriteAddress, DeviceAddress);
        if((length - count) <= I2C_PageSize)
        {
            //Write one more page at the end of the data
            EEPROM_PageWrite(pBuffer + count, length - count, WriteAddress + count, DeviceAddress);
        }
        else
        {
            for(i = 0; i < ((length - count) / I2C_PageSize); i++)
            {
                EEPROM_PageWrite(pBuffer + count + i * I2C_PageSize, I2C_PageSize, WriteAddress + count + i * I2C_PageSize, DeviceAddress);
            }
            if( ((length - count) % I2C_PageSize) != 0 )
            {
                EEPROM_PageWrite(pBuffer + count + i * I2C_PageSize, ((length - count) % I2C_PageSize), WriteAddress + count + i * I2C_PageSize, DeviceAddress);
            }
        }
    }
}

////////////////////////////////////////////////////////////////////////////////
/// @brief  read data from EEPROM.
/// @note   None.
/// @param  ReadByte(receive a byte data ).
/// @param  WriteAddress(Starting address ).
/// @param  DeviceAddress(Equipment Address ).
/// @retval None.
////////////////////////////////////////////////////////////////////////////////
bool EEPROM_RandomRead(u8 *pByte, u16 ReadAddress, u8 DeviceAddress)
{
    if(!I2C_Start()) return FALSE;
    //Setting High Start Address + Device Address.
    I2C_SendByte(((ReadAddress & 0x0700) >> 7) | (DeviceAddress & 0xFE));
    if(!I2C_WaitAck())
    {
        I2C_Stop();
        return FALSE;
    }
    I2C_SendByte((u8)(ReadAddress & 0x00FF));
    I2C_WaitAck();
    I2C_Start();
    I2C_SendByte(((ReadAddress & 0x0700) >> 7) | (DeviceAddress | 0x0001));
    I2C_WaitAck();
    *pByte = I2C_ReceiveByte();
    I2C_NoAck();
    I2C_Stop();
    return TRUE;
}

////////////////////////////////////////////////////////////////////////////////
/// @brief  read data from EEPROM.
/// @note   None.
/// @param  ReadByte(receive a byte data ).
/// @param  WriteAddress(Starting address ).
/// @param  DeviceAddress(Equipment Address ).
/// @retval None.
////////////////////////////////////////////////////////////////////////////////
bool EEPROM_SequentialRead(u8 *pBuffer, u8 length, u16 ReadAddress, u8 DeviceAddress)
{
    if(!I2C_Start()) return FALSE;
    //Setting High Start Address + Device Address.
    I2C_SendByte(((ReadAddress & 0x0700) >> 7) | (DeviceAddress & 0xFE));
    if(!I2C_WaitAck())
    {
        I2C_Stop();
        return FALSE;
    }
    I2C_SendByte((u8)(ReadAddress & 0x00FF));
    I2C_WaitAck();
    I2C_Start();
    I2C_SendByte(((ReadAddress & 0x0700) >> 7) | (DeviceAddress | 0x0001));
    I2C_WaitAck();
    while(length)
    {
        *pBuffer = I2C_ReceiveByte();
        if(length == 1) I2C_NoAck();
        else I2C_Ack();
        pBuffer++;
        length--;
    }
    I2C_Stop();
    return TRUE;
}

////////////////////////////////////////////////////////////////////////////////
/// @brief  Write address.
/// @note   None.
/// @param  ReadByte(receive a byte data ).
/// @param  WriteAddress(Starting address ).
/// @param  DeviceAddress(Equipment Address ).
/// @retval None.
////////////////////////////////////////////////////////////////////////////////
void I2CEEPROMWriteany(u16 addr, u8* ptr, u16 cnt)
{
    EEPROM_BufferWrite(ptr, cnt, addr, 0xA0);
}

////////////////////////////////////////////////////////////////////////////////
/// @brief  This function is main entrance.
/// @param  None.
/// @retval None.
////////////////////////////////////////////////////////////////////////////////
int main(void)
{
    u16 i;
    u16 temp;

    SetSystemClock(emSYSTICK_On, NULL);
    LED_Init();

    //Use I2C1 Port to connect external I2C interface type EEPROM 24C02;
    //run Write and Read series bytes Data;
    //Initial I2C
    I2C_Initialize();
    //Write 16 bytes from buffer0[128] to 0x10 of EEPROM
    I2CEEPROMWrite(0x10, buffer0, 0x10);
    //Read 16 bytes from 0x10 of EEPROM to buffer1[128]
    I2CEEPROMRead(0x10, buffer1, 0x10);
    for(i = 0; i < 0x10; i++)
    {
        buffer0[i] = i;
    }
    I2CEEPROMWriteany(0x20, buffer0, 0x8);
    I2CEEPROMRead(0x20, buffer1, 0x08);
    I2CEEPROMWriteany(0x20 + 0x8, buffer0, 0x8 + 0x8);
    I2CEEPROMRead(0x20 + 0x8, buffer1, 0x8 + 0x8);

    temp = 0;
    for(i = 0; i < 0x10; i++)
    {
        if((buffer0[i]) == (buffer1[i]))
        {
            temp++;
        }
    }
    while(1)
    {
        LED1_TOGGLE();
        if(temp < 0x10)
        {
            delay_ms(100);
        }

        else
        {
            delay_ms(500);
        }
    }
}

////////////////////////////////////////////////////////////////////////////////
/// @brief  Initial I2C.
/// @param  None.
/// @retval None.
////////////////////////////////////////////////////////////////////////////////
void I2C_Initialize()
{
    I2C_GPIO_Config();
}

////////////////////////////////////////////////////////////////////////////////
/// @brief  Write a data packet.
/// @note   None.
/// @param  addr (Sub address of EEPROM)
/// @param  ptr (Data in the buffer)
/// @param  cnt (Number of data)
/// @retval None.
////////////////////////////////////////////////////////////////////////////////
void I2CEEPROMWrite(u16 addr, u8 *ptr, u16 cnt)
{
    u16 i;
    for(i = 0; i < cnt; i++)
    {
        EEPROM_ByteWrite(*ptr++, addr + i, 0xA0);
        delay_ms(1);
    }
}

////////////////////////////////////////////////////////////////////////////////
/// @brief  Receive a data packet.
/// @note   None.
/// @param  addr (Sub address of EEPROM)
/// @param  ptr (Data in the buffer)
/// @param  cnt (Number of data)
/// @retval None.
////////////////////////////////////////////////////////////////////////////////
void I2CEEPROMRead(u16 addr, u8* ptr, u16 cnt)
{
    EEPROM_SequentialRead(ptr, cnt, addr, 0xA0);
}

////////////////////////////////////////////////////////////////////////////////
/// @brief  RCC clock set.
/// @note   None.
/// @param  Portx , State
/// @retval None.
////////////////////////////////////////////////////////////////////////////////
void GPIO_Clock_Set(GPIO_TypeDef* GPIOx, FunctionalState NewState)
{
    if(GPIOx == GPIOA)
    {
        RCC_AHBPeriphClockCmd(RCC_AHBPeriph_GPIOA, NewState);
    }
    if(GPIOx == GPIOB)
    {
        RCC_AHBPeriphClockCmd(RCC_AHBPeriph_GPIOB, NewState);
    }
    if(GPIOx == GPIOC)
    {
        RCC_AHBPeriphClockCmd(RCC_AHBPeriph_GPIOC, NewState);
    }
    if(GPIOx == GPIOD)
    {
        RCC_AHBPeriphClockCmd(RCC_AHBPeriph_GPIOD, NewState);
    }
}

////////////////////////////////////////////////////////////////////////////////
/// @brief  Initial LED.
/// @param  None.
/// @retval None.
////////////////////////////////////////////////////////////////////////////////
void LED_Init(void)
{

    GPIO_InitTypeDef  GPIO_InitStructure;

    GPIO_Clock_Set(LED1_Port, ENABLE);

    GPIO_InitStructure.GPIO_Pin  =  LED1_Pin;
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
    GPIO_Init(LED1_Port, &GPIO_InitStructure);


    LED1_OFF();

}

/// @}


/// @}

/// @}

