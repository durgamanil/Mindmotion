////////////////////////////////////////////////////////////////////////////////
/// @file     I2C_POLL_WR_EEPROM.c
/// @author   AE TEAM
/// @version  v1.0.0
/// @date     2019-09-20
/// @brief    Using IIC to send and read EEPROM(24C02)
////////////////////////////////////////////////////////////////////////////////
/// @attention
///
/// THE EXISTING FIRMWARE IS ONLY FOR REFERENCE, WHICH IS DESIGNED TO PROVIDE
/// CUSTOMERS WITH CODING INFORMATION ABOUT THEIR PRODUCTS SO THEY CAN SAVE
/// TIME. THEREFORE, MINDMOTION SHALL NOT BE LIABLE FOR ANY DIRECT, INDIRECT OR
/// CONSEQUENTIAL DAMAGES ABOUT ANY CLAIMS ARISING OUT OF THE CONTENT OF SUCH
/// HARDWARE AND/OR THE USE OF THE CODING INFORMATION CONTAINED HEREIN IN
/// CONNECTION WITH PRODUCTS MADE BY CUSTOMERS.
///
/// <H2><CENTER>&COPY; COPYRIGHT 2018-2019 MINDMOTION </CENTER></H2>
////////////////////////////////////////////////////////////////////////////////
#include "string.h"
#include "HAL_device.h"
#include "stdio.h"
#include "stdbool.h"
#include "HAL_conf.h"

#define USEPB89AS_SCLSDA
#ifdef USEPB67AS_SCLSDA

#define I2C1_SCL_BUSCLK                  RCC_AHBPeriph_GPIOB
#define I2C1_SCL_PIN                     GPIO_Pin_6
#define I2C1_SCL_PORT                    GPIOB
#define I2C1_SCL_AFSOURCE                GPIO_PinSource6
#define I2C1_SCL_AFMODE                  GPIO_AF_1

#define I2C1_SDA_BUSCLK                  RCC_AHBPeriph_GPIOB
#define I2C1_SDA_PIN                     GPIO_Pin_7
#define I2C1_SDA_PORT                    GPIOB
#define I2C1_SDA_AFSOURCE                GPIO_PinSource7
#define I2C1_SDA_AFMODE                  GPIO_AF_1
#endif


#ifdef USEPB89AS_SCLSDA

#define I2C1_SCL_BUSCLK                  RCC_AHBPeriph_GPIOB
#define I2C1_SCL_PIN                     GPIO_Pin_8
#define I2C1_SCL_PORT                    GPIOB
#define I2C1_SCL_AFSOURCE                GPIO_PinSource8
#define I2C1_SCL_AFMODE                  GPIO_AF_1

#define I2C1_SDA_BUSCLK                  RCC_AHBPeriph_GPIOB
#define I2C1_SDA_PIN                     GPIO_Pin_9
#define I2C1_SDA_PORT                    GPIOB
#define I2C1_SDA_AFSOURCE                GPIO_PinSource9
#define I2C1_SDA_AFMODE                  GPIO_AF_1
#endif
#ifdef USEPB1011AS_SCLSDA

#define I2C1_SCL_BUSCLK                  RCC_AHBPeriph_GPIOB
#define I2C1_SCL_PIN                     GPIO_Pin_10
#define I2C1_SCL_PORT                    GPIOB
#define I2C1_SCL_AFSOURCE                GPIO_PinSource10
#define I2C1_SCL_AFMODE                  GPIO_AF_1

#define I2C1_SDA_BUSCLK                  RCC_AHBPeriph_GPIOB
#define I2C1_SDA_PIN                     GPIO_Pin_11
#define I2C1_SDA_PORT                    GPIOB
#define I2C1_SDA_AFSOURCE                GPIO_PinSource11
#define I2C1_SDA_AFMODE                  GPIO_AF_1
#endif
#ifdef USEPB1314AS_SCLSDA

#define I2C1_SCL_BUSCLK                  RCC_AHBPeriph_GPIOB
#define I2C1_SCL_PIN                     GPIO_Pin_13
#define I2C1_SCL_PORT                    GPIOB
#define I2C1_SCL_AFSOURCE                GPIO_PinSource13
#define I2C1_SCL_AFMODE                  GPIO_AF_5

#define I2C1_SDA_BUSCLK                  RCC_AHBPeriph_GPIOB
#define I2C1_SDA_PIN                     GPIO_Pin_14
#define I2C1_SDA_PORT                    GPIOB
#define I2C1_SDA_AFSOURCE                GPIO_PinSource14
#define I2C1_SDA_AFMODE                  GPIO_AF_5
#endif
#ifdef USEPA54AS_SCLSDA

#define I2C1_SCL_BUSCLK                  RCC_AHBPeriph_GPIOA
#define I2C1_SCL_PIN                     GPIO_Pin_5
#define I2C1_SCL_PORT                    GPIOA
#define I2C1_SCL_AFSOURCE                GPIO_PinSource5
#define I2C1_SCL_AFMODE                  GPIO_AF_5

#define I2C1_SDA_BUSCLK                  RCC_AHBPeriph_GPIOA
#define I2C1_SDA_PIN                     GPIO_Pin_4
#define I2C1_SDA_PORT                    GPIOA
#define I2C1_SDA_AFSOURCE                GPIO_PinSource4
#define I2C1_SDA_AFMODE                  GPIO_AF_5
#endif

#ifdef USEPA910AS_SCLSDA

#define I2C1_SCL_BUSCLK                  RCC_AHBPeriph_GPIOA
#define I2C1_SCL_PIN                     GPIO_Pin_9
#define I2C1_SCL_PORT                    GPIOA
#define I2C1_SCL_AFSOURCE                GPIO_PinSource9
#define I2C1_SCL_AFMODE                  GPIO_AF_4

#define I2C1_SDA_BUSCLK                  RCC_AHBPeriph_GPIOA
#define I2C1_SDA_PIN                     GPIO_Pin_10
#define I2C1_SDA_PORT                    GPIOA
#define I2C1_SDA_AFSOURCE                GPIO_PinSource10
#define I2C1_SDA_AFMODE                  GPIO_AF_4
#endif
#ifdef USEPA1112AS_SCLSDA

#define I2C1_SCL_BUSCLK                  RCC_AHBPeriph_GPIOA
#define I2C1_SCL_PIN                     GPIO_Pin_11
#define I2C1_SCL_PORT                    GPIOA
#define I2C1_SCL_AFSOURCE                GPIO_PinSource11
#define I2C1_SCL_AFMODE                  GPIO_AF_5

#define I2C1_SDA_BUSCLK                  RCC_AHBPeriph_GPIOA
#define I2C1_SDA_PIN                     GPIO_Pin_12
#define I2C1_SDA_PORT                    GPIOA
#define I2C1_SDA_AFSOURCE                GPIO_PinSource12
#define I2C1_SDA_AFMODE                  GPIO_AF_5
#endif
#ifdef USEPD10AS_SCLSDA

#define I2C1_SCL_BUSCLK                  RCC_AHBPeriph_GPIOD
#define I2C1_SCL_PIN                     GPIO_Pin_1
#define I2C1_SCL_PORT                    GPIOD
#define I2C1_SCL_AFSOURCE                GPIO_PinSource1
#define I2C1_SCL_AFMODE                  GPIO_AF_1

#define I2C1_SDA_BUSCLK                  RCC_AHBPeriph_GPIOD
#define I2C1_SDA_PIN                     GPIO_Pin_0
#define I2C1_SDA_PORT                    GPIOD
#define I2C1_SDA_AFSOURCE                GPIO_PinSource0
#define I2C1_SDA_AFMODE                  GPIO_AF_1
#endif
//The size of each EEPROM page
#define PAGESIZE 16
//Device address of EEPROM
#define EEPROM_ADDR 0xA8
#define MAX(a,b)((a)>(b)?(a):(b))
#define MIN(a,b)((a)<(b)?(a):(b))
typedef struct
{
    //Flag of whether I2C is transmitting
    u8 busy;
    u8 ack;
    //Flag of whether I2C is right
    u8 fault;
    //Flag of I2C transmission direction
    u8 opt;
    //sub address
    u8 sub;
    //number
    u8 cnt;
    //buffer
    u8 *ptr;
    //used to determine if sub addresses need to be sent in interrupt
    u8 sadd;
} i2c_def;
i2c_def i2c;
//write or read
enum {WR, RD};



void I2CWrite(u8 sub, u8* ptr, u16 len);
void I2CRead(u8 sub, u8* ptr, u16 len);
void I2C_MasterMode_Init(I2C_TypeDef *I2Cx, u32 uiI2C_speed);
void I2C_SetDeviceAddr(I2C_TypeDef *I2Cx, u8 deviceaddr);
void I2C_WaitEEready(void);
void I2C_TXByte(u8 dat);
u8   I2C_SendBytes(u8 sub, u8* ptr, u16 cnt);
u8   I2C_SendPacket(u8 sub, u8* ptr, u16 cnt);
void I2C_RevBytes(void);
void I2C_RcvPacket(u8 sub, u8* ptr, u16 cnt);
void I2C_Check(void);
void I2C_Initialize(void);

u8 buffer0[128] = {0xaa, 0xbb, 0xcc, 0xdd, 0xee, 0xff, 0x11, 0x22, 0x33, 0x44, 0x55, 0x66, 0x77, 0x88, 0x99};
u8 buffer1[128];
static __IO uint32_t TimingDelay;
#ifndef NULL
#define NULL  _NULL
#endif

////////////////////////////////////////////////////////////////////////////////
/// @brief  This function make delay count decrement as one systick
///         for example , delay (1ms)
/// @note   when decrement to zero�� it always 0.
/// @param  None.
/// @retval None.
////////////////////////////////////////////////////////////////////////////////
void TimingDelay_Decrement(void)
{
    if (TimingDelay > 0x00)
    {
        TimingDelay--;
    }
}

////////////////////////////////////////////////////////////////////////////////
/// @brief  This function is called back by SysTick Handler
///         call series function to run systick cycle running
///         for example , delay, led blink, key in scan , etc.
/// @note   This function always run after power on.
/// @param  None.
/// @retval None.
////////////////////////////////////////////////////////////////////////////////
void SysTick_Handler_CALL(void)
{
    TimingDelay_Decrement();
}

////////////////////////////////////////////////////////////////////////////////
/// @brief  This function is main entrance.
/// @param  None.
/// @retval None.
////////////////////////////////////////////////////////////////////////////////
int main(void)
{

    SetSystemClock(emSYSTICK_On, NULL);

    //Initial I2C
    I2C_Initialize();
    //Write 16 bytes from buffer0[128] to 0x10 of EEPROM
    I2CWrite(0x10, buffer0, 0x10);
    //Read 16 bytes from 0x10 of EEPROM to buffer1[128]
    I2CRead(0x10, buffer1, 0x10);

    while(1)
    {

    }
}

////////////////////////////////////////////////////////////////////////////////
/// @brief  I2CWrite
/// @note   Write a data packet.
/// @param  : sub (Sub address of EEPROM)
/// @param  : ptr (Data in the buffer)
/// @param  : len (Number of data)
/// @retval : None.
////////////////////////////////////////////////////////////////////////////////
void I2CWrite(u8 sub, u8* ptr, u16 len)
{
    do
    {
        //write data
        I2C_SendPacket(sub, ptr, len);
        //till I2C is not work
        while(i2c.busy);
    }
    while(!i2c.ack);
}

////////////////////////////////////////////////////////////////////////////////
/// @brief  I2CRead
/// @note   Receive a data packet.
/// @param  : sub (Sub address of EEPROM)
/// @param  : ptr (Buffer to storage data)
/// @param  : len (Number of data)
/// @retval : None.
////////////////////////////////////////////////////////////////////////////////
void I2CRead(u8 sub, u8* ptr, u16 len)
{
    do
    {
        //read data
        I2C_RcvPacket(sub, ptr, len);
        //till I2C is not work
        while(i2c.busy);
    }
    while(!i2c.ack);
}

////////////////////////////////////////////////////////////////////////////////
/// @brief  Clock and data bus configuration
/// @note   Keep the bus free which means SCK & SDA is high.
/// @param  : None.
/// @retval : None.
////////////////////////////////////////////////////////////////////////////////
void I2C1BusFreeGPIOMode(void)
{

    //I2C uses PB6, PB7
    GPIO_InitTypeDef GPIO_InitStructure;
    RCC_AHBPeriphClockCmd(I2C1_SCL_BUSCLK, ENABLE);

    GPIO_InitStructure.GPIO_Pin  = I2C1_SCL_PIN;
    //Set GPIO spped
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_20MHz;
    //Keep the bus free which means SCK & SDA is high
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IPU;
    GPIO_Init(I2C1_SCL_PORT, &GPIO_InitStructure);

    RCC_AHBPeriphClockCmd(I2C1_SDA_BUSCLK, ENABLE);

    GPIO_InitStructure.GPIO_Pin  = I2C1_SDA_PIN;
    //Set GPIO spped
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_20MHz;
    //Keep the bus free which means SCK & SDA is high
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IPU;
    GPIO_Init(I2C1_SDA_PORT, &GPIO_InitStructure);
}

////////////////////////////////////////////////////////////////////////////////
/// @brief  Clock and data bus configuration
/// @note   Keep the bus free which means SCK & SDA is high.
/// @param  : None.
/// @retval : None.
////////////////////////////////////////////////////////////////////////////////
void I2C1ConfigGPIOMode(void)
{
    //I2C uses PB6, PB7
    GPIO_InitTypeDef GPIO_InitStructure;
    RCC_AHBPeriphClockCmd(I2C1_SCL_BUSCLK, ENABLE);

    GPIO_InitStructure.GPIO_Pin  = I2C1_SCL_PIN;
    //Set GPIO spped
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_20MHz;
    //Keep the bus free which means SCK & SDA is high
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_OD;
    GPIO_Init(I2C1_SCL_PORT, &GPIO_InitStructure);

    RCC_AHBPeriphClockCmd(I2C1_SDA_BUSCLK, ENABLE);

    GPIO_InitStructure.GPIO_Pin  = I2C1_SDA_PIN;
    //Set GPIO spped
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_20MHz;
    //Keep the bus free which means SCK & SDA is high
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_OD;
    GPIO_Init(I2C1_SDA_PORT, &GPIO_InitStructure);

    GPIO_PinAFConfig(I2C1_SCL_PORT, I2C1_SCL_AFSOURCE, I2C1_SCL_AFMODE);
    GPIO_PinAFConfig(I2C1_SDA_PORT, I2C1_SDA_AFSOURCE, I2C1_SDA_AFMODE);
}

////////////////////////////////////////////////////////////////////////////////
/// @brief  Initializes the I2Cx master mode
/// @note   None.
/// @param  : I2Cx (where x can be 1 or 2 to select the I2C peripheral)
/// @param  : iI2C_speed: I2C speed.
/// @retval : None.
////////////////////////////////////////////////////////////////////////////////
void I2C_MasterMode_Init(I2C_TypeDef *I2Cx, u32 uiI2C_speed)
{
    I2C_InitTypeDef I2C_InitStructure;

    //Enable I2C clock state
    RCC_APB1PeriphClockCmd(RCC_APB1Periph_I2C1, ENABLE);
    I2C1BusFreeGPIOMode();

    //Configure I2C as master mode
    I2C_InitStructure.Mode = I2C_CR_MASTER;
    I2C_InitStructure.OwnAddress = 0;
    I2C_InitStructure.Speed = I2C_CR_STD;
    I2C_InitStructure.ClockSpeed = uiI2C_speed;

    //Initializes the I2Cx peripheral according to the specified
    I2C_Init(I2Cx, &I2C_InitStructure);
    I2C_Cmd(I2Cx, ENABLE);

    I2C1ConfigGPIOMode();

}

////////////////////////////////////////////////////////////////////////////////
/// @brief  Set the device address
/// @note   None.
/// @param  : I2Cx(where x can be 1 or 2 to select the I2C peripheral)
/// @param  : deviceaddr(device address).
/// @retval : None.
////////////////////////////////////////////////////////////////////////////////
void I2C_SetDeviceAddr(I2C_TypeDef *I2Cx, u8 deviceaddr)
{
    I2C1BusFreeGPIOMode();

    //Disable I2C
    I2C_Cmd(I2Cx, DISABLE);
    //Set the device address
    I2C_Send7bitAddress(I2Cx, deviceaddr, I2C_Direction_Transmitter);
    //Enable I2C
    I2C_Cmd(I2Cx, ENABLE);

    I2C1ConfigGPIOMode();
}

////////////////////////////////////////////////////////////////////////////////
/// @brief  Wait for EEPROM getting ready.
/// @note   None.
/// @param  : None.
/// @retval : None.
////////////////////////////////////////////////////////////////////////////////
void I2C_WaitEEready(void)
{
    //eeprom operation interval delay
    u32 i = 10000;
    while(i--);
}

////////////////////////////////////////////////////////////////////////////////
/// @brief  Send a byte.
/// @note   None.
/// @param  : None.
/// @retval : None.
////////////////////////////////////////////////////////////////////////////////
void I2C_TXByte(u8 dat)
{
    //Send data
    I2C_SendData(I2C1, dat);
    //Checks whether transmit FIFO completely empty or not
    while(I2C_GetFlagStatus(I2C1, I2C_STATUS_FLAG_TFE) == 0);
}

////////////////////////////////////////////////////////////////////////////////
/// @brief  Receive a byte.
/// @note   None.
/// @param  : None.
/// @retval : None.
////////////////////////////////////////////////////////////////////////////////
void I2C_RevBytes(void)
{
    u8 i, flag = 0, _cnt = 0;
    for (i = 0; i < i2c.cnt; i++)
    {
        while(1)
        {
            //Write command is sent when RX FIFO is not full
            if ((I2C_GetFlagStatus(I2C1, I2C_STATUS_FLAG_TFNF)) && (flag == 0))
            {
                //Configure to read
                I2C_ReadCmd(I2C1);
                _cnt++;
                //When flag is set, receive complete
                if (_cnt == i2c.cnt)
                    flag = 1;
            }
            //Check receive FIFO not empty
            if (I2C_GetFlagStatus(I2C1, I2C_STATUS_FLAG_RFNE))
            {
                //read data to i2c.ptr
                i2c.ptr[i] = I2C_ReceiveData(I2C1);
                break;
            }
        }
    }
}

////////////////////////////////////////////////////////////////////////////////
/// @brief  Send bytes
/// @note   None.
/// @param  : sub(Sub address of EEPROM)
/// @param  : ptr(Data in the buffer)
/// @param  : cnt(Number of data)
/// @retval : None.
////////////////////////////////////////////////////////////////////////////////
u8 I2C_SendBytes(u8 sub, u8* ptr, u16 cnt)
{
    //Send sub address
    I2C_TXByte(sub);
    while (cnt --)
    {
        //Send data
        I2C_TXByte(*ptr);
        //Point to the next data
        ptr++;
    }
    //Stop transmission
    I2C_GenerateSTOP(I2C1, ENABLE);
    //Checks whether stop condition has occurred or not.
    while((I2C_GetITStatus(I2C1, I2C_IT_STOP_DET)) == 0);
    i2c.ack = true;
    //I2C operation stops
    i2c.busy = false;
    //Wait for EEPROM getting ready.
    I2C_WaitEEready();
    return true;
}

////////////////////////////////////////////////////////////////////////////////
/// @brief  Send a data packet
/// @note   None.
/// @param  : sub(Sub address of EEPROM)
/// @param  : ptr(Data in the buffer)
/// @param  : cnt(Number of data)
/// @retval : The state of this transmission.
////////////////////////////////////////////////////////////////////////////////
u8 I2C_SendPacket(u8 sub, u8* ptr, u16 cnt)
{
    u8 i;
    //i2c option flag set to write
    i2c.opt = WR;
    //number to send
    i2c.cnt = cnt;
    //sub address
    i2c.sub = sub;
    //I2C operation starts
    i2c.busy = true;
    i2c.ack = false;

    if ((sub % PAGESIZE) > 0)
    {
        //Need temp number of data, just right to the page address
        u8 temp = MIN((PAGESIZE - sub % PAGESIZE), i2c.cnt);
        //If WRITE successful
        if(I2C_SendBytes(sub, ptr, temp))
        {
            //Point to the next page
            ptr +=  temp;
            i2c.cnt -=  temp;
            sub += temp;
        }
        //i2c.cnt = 0 means transmition complete
        if (i2c.cnt == 0) return true;
    }
    for (i = 0; i < (i2c.cnt / PAGESIZE); i++)
    {
        //Full page write
        if (I2C_SendBytes(sub, ptr, PAGESIZE))
        {
            //Point to the next page
            ptr += PAGESIZE;
            sub += PAGESIZE;
            i2c.cnt -= PAGESIZE;
        }
        if (i2c.cnt == 0) return true;
    }
    if (i2c.cnt > 0)
    {
        if (I2C_SendBytes(sub, ptr, i2c.cnt)) return true;
    }
    //I2C operation ends
    i2c.busy = false;
    i2c.ack = true;
    return false;
}

////////////////////////////////////////////////////////////////////////////////
/// @brief  Receive a data packet
/// @note   None.
/// @param  : sub(Sub address of EEPROM)
/// @param  : ptr(Data in the buffer)
/// @param  : cnt(Number of data)
/// @retval : None.
////////////////////////////////////////////////////////////////////////////////
void I2C_RcvPacket(u8 sub, u8* ptr, u16 cnt)
{
    //I2C operation starts
    i2c.busy = true;
    i2c.ack = false;
    i2c.sub = sub;
    i2c.ptr = ptr;
    i2c.cnt = cnt;

    //Send sub address
    I2C_TXByte(i2c.sub);
    //receive bytes
    I2C_RevBytes();
    //Stop transmission
    I2C_GenerateSTOP(I2C1, ENABLE);
    //Checks whether stop condition has occurred or not.
    while((I2C_GetITStatus(I2C1, I2C_IT_STOP_DET)) == 0);

    //I2C operation ends
    i2c.busy = false;
    i2c.ack = true;
    I2C_WaitEEready();
}

////////////////////////////////////////////////////////////////////////////////
/// @brief  Initial I2C
/// @note   None.
/// @param  : None.
/// @retval : None.
////////////////////////////////////////////////////////////////////////////////
void I2C_Initialize()
{
    //Initial value of i2c struct
    memset(&i2c, 0x00, sizeof(i2c));
    //Initializes the I2C master mode
    I2C_MasterMode_Init(I2C1, 100000);
    //Set the EEPROM address
    I2C_SetDeviceAddr(I2C1, EEPROM_ADDR);
}

/// @}


/// @}

/// @}




