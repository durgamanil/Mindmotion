////////////////////////////////////////////////////////////////////////////////
/// @file     I2C_EEPROM_DMA.c
/// @author   AE TEAM
/// @version  v1.0.0
/// @date     2019-09-20
/// @brief    Using DMA to send and read EEPROM through IIC bus
////////////////////////////////////////////////////////////////////////////////
/// @attention
///
/// THE EXISTING FIRMWARE IS ONLY FOR REFERENCE, WHICH IS DESIGNED TO PROVIDE
/// CUSTOMERS WITH CODING INFORMATION ABOUT THEIR PRODUCTS SO THEY CAN SAVE
/// TIME. THEREFORE, MINDMOTION SHALL NOT BE LIABLE FOR ANY DIRECT, INDIRECT OR
/// CONSEQUENTIAL DAMAGES ABOUT ANY CLAIMS ARISING OUT OF THE CONTENT OF SUCH
/// HARDWARE AND/OR THE USE OF THE CODING INFORMATION CONTAINED HEREIN IN
/// CONNECTION WITH PRODUCTS MADE BY CUSTOMERS.
///
/// <H2><CENTER>&COPY; COPYRIGHT 2018-2019 MINDMOTION </CENTER></H2>
////////////////////////////////////////////////////////////////////////////////
#include "HAL_device.h"
#include "HAL_conf.h"
#include "HAL_rcc.h"
#include "stdio.h"

void uart_initwBaudRate(u32 bound);
void I2C1MasterDMATest(void);
void I2C1_DMA_TX(unsigned char *tx_buf, unsigned short size);
void I2CInitMasterMode(void);
void DMA_I2C1MasterWrite(unsigned char device_id, unsigned short mem_byte_addr, unsigned short tx_count, unsigned char *tx_data );
void DMA_I2C1MasterRead(unsigned char device_id, unsigned short mem_byte_addr, unsigned short rx_count, unsigned char *rx_data );
void UartSendGroup(u8* buf, u16 len);
void UartSendAscii(char *str);

#define I2C1_SCL_BUSCLK                  RCC_AHBPeriph_GPIOB
#define I2C1_SCL_PIN                     GPIO_Pin_8
#define I2C1_SCL_PORT                    GPIOB
#define I2C1_SCL_AFSOURCE                GPIO_PinSource8
#define I2C1_SCL_AFMODE                  GPIO_AF_1

#define I2C1_SDA_BUSCLK                  RCC_AHBPeriph_GPIOB
#define I2C1_SDA_PIN                     GPIO_Pin_9
#define I2C1_SDA_PORT                    GPIOB
#define I2C1_SDA_AFSOURCE                GPIO_PinSource9
#define I2C1_SDA_AFMODE                  GPIO_AF_1

unsigned char tx_buffer0[16] = {0xa, 0xb, 0xc, 0xd, 0xe, 0xf, 1, 2, 3, 4, 5, 6, 7, 8, 9, 0};
unsigned char rx_buffer0[16] ;
char printBuf[100];

#define FLASH_DEVICE_ADDR    0xA0
#define EEPROM_ADDR   0xA9

////////////////////////////////////////////////////////////////////////////////
/// @brief  This function is main entrance.
/// @param  None.
/// @retval None.
////////////////////////////////////////////////////////////////////////////////
int main(void)
{
    uart_initwBaudRate(115200);
    //Write and read data from EEPROM.
    I2C1MasterDMATest();

    while(1)
    {

    }
}

////////////////////////////////////////////////////////////////////////////////
/// @brief  Clock and data bus configuration
/// @note   Keep the bus free which means SCK & SDA is high.
/// @param  : None.
/// @retval : None.
////////////////////////////////////////////////////////////////////////////////
void I2C1BusFreeGPIOMode(void)
{

    //I2C uses PB6, PB7
    GPIO_InitTypeDef GPIO_InitStructure;
    RCC_AHBPeriphClockCmd(I2C1_SCL_BUSCLK, ENABLE);

    GPIO_InitStructure.GPIO_Pin  = I2C1_SCL_PIN;
    //Set GPIO spped
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_20MHz;
    //Keep the bus free which means SCK & SDA is high
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IPU;
    GPIO_Init(I2C1_SCL_PORT, &GPIO_InitStructure);

    RCC_AHBPeriphClockCmd(I2C1_SDA_BUSCLK, ENABLE);

    GPIO_InitStructure.GPIO_Pin  = I2C1_SDA_PIN;
    //Set GPIO spped
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_20MHz;
    //Keep the bus free which means SCK & SDA is high
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IPU;
    GPIO_Init(I2C1_SDA_PORT, &GPIO_InitStructure);
}

////////////////////////////////////////////////////////////////////////////////
/// @brief  Clock and data bus configuration
/// @note   Keep the bus free which means SCK & SDA is high.
/// @param  : None.
/// @retval : None.
////////////////////////////////////////////////////////////////////////////////
void I2C1ConfigGPIOMode(void)
{
    //I2C uses PB6, PB7
    GPIO_InitTypeDef GPIO_InitStructure;
    RCC_AHBPeriphClockCmd(I2C1_SCL_BUSCLK, ENABLE);

    GPIO_InitStructure.GPIO_Pin  = I2C1_SCL_PIN;
    //Set GPIO spped
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_20MHz;
    //Keep the bus free which means SCK & SDA is high
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_OD;
    GPIO_Init(I2C1_SCL_PORT, &GPIO_InitStructure);

    RCC_AHBPeriphClockCmd(I2C1_SDA_BUSCLK, ENABLE);

    GPIO_InitStructure.GPIO_Pin  = I2C1_SDA_PIN;
    //Set GPIO spped
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_20MHz;
    //Keep the bus free which means SCK & SDA is high
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_OD;
    GPIO_Init(I2C1_SDA_PORT, &GPIO_InitStructure);

    GPIO_PinAFConfig(I2C1_SCL_PORT, I2C1_SCL_AFSOURCE, I2C1_SCL_AFMODE);
    GPIO_PinAFConfig(I2C1_SDA_PORT, I2C1_SDA_AFSOURCE, I2C1_SDA_AFMODE);
}


////////////////////////////////////////////////////////////////////////////////
/// @brief  Serial port initialization configuration
/// @note   It must be careful of the Chip Version.
/// @param  bound: Baud rate
/// @retval None.
////////////////////////////////////////////////////////////////////////////////
void uart_initwBaudRate(u32 bound)
{

    GPIO_InitTypeDef GPIO_InitStructure;
    UART_InitTypeDef UART_InitStructure;

    RCC_APB2PeriphClockCmd(RCC_APB2Periph_UART1, ENABLE);
    RCC_AHBPeriphClockCmd(RCC_AHBPeriph_GPIOA, ENABLE);

    GPIO_PinAFConfig(GPIOA, GPIO_PinSource9, GPIO_AF_1);
    GPIO_PinAFConfig(GPIOA, GPIO_PinSource10, GPIO_AF_1);

    //Baud rate
    UART_InitStructure.BaudRate = bound;
    //The word length is in 8-bit data format.
    UART_InitStructure.WordLength = UART_WordLength_8b;
    UART_InitStructure.StopBits = UART_StopBits_1;
    //No even check bit.
    UART_InitStructure.Parity = UART_Parity_No;
    //No hardware data flow control.
    UART_InitStructure.HWFlowControl = UART_HWFlowControl_None;
    UART_InitStructure.Mode = UART_Mode_Rx | UART_Mode_Tx;

    UART_Init(UART1, &UART_InitStructure);
    UART_Cmd(UART1, ENABLE);

    //UART1_TX   GPIOA.9  Reuse push-pull output
    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_9;
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP;
    GPIO_Init(GPIOA, &GPIO_InitStructure);

    //UART1_RX	  GPIOA.10 Floated input
    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_10;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_FLOATING;
    GPIO_Init(GPIOA, &GPIO_InitStructure);

}
////////////////////////////////////////////////////////////////////////////////
/// @brief    Set the device address
/// @note     None.
/// @param  : I2Cx(where x can be 1 or 2 to select the I2C peripheral)
/// @param  : deviceaddr(device address).
/// @retval : None.
////////////////////////////////////////////////////////////////////////////////
void I2C_SetDeviceAddr(I2C_TypeDef *I2Cx, u8 deviceaddr)
{
    I2C1BusFreeGPIOMode();

    //Disable I2C
    I2C_Cmd(I2Cx, DISABLE);
    //Set the device address
    I2C_Send7bitAddress(I2Cx, deviceaddr, I2C_Direction_Transmitter);
    //Enable I2C
    I2C_Cmd(I2Cx, ENABLE);

    I2C1ConfigGPIOMode();
}

////////////////////////////////////////////////////////////////////////////////
/// @brief    Write and read data from EEPROM.
/// @note     None.
/// @param  : None.
/// @retval : None.
////////////////////////////////////////////////////////////////////////////////
void I2C1MasterDMATest(void)
{
    unsigned int i;
    I2C_DeInit(I2C1);
    UartSendGroup((u8*)printBuf, sprintf(printBuf, "i2c1 dma test start\r\n"));
    I2CInitMasterMode();
    I2C_SetDeviceAddr(I2C1, EEPROM_ADDR);
    DMA_I2C1MasterWrite(FLASH_DEVICE_ADDR, 16 * 0, 16, tx_buffer0 );
    //delay
    i = 1000000; while(i--);
    for(i = 0; i < 16 ; i ++)
    {
        UartSendGroup((u8*)printBuf, sprintf(printBuf, "TX data is: %x \r\n", tx_buffer0[i]));
    }
    DMA_I2C1MasterRead(FLASH_DEVICE_ADDR, 16 * 0, 16, rx_buffer0 );

    for(i = 0; i < 16; i++)
    {
        UartSendGroup((u8*)printBuf, sprintf(printBuf, "RX data%d is  : %x \r\n", i, rx_buffer0[i]));
    }
    UartSendGroup((u8*)printBuf, sprintf(printBuf, "i2c1 dma test over\r\n"));
}

////////////////////////////////////////////////////////////////////////////////
/// @brief    Initializes the I2Cx master mode
/// @note     None.
/// @param  : None.
/// @retval : None.
////////////////////////////////////////////////////////////////////////////////
void I2CInitMasterMode(void)
{
    I2C_InitTypeDef I2C_InitStructure;

    RCC_AHBPeriphClockCmd(RCC_AHBPeriph_GPIOB, ENABLE);
    RCC_APB1PeriphClockCmd(RCC_APB1Periph_I2C1, ENABLE);

    I2C1BusFreeGPIOMode();

    I2C_InitStructure.Mode = I2C_CR_MASTER;
    I2C_InitStructure.OwnAddress = FLASH_DEVICE_ADDR;
    I2C_InitStructure.Speed = I2C_CR_STD;
    I2C_InitStructure.ClockSpeed = 100000;
    I2C_Init(I2C1, &I2C_InitStructure);
    I2C_Cmd(I2C1, ENABLE);

    I2C1ConfigGPIOMode();

}

////////////////////////////////////////////////////////////////////////////////
/// @brief    Send data
/// @note     None.
/// @param  : device_id( Slave address )
/// @param  : mem_byte_addr(Write data)
/// @param  : tx_count(Number of data)
/// @param  : tx_data(data)
/// @retval : None.
////////////////////////////////////////////////////////////////////////////////
void DMA_I2C1MasterWrite(unsigned char device_id, unsigned short mem_byte_addr, unsigned short tx_count, unsigned char *tx_data )
{

    I2C1_DMA_TX((u8*)&mem_byte_addr, 1);
    I2C1_DMA_TX(tx_data, tx_count);
    //  while(!I2C_GetFlagStatus(I2C1,I2C_STATUS_FLAG_TFE));
    while(!(I2C1->SR & 0x4));
    I2C_GenerateSTOP( I2C1, ENABLE );
}

////////////////////////////////////////////////////////////////////////////////
/// @brief    Write command is sent when TX FIFO is empty
/// @note     None.
/// @param  : I2Cx (where x can be 1 or 2 to select the I2C peripheral)
/// @retval : None.
////////////////////////////////////////////////////////////////////////////////
void I2CTXEmptyCheck(I2C_TypeDef *I2Cx)
{
    while(1)
    {
        if(I2C_GetFlagStatus(I2Cx, I2C_FLAG_TX_EMPTY))
        {
            break;
        }
    }
}

////////////////////////////////////////////////////////////////////////////////
/// @brief    Write command is sent when RX FIFO is not full
/// @note     None.
/// @param  : I2Cx (where x can be 1 or 2 to select the I2C peripheral)
/// @retval : None.
////////////////////////////////////////////////////////////////////////////////
void I2CRXFullCheck(I2C_TypeDef *I2Cx)
{

    while(1)
    {
        if(I2C_GetFlagStatus(I2Cx, I2C_FLAG_RX_FULL))
        {
            break;
        }
    }
}

////////////////////////////////////////////////////////////////////////////////
/// @brief    Send a byte of data
/// @note     None.
/// @param  : I2Cx (where x can be 1 or 2 to select the I2C peripheral)
/// @param  : temp (Byte to be transmitted.)
/// @retval : None.
////////////////////////////////////////////////////////////////////////////////
void I2CTXByte(I2C_TypeDef *I2Cx, unsigned short cmd, unsigned char temp)
{
    I2C_SendData(I2Cx, temp);
    I2CTXEmptyCheck(I2Cx);

}

////////////////////////////////////////////////////////////////////////////////
/// @brief    Receive a byte of data
/// @note     None.
/// @param  : I2Cx (where x can be 1 or 2 to select the I2C peripheral)
/// @retval : temp (The value of the received data).
////////////////////////////////////////////////////////////////////////////////
unsigned char I2CRXByte(I2C_TypeDef *I2Cx)
{
    unsigned short temp;

    I2CRXFullCheck(I2Cx);

    temp = I2C_ReceiveData(I2Cx);
    return (unsigned char)temp;
}

////////////////////////////////////////////////////////////////////////////////
/// @brief    use DMA Send data
/// @note     None.
/// @param  : size(Number of data)
/// @param  : tx_buf(data)
/// @retval : None.
////////////////////////////////////////////////////////////////////////////////
void I2C1_DMA_TX(unsigned char *tx_buf, unsigned short size)
{
    DMA_InitTypeDef DMA_InitStruct;
    RCC_AHBPeriphClockCmd(RCC_AHBPeriph_DMA1, ENABLE);
    DMA_DeInit(DMA1_Channel2);

    // Initialize the DMA_PeripheralBaseAddr member
    DMA_InitStruct.PeripheralBaseAddr = I2C1_BASE + 0x10;
    // Initialize the DMA_MemoryBaseAddr member
    DMA_InitStruct.MemoryBaseAddr = (unsigned int)tx_buf;
    // Initialize the DMA_DIR member
    DMA_InitStruct.DIR = DMA_DIR_PeripheralDST;
    // Initialize the DMA_BufferSize member
    DMA_InitStruct.BufferSize = size;
    // Initialize the DMA_PeripheralInc member
    DMA_InitStruct.PeripheralInc = DMA_PeripheralInc_Disable;
    // Initialize the DMA_MemoryInc member
    DMA_InitStruct.MemoryInc = DMA_MemoryInc_Enable ;
    // Initialize the DMA_PeripheralDataSize member
    DMA_InitStruct.PeripheralDataSize = DMA_PeripheralDataSize_Word;
    // Initialize the DMA_MemoryDataSize member
    DMA_InitStruct.MemoryDataSize = DMA_MemoryDataSize_Byte;
    // Initialize the DMA_Mode member
    DMA_InitStruct.Mode = DMA_Mode_Normal;
    // Initialize the DMA_Priority member
    DMA_InitStruct.Priority = DMA_Priority_Low;
    // Initialize the DMA_M2M member
    DMA_InitStruct.M2M = DMA_M2M_Disable;
    DMA_Init(DMA1_Channel2, &DMA_InitStruct);
    DMA_Cmd(DMA1_Channel2, ENABLE);
    // Enable DMA transmission
    I2C1->DMA |= TDMAE_SET;
    //Waiting for the completion of DMA transmission
    while(!DMA_GetFlagStatus(DMA1_FLAG_TC2));
    DMA_Cmd(DMA1_Channel2, DISABLE);
    // Disable DMA transmission
    I2C1->DMA &= ~TDMAE_SET;
}

////////////////////////////////////////////////////////////////////////////////
/// @brief    Use DMA receive data
/// @note     None.
/// @param  : size(Number of data)
/// @param  : rx_buf(receive data buff)
/// @retval : None.
////////////////////////////////////////////////////////////////////////////////
void I2C1_DMA_RX(unsigned char *rx_buf, unsigned short size)
{
    unsigned int ui_Tdata = 0x100;
    DMA_InitTypeDef DMA_InitStruct;
    RCC_AHBPeriphClockCmd(RCC_AHBPeriph_DMA1, ENABLE);
    //Disable DMA transmission
    I2C1->DMA |= RDMAE_SET | TDMAE_SET;

    DMA_DeInit(DMA1_Channel3);

    // Initialize the DMA_PeripheralBaseAddr member
    DMA_InitStruct.PeripheralBaseAddr = I2C1_BASE + 0x10;
    // Initialize the DMA_MemoryBaseAddr member
    DMA_InitStruct.MemoryBaseAddr = (unsigned int)rx_buf;
    // Initialize the DMA_DIR member
    DMA_InitStruct.DIR = DMA_DIR_PeripheralSRC;
    // Initialize the DMA_BufferSize member
    DMA_InitStruct.BufferSize = size;
    // Initialize the DMA_PeripheralInc member
    DMA_InitStruct.PeripheralInc = DMA_PeripheralInc_Disable;
    // Initialize the DMA_MemoryInc member
    DMA_InitStruct.MemoryInc = DMA_MemoryInc_Enable ;
    // Initialize the DMA_PeripheralDataSize member
    DMA_InitStruct.PeripheralDataSize = DMA_PeripheralDataSize_Byte;
    // Initialize the DMA_MemoryDataSize member
    DMA_InitStruct.MemoryDataSize = DMA_MemoryDataSize_Byte;
    // Initialize the DMA_Mode member
    DMA_InitStruct.Mode = DMA_Mode_Normal;
    // Initialize the DMA_Priority member
    DMA_InitStruct.Priority = DMA_Priority_Low;
    // Initialize the DMA_M2M member
    DMA_InitStruct.M2M = DMA_M2M_Disable;
    DMA_Init(DMA1_Channel3, &DMA_InitStruct);
    DMA_Cmd(DMA1_Channel3, ENABLE);

    DMA_DeInit(DMA1_Channel2);

    // Initialize the DMA_PeripheralBaseAddr member
    DMA_InitStruct.PeripheralBaseAddr = I2C1_BASE + 0x10;
    // Initialize the DMA_MemoryBaseAddr member
    DMA_InitStruct.MemoryBaseAddr = (unsigned int)&ui_Tdata;
    // Initialize the DMA_DIR member
    DMA_InitStruct.DIR = DMA_DIR_PeripheralDST;
    // Initialize the DMA_BufferSize member
    DMA_InitStruct.BufferSize = size;
    // Initialize the DMA_PeripheralInc member
    DMA_InitStruct.PeripheralInc = DMA_PeripheralInc_Disable;
    // Initialize the DMA_MemoryInc member
    DMA_InitStruct.MemoryInc = DMA_MemoryInc_Disable  ;
    // Initialize the DMA_PeripheralDataSize member
    DMA_InitStruct.PeripheralDataSize = DMA_PeripheralDataSize_Word;
    // Initialize the DMA_MemoryDataSize member
    DMA_InitStruct.MemoryDataSize = DMA_MemoryDataSize_Word;
    // Initialize the DMA_Mode member
    DMA_InitStruct.Mode = DMA_Mode_Normal;
    // Initialize the DMA_Priority member
    DMA_InitStruct.Priority = DMA_Priority_Low;
    // Initialize the DMA_M2M member
    DMA_InitStruct.M2M = DMA_M2M_Disable;
    DMA_Init(DMA1_Channel2, &DMA_InitStruct);
    DMA_Cmd(DMA1_Channel2, ENABLE);

    // Wait for DMA transfer to complete
    while(!DMA_GetFlagStatus(DMA1_FLAG_TC3))
    {
        //I2C1->IC_DATA_CMD = 0x100;
    }
    DMA_Cmd(DMA1_Channel3, DISABLE);
    DMA_Cmd(DMA1_Channel2, DISABLE);
    I2C1->DMA &= ~(RDMAE_SET | TDMAE_SET);
}

////////////////////////////////////////////////////////////////////////////////
/// @brief  Receive data
/// @note   None.
/// @param  : device_id( Slave address )
/// @param  : mem_byte_addr(Write data)
/// @param  : rx_count(Number of data)
/// @param  : rx_data(data)
/// @retval : None.
////////////////////////////////////////////////////////////////////////////////
void DMA_I2C1MasterRead(unsigned char device_id, unsigned short mem_byte_addr, unsigned short rx_count, unsigned char *rx_data )
{

    I2C1_DMA_TX((u8*)&mem_byte_addr, 1);
    I2C1_DMA_RX(rx_data, rx_count);
    while(!(I2C1->SR & 0x4));
    I2C_GenerateSTOP( I2C1, ENABLE );
}

////////////////////////////////////////////////////////////////////////////////
/// @brief  UART send byte.
/// @note   None.
/// @param  dat(A byte data).
/// @retval None.
////////////////////////////////////////////////////////////////////////////////
void UartSendByte(u8 dat)
{
    UART_SendData(UART1, dat);
    while(!UART_GetFlagStatus(UART1, UART_FLAG_TXEPT));
}

////////////////////////////////////////////////////////////////////////////////
/// @brief  UART send byte.
/// @note   None.
/// @param  buf:buffer address.
/// @param  len:data length.
/// @retval None.
////////////////////////////////////////////////////////////////////////////////
void UartSendGroup(u8* buf, u16 len)
{
    while(len--)
        UartSendByte(*buf++);
}

/// @}


/// @}

/// @}




