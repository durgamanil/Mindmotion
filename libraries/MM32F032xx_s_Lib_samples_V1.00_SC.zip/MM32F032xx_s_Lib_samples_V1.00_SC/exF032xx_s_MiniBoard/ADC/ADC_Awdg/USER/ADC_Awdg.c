////////////////////////////////////////////////////////////////////////////////
/// @file    ADC_Awdg.c
/// @author  AE TEAM
/// @version v1.0.0
/// @date    2019-09-20
/// @brief    In window comparator mode,The transformation results are detected
///           Set the threshold value from 0 to 3V, and connect PB6 and PA0 with
///           jumper cap to see the effect.
////////////////////////////////////////////////////////////////////////////////
/// @attention
///
/// THE EXISTING FIRMWARE IS ONLY FOR REFERENCE, WHICH IS DESIGNED TO PROVIDE
/// CUSTOMERS WITH CODING INFORMATION ABOUT THEIR PRODUCTS SO THEY CAN SAVE
/// TIME. THEREFORE, MINDMOTION SHALL NOT BE LIABLE FOR ANY DIRECT, INDIRECT OR
/// CONSEQUENTIAL DAMAGES ABOUT ANY CLAIMS ARISING OUT OF THE CONTENT OF SUCH
/// HARDWARE AND/OR THE USE OF THE CODING INFORMATION CONTAINED HEREIN IN
/// CONNECTION WITH PRODUCTS MADE BY CUSTOMERS.
///
/// <H2><CENTER>&COPY; COPYRIGHT 2018-2019 MINDMOTION </CENTER></H2>
////////////////////////////////////////////////////////////////////////////////
// Define to prevent recursive inclusion  --------------------------------------
#define _ADC_AWDG_C_

// Files includes  -------------------------------------------------------------
#include "ADC_Awdg.h"



////////////////////////////////////////////////////////////////////////////////
/// @brief  This function is main entrance.
/// @param  None.
/// @retval None.
////////////////////////////////////////////////////////////////////////////////
int main(void)
{

    GPIO_InitTypeDef  GPIO_InitStructure;
    RCC_AHBPeriphClockCmd(RCC_AHBPeriph_GPIOB, ENABLE);
    GPIO_InitStructure.GPIO_Pin  = GPIO_Pin_6;
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_2MHz;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
    GPIO_Init(GPIOB, &GPIO_InitStructure);
    GPIO_SetBits(GPIOB, GPIO_Pin_6);
    ADCConfig(ADC_Channel_0);
    while(1)
    {
        ADCVAL = ADC1_SingleChannel_Get();
        if(ADC_flag == 1)
        {
            fValue = ((float)ADCVAL / 4095) * 3.3;
            ADC_flag = 0;

        }
    }

}

////////////////////////////////////////////////////////////////////////////////
/// @brief  Configure the ADC1 single conversion mode to correspond to the PIN
/// @note    It must be careful of the Chip Version.
/// @param  GPIOx: The sampling port corresponds to the port
/// @param  GPIO_Pin_n: The sampling port corresponds to the pin.
/// @retval None.
////////////////////////////////////////////////////////////////////////////////
void GPIO_Config_AIN(GPIO_TypeDef* GPIOx, u16 GPIO_Pin_n)
{
    GPIO_InitTypeDef GPIO_InitStructure;
    if(GPIOx == GPIOA)
    {
        RCC_AHBPeriphClockCmd(RCC_AHBPeriph_GPIOA, ENABLE);
    }
    if(GPIOx == GPIOB)
    {
        RCC_AHBPeriphClockCmd(RCC_AHBPeriph_GPIOB, ENABLE);
    }
    if(GPIOx == GPIOC)
    {
        RCC_AHBPeriphClockCmd(RCC_AHBPeriph_GPIOC, ENABLE);
    }
    if(GPIOx == GPIOD)
    {
        //GPIO clock starts
        RCC_AHBPeriphClockCmd(RCC_AHBPeriph_GPIOD, ENABLE);
    }
    GPIO_InitStructure.GPIO_Pin  =  GPIO_Pin_n;
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AIN;
    GPIO_Init(GPIOx, &GPIO_InitStructure);
}

////////////////////////////////////////////////////////////////////////////////
/// @brief  initialize LED GPIO pin
/// @note   if use jtag/swd interface GPIO PIN as LED, need to be careful,
///         can not debug or program.
/// @param  None.
/// @retval None.
////////////////////////////////////////////////////////////////////////////////
void LED_Init(void)
{

    GPIO_InitTypeDef  GPIO_InitStructure;

    GPIO_Clock_Set(GPIOA, ENABLE);
    GPIO_Clock_Set(GPIOB, ENABLE);
    GPIO_InitStructure.GPIO_Pin  =  GPIO_Pin_15;
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
    GPIO_Init(GPIOA, &GPIO_InitStructure);

    GPIO_InitStructure.GPIO_Pin  = GPIO_Pin_3 | GPIO_Pin_4 | GPIO_Pin_5;
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
    GPIO_Init(GPIOB, &GPIO_InitStructure);

    LED1_ON();
    LED2_ON();
    LED3_ON();
    LED4_ON();
}

////////////////////////////////////////////////////////////////////////////////
/// @brief  RCC clock set.Enable to use the IO port clock
/// @note   It must be careful of the Chip Version.
/// @param  None.
/// @retval None.
////////////////////////////////////////////////////////////////////////////////
void GPIO_Clock_Set(GPIO_TypeDef* GPIOx, FunctionalState NewState)
{

    if(GPIOx == GPIOA)
    {
        RCC_AHBPeriphClockCmd(RCC_AHBPeriph_GPIOA, NewState);
    }
    if(GPIOx == GPIOB)
    {
        RCC_AHBPeriphClockCmd(RCC_AHBPeriph_GPIOB, NewState);
    }
    if(GPIOx == GPIOC)
    {
        RCC_AHBPeriphClockCmd(RCC_AHBPeriph_GPIOC, NewState);
    }
    if(GPIOx == GPIOD)
    {
        RCC_AHBPeriphClockCmd(RCC_AHBPeriph_GPIOD, NewState);
    }
}

////////////////////////////////////////////////////////////////////////////////
/// @brief  Configure ADC1 single conversion mode��external interrupt source
///         interrupt priority
/// @note   Configure parameters according to requirements.
/// @param  ADC_Channel_x: The sampling channel
/// @retval None.
////////////////////////////////////////////////////////////////////////////////
void ADCSingleChannelInit(ADCCHANNEL_TypeDef ADC_Channel_x)
{
    ADC_InitTypeDef  ADC_InitStructure;
    NVIC_InitTypeDef NVIC_InitStructure;
    ADC_StructInit(&ADC_InitStructure);

    //Enable ADC clock
    RCC_APB2PeriphClockCmd(RCC_APB2Periph_ADC1, ENABLE);
    ADC_InitStructure.ADC_Resolution = ADC_Resolution_12b;
    //ADC prescale factor
    ADC_InitStructure.ADC_PRESCARE = ADC_PCLK2_PRESCARE_16;
    //Set ADC mode to continuous conversion mode
    ADC_InitStructure.ADC_Mode = ADC_Mode_Continue;
    //AD data right-justified
    ADC_InitStructure.ADC_DataAlign = ADC_DataAlign_Right;
    ADC_InitStructure.ADC_ExternalTrigConv = ADC_ExternalTrigConv_T1_CC1;
    ADC_Init(ADC1, &ADC_InitStructure);
    //Enable the channel
    ADC_RegularChannelConfig(ADC1, ADC_Channel_x, 0, ADC_Samctl_239_5);

    ADC_AnalogWatchdogCmd(ADC1, ENABLE);
    ADC_AnalogWatchdogThresholdsConfig(ADC1, 3722, 0);
    ADC_AnalogWatchdogSingleChannelConfig(ADC1, ADC_Channel_x);


    //Enable an external interrupt source
    ADC_ITConfig(ADC1, ADC_IT_AWD, ENABLE);
    ADC_Cmd(ADC1, ENABLE);

    // Configure interrupt priority
    NVIC_InitStructure.NVIC_IRQChannel = ADC_COMP_IRQn;
    NVIC_InitStructure.NVIC_IRQChannelPriority = 0x02;
    NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
    NVIC_Init(&NVIC_InitStructure);
}

////////////////////////////////////////////////////////////////////////////////
/// @brief  Configure sampling GPIO with single conversion mode for ADC1
/// @note    Note the corresponding channel selection.
/// @param  ADC_Channel_x: The sampling channel
/// @retval None.
////////////////////////////////////////////////////////////////////////////////
void ADCConfig(ADCCHANNEL_TypeDef ADC_Channel)
{
    if( ADC_Channel_0 == ADC_Channel )
    {
        GPIO_Config_AIN(GPIOA, GPIO_Pin_0);
    }
    else if( ADC_Channel_1 == ADC_Channel )
    {
        GPIO_Config_AIN(GPIOA, GPIO_Pin_1);
    }
    else if( ADC_Channel_2 == ADC_Channel )
    {
        GPIO_Config_AIN(GPIOA, GPIO_Pin_2);
    }
    else if( ADC_Channel_3 == ADC_Channel )
    {
        GPIO_Config_AIN(GPIOA, GPIO_Pin_3);
    }
    else if( ADC_Channel_4 == ADC_Channel )
    {
        GPIO_Config_AIN(GPIOA, GPIO_Pin_4);
    }
    else if( ADC_Channel_5 == ADC_Channel )
    {
        GPIO_Config_AIN(GPIOA, GPIO_Pin_5);
    }
    else if( ADC_Channel_6 == ADC_Channel )
    {
        GPIO_Config_AIN(GPIOA, GPIO_Pin_6);
    }
    else if( ADC_Channel_7 == ADC_Channel )
    {
        GPIO_Config_AIN(GPIOA, GPIO_Pin_7);
    }
    else if( ADC_Channel_8 == ADC_Channel )
    {
        GPIO_Config_AIN(GPIOB, GPIO_Pin_0);
    }
    else if( ADC_Channel_9 == ADC_Channel )
    {
        GPIO_Config_AIN(GPIOB, GPIO_Pin_1);
    }
    else
    {
    }
    ADCSingleChannelInit(ADC_Channel);
}

////////////////////////////////////////////////////////////////////////////////
/// @brief  Gets the ADC1 transform data
/// @note   Note the register configuration if there is no return value.
/// @param  None.
/// @retval puiADData:Conversion results.
////////////////////////////////////////////////////////////////////////////////
u16 ADC1_SingleChannel_Get(void)
{
    u16 puiADData;
    //Register ADST bit enable, software start conversion
    ADC_SoftwareStartConvCmd(ADC1, ENABLE);
    //ADC_IT_EOC
    while(ADC_GetFlagStatus(ADC1, ADC_IT_AWD) == 0);
    ADC_ClearFlag(ADC1, ADC_IT_AWD);
    puiADData = ADC_GetConversionValue(ADC1);
    return puiADData;
}

////////////////////////////////////////////////////////////////////////////////
/// @brief  Gets the ADC1 transform data
/// @note   None.
/// @param  times:Sampling frequency
/// @retval temp_val / times:Obtain the average value of several ADC1 samples.
////////////////////////////////////////////////////////////////////////////////
u16 Get_Adc_Average(uint8_t times)
{
    u32 temp_val = 0;
    u8 t;
    u8 delay;
    for(t = 0; t < times; t++)
    {
        temp_val += ADC1_SingleChannel_Get();
        for(delay = 0; delay < 100; delay++);
    }
    return temp_val / times;
}


////////////////////////////////////////////////////////////////////////////////
/// @brief  Interrupt service function
/// @note   If error occurs,Simulation to see if you can enter the interrupt
///         function.
/// @param  None.
/// @retval None.
////////////////////////////////////////////////////////////////////////////////
void ADC_COMP_IRQHandler(void)
{

    if(ADC_GetFlagStatus(ADC1, ADC_IT_AWD) != RESET)
    {
        ADC_flag = 1;
    }

    ADC_ClearFlag(ADC1, ADC_IT_AWD);
}


////////////////////////////////////////////////////////////////////////////////
/// @brief  This function is called back by SysTick Handler
///         call series function to run systick cycle running
///         for example , delay, led blink, key in scan , etc.
/// @note   This function always run after power on.
/// @param  None.
/// @retval None.
////////////////////////////////////////////////////////////////////////////////
void SysTick_Handler_CALL(void)
{
    TimingDelay_Decrement();
}
////////////////////////////////////////////////////////////////////////////////
/// @brief  This function make delay count decrement as one systick
///         for example , delay (1ms)
/// @note   when decrement to zero?? it always 0.
/// @param  None.
/// @retval None.
////////////////////////////////////////////////////////////////////////////////
void TimingDelay_Decrement(void)
{
    if (TimingDelay != 0x00)
    {
        TimingDelay--;
    }
}
////////////////////////////////////////////////////////////////////////////////
/// @brief  delay nTime ms
/// @note   get x times.
/// @param  nTime  nTime ms.
/// @retval None.
////////////////////////////////////////////////////////////////////////////////
void delay_ms(__IO uint32_t nTime)
{
    TimingDelay = nTime;
    for(;;)
    {
        if(TimingDelay == 0)
            break;
    }
}



/// @}

/// @}

/// @}
