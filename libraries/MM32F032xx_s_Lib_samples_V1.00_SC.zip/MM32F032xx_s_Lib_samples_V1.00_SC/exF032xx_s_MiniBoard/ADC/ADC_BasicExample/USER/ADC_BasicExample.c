////////////////////////////////////////////////////////////////////////////////
/// @file    ADC_BasicExample.c
/// @author  AE TEAM
/// @version v1.0.0
/// @date    2019-09-20
/// @brief   THIS FILE PROVIDES ALL THE SYSTEM FUNCTIONS.
////////////////////////////////////////////////////////////////////////////////
/// @attention
///
/// THE EXISTING FIRMWARE IS ONLY FOR REFERENCE, WHICH IS DESIGNED TO PROVIDE
/// CUSTOMERS WITH CODING INFORMATION ABOUT THEIR PRODUCTS SO THEY CAN SAVE
/// TIME. THEREFORE, MINDMOTION SHALL NOT BE LIABLE FOR ANY DIRECT, INDIRECT OR
/// CONSEQUENTIAL DAMAGES ABOUT ANY CLAIMS ARISING OUT OF THE CONTENT OF SUCH
/// HARDWARE AND/OR THE USE OF THE CODING INFORMATION CONTAINED HEREIN IN
/// CONNECTION WITH PRODUCTS MADE BY CUSTOMERS.
///
/// <H2><CENTER>&COPY; COPYRIGHT 2019 MINDMOTION </CENTER></H2>
////////////////////////////////////////////////////////////////////////////////

/// Define to prevent recursive inclusion  -------------------------------------
#define _ADC_BasicExample_C_

/// File includes --------------------------------------------------------------

#include "ADC_BasicExample.h"


////////////////////////////////////////////////////////////////////////////////
/// @addtogroup MM32_Example_Layer
/// @{

////////////////////////////////////////////////////////////////////////////////
/// @addtogroup MM32_RESOURCE
/// @{

////////////////////////////////////////////////////////////////////////////////
/// @addtogroup MM32_Exported_Constants
/// @{

/// @}

////////////////////////////////////////////////////////////////////////////////
/// @brief  This function is main entrance.
/// @param  None.
/// @retval  0.
////////////////////////////////////////////////////////////////////////////////
int main(void)
{
    SetSystemClock(emSYSTICK_On, NULL);
    uart_initwBaudRate(115200);
    ADCConfig(ADCch0); //use PA0
    while(1)
    {
        ADCVAL = Get_Adc_Average(5);
        fValue = ((float)ADCVAL / 4095) * 3.3; //use 3.3V as VDD
        //fValue = (((float)ADCVAL)/4095)*5; //use 5V as VDD
        //printf("ADC1_CH_1=%fV\r\n",fValue);
        delay_ms(200);
    }
}
////////////////////////////////////////////////////////////////////////////////
/// @brief  GPIO_Clock_Set and RCC_Clock_Set.
/// @note   This function always used when using clock.
/// @param  GPIOx state,where x can be A-D to select the GPIO .
/// @retval None.
////////////////////////////////////////////////////////////////////////////////
void GPIO_Clock_Set(GPIO_TypeDef* GPIOx, FunctionalState NewState)
{
    if(GPIOx == GPIOA)
    {
        RCC_AHBPeriphClockCmd(RCC_AHBPeriph_GPIOA, NewState);//GPIO clock starts
    }
    if(GPIOx == GPIOB)
    {
        RCC_AHBPeriphClockCmd(RCC_AHBPeriph_GPIOB, NewState);//GPIO clock starts
    }
    if(GPIOx == GPIOC)
    {
        RCC_AHBPeriphClockCmd(RCC_AHBPeriph_GPIOC, NewState);//GPIO clock starts
    }
    if(GPIOx == GPIOD)
    {
        RCC_AHBPeriphClockCmd(RCC_AHBPeriph_GPIOD, NewState);//GPIO clock starts
    }
}
////////////////////////////////////////////////////////////////////////////////
/// @brief  This function is  to achieve serial port initialization.
/// @note   When you use serial ports you need to match the baud rate.
/// @param  bound,where you can chose 9600,115200 ect.
/// @retval None.
////////////////////////////////////////////////////////////////////////////////
void uart_initwBaudRate(u32 bound)
{

    GPIO_InitTypeDef GPIO_InitStructure;
    UART_InitTypeDef UART_InitStructure;

    RCC_APB2PeriphClockCmd(RCC_APB2Periph_UART1, ENABLE);//Enable the UART1 and GPIOA
    //RCC_AHBPeriphClockCmd(RCC_AHBPeriph_GPIOA, ENABLE);//Open the GPIOA and GPIOB clock
    GPIO_Clock_Set(GPIOA, ENABLE);//Open the GPIOA and GPIOB clock
    GPIO_PinAFConfig(GPIOA, GPIO_PinSource9, GPIO_AF_1);
    GPIO_PinAFConfig(GPIOA, GPIO_PinSource10, GPIO_AF_1);

    UART_InitStructure.BaudRate = bound;  //Baud rate setting
    UART_InitStructure.WordLength = UART_WordLength_8b; //The word length is in 8-bit data format
    UART_InitStructure.StopBits = UART_StopBits_1;//One stop bit
    UART_InitStructure.Parity = UART_Parity_No;//No even check bit
    UART_InitStructure.HWFlowControl = UART_HWFlowControl_None;//No hardware data flow control
    UART_InitStructure.Mode = UART_Mode_Rx | UART_Mode_Tx;//Sending and receiving mode

    UART_Init(UART1, &UART_InitStructure); //Initialize serial port 1
    UART_Cmd(UART1, ENABLE);//Enable serial port 1

    //UART1_TX   GPIOA.9
    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_9; //PA.9
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP;//Reuse push-pull output
    GPIO_Init(GPIOA, &GPIO_InitStructure);//Initialize GPIOA. 9

    //UART1_RX	  GPIOA.10 initialize
    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_10;//PA10
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_FLOATING;//Floated input
    GPIO_Init(GPIOA, &GPIO_InitStructure);//Initialize GPIOA.10
}

////////////////////////////////////////////////////////////////////////////////
/// @brief  This function is chosen the channel of adc by yourself.
/// @note   This function always run after using ADC.
/// @param  ADC_Channel.
/// @retval None.
////////////////////////////////////////////////////////////////////////////////
void ADCConfig(ADCch ADC_Channel)
{
    GPIO_InitTypeDef GPIO_InitStructure;
    GPIO_Clock_Set(GPIOA, ENABLE);
    if( ADCch0 == ADC_Channel )
    {
        GPIO_InitStructure.GPIO_Pin  =  GPIO_Pin_0;
    }
    else if( ADCch1 == ADC_Channel )
    {
        GPIO_InitStructure.GPIO_Pin  =  GPIO_Pin_1;
    }
    else if( ADCch1 == ADC_Channel )
    {
        GPIO_InitStructure.GPIO_Pin  =  GPIO_Pin_2;
    }
    else if( ADCch3 == ADC_Channel )
    {
        GPIO_InitStructure.GPIO_Pin  =  GPIO_Pin_3;
    }
    else if( ADCch4 == ADC_Channel )
    {
        GPIO_InitStructure.GPIO_Pin  =  GPIO_Pin_4;
    }
    else if( ADCch5 == ADC_Channel )
    {
        GPIO_InitStructure.GPIO_Pin  =  GPIO_Pin_5;
    }
    else if( ADCch6 == ADC_Channel )
    {
        GPIO_InitStructure.GPIO_Pin  =  GPIO_Pin_6;
    }
    else if( ADCch7 == ADC_Channel )
    {
        GPIO_InitStructure.GPIO_Pin  =  GPIO_Pin_7;
    }
    else if( ADCch8 == ADC_Channel )
    {
        GPIO_InitStructure.GPIO_Pin  =  GPIO_Pin_8;
    }
    else if( ADCch9 == ADC_Channel )
    {
        GPIO_InitStructure.GPIO_Pin  =  GPIO_Pin_9;
    }
    else
    {}
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;                           //Output speed
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AIN;                               //GPIO mode
    GPIO_Init(GPIOA, &GPIO_InitStructure);
    ADCSingleChannelInit(ADC_Channel);
}
////////////////////////////////////////////////////////////////////////////////
/// @brief  This function is initial adcchannel.
/// @note   Use this function when initializing an ADC channel.
/// @param  ADC_Channel_x.
/// @retval None.
////////////////////////////////////////////////////////////////////////////////
void ADCSingleChannelInit(ADCch ADC_Channel_x)
{
    ADC_InitTypeDef  ADC_InitStructure;
    ADC_StructInit(&ADC_InitStructure);
    //Initialize PA1 to analog input mode
    RCC_APB2PeriphClockCmd(RCC_APB2Periph_ADC1, ENABLE);                        //Enable ADC clock

    ADC_InitStructure.ADC_Resolution = ADC_Resolution_12b;
    ADC_InitStructure.ADC_PRESCARE = ADC_PCLK2_PRESCARE_16;                     //ADC prescale factor
    ADC_InitStructure.ADC_Mode = ADC_Mode_Continue;                             //Set ADC mode to continuous conversion mode
    ADC_InitStructure.ADC_DataAlign = ADC_DataAlign_Right;                      //AD data right-justified
    ADC_InitStructure.ADC_ExternalTrigConv = ADC_ExternalTrigConv_T1_CC1;
    ADC_Init(ADC1, &ADC_InitStructure);

    //ADC_RegularChannelConfig(ADC, ADC_Channel_All_Disable, 0, ADC_SampleTime_13_5Cycles);//Block all channels
    ADC_RegularChannelConfig(ADC1, ADC_Channel_x, 0, ADC_Samctl_239_5);        //Enable the channel


    if((ADC_Channel_x == (ADCch)ADC_Channel_TempSensor) || (ADC_Channel_x == (ADCch)ADC_Channel_VoltReference))
    {
        ADC_TempSensorVrefintCmd(ENABLE);                                      //Enable internal temperature sensor
    }
    ADC_Cmd(ADC1, ENABLE);                                                     //Enable AD conversion
}

////////////////////////////////////////////////////////////////////////////////
/// @brief  This function is getting the convert data
/// @note   Software enables more than one channel, the channel with the smallest
///         sequence number is converted, and other channels are ignored.
/// @param  None.
/// @retval puiADData.
////////////////////////////////////////////////////////////////////////////////
u16 ADC1_SingleChannel_Get(void)
{
    u16 puiADData;
    ADC_SoftwareStartConvCmd(ADC1, ENABLE);                                     //Software start conversion
    while(ADC_GetFlagStatus(ADC1, ADC_IT_EOC) == 0);
    ADC_ClearFlag(ADC1, ADC_IT_EOC);
    puiADData = ADC_GetConversionValue(ADC1);
    return puiADData;
}
////////////////////////////////////////////////////////////////////////////////
/// @brief  This function is getting the average of ADC
/// @note   None.
/// @param  times.
/// @retval average.
////////////////////////////////////////////////////////////////////////////////
u16 Get_Adc_Average(uint8_t times)
{
    u32 temp_val = 0;
    u8 t;
    u8 delay;
    for(t = 0; t < times; t++)
    {
        temp_val += ADC1_SingleChannel_Get();
        for(delay = 0; delay < 100; delay++);
    }
    return temp_val / times;
}
////////////////////////////////////////////////////////////////////////////////
/// @brief  This function is called back by SysTick Handler
///         call series function to run systick cycle running
///         for example , delay, led blink, key in scan , etc.
/// @note   This function always run after power on.
/// @param  GPIOx GPIO_Pin_n.
/// @retval None.
////////////////////////////////////////////////////////////////////////////////
void SysTick_Handler_CALL(void)
{
    TimingDelay_Decrement();
}
////////////////////////////////////////////////////////////////////////////////
/// @brief  This function make delay count decrement as one systick
///         for example , delay (1ms)
/// @note   when decrement to zero�� it always 0.
/// @param  None.
/// @retval None.
////////////////////////////////////////////////////////////////////////////////
void TimingDelay_Decrement(void)
{
    if (TimingDelay != 0x00)
    {
        TimingDelay--;
    }
}
////////////////////////////////////////////////////////////////////////////////
/// @brief  delay nTime ms
/// @note   get x times.
/// @param  nTime  nTime ms.
/// @retval None.
////////////////////////////////////////////////////////////////////////////////
void delay_ms(__IO uint32_t nTime)
{
    TimingDelay = nTime;

    while(TimingDelay > 0)
    {
        __NOP();
    }
}
/// @}


/// @}

/// @}

