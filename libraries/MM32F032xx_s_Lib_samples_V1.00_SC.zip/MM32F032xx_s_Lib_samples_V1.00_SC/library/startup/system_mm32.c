////////////////////////////////////////////////////////////////////////////////
/// @file    SYSTEM_MM32.C
/// @author  AE TEAM
/// @version 2.0.0
/// @date    2019-09-20
/// @brief   THIS FILE PROVIDES ALL THE SYSTEM FUNCTIONS.
////////////////////////////////////////////////////////////////////////////////
/// @attention
///
/// THE EXISTING FIRMWARE IS ONLY FOR REFERENCE, WHICH IS DESIGNED TO PROVIDE
/// CUSTOMERS WITH CODING INFORMATION ABOUT THEIR PRODUCTS SO THEY CAN SAVE
/// TIME. THEREFORE, MINDMOTION SHALL NOT BE LIABLE FOR ANY DIRECT, INDIRECT OR
/// CONSEQUENTIAL DAMAGES ABOUT ANY CLAIMS ARISING OUT OF THE CONTENT OF SUCH
/// HARDWARE AND/OR THE USE OF THE CODING INFORMATION CONTAINED HEREIN IN
/// CONNECTION WITH PRODUCTS MADE BY CUSTOMERS.
///
/// <H2><CENTER>&COPY; COPYRIGHT 2019 MINDMOTION </CENTER></H2>
////////////////////////////////////////////////////////////////////////////////

// Define to prevent recursive inclusion  --------------------------------------
#define _SYSTEM_MM32_C_

// Files includes  -------------------------------------------------------------
#include <string.h>
#include "types.h"
#include "mm32.h"


#include "system_mm32.h"

#include "hal_rcc.h"


////////////////////////////////////////////////////////////////////////////////
/// @addtogroup MM32_Example_Layer
/// @{

////////////////////////////////////////////////////////////////////////////////
/// @addtogroup MM32_RESOURCE
/// @{

////////////////////////////////////////////////////////////////////////////////
/// @addtogroup MM32_Exported_Constants
/// @{

/// @}

////////////////////////////////////////////////////////////////////////////////
/// @addtogroup MM32_Exported_Functions
/// @{

////////////////////////////////////////////////////////////////////////////////
/// @brief  This function handles SysTick Handler.
/// @param  None.
/// @retval None.
////////////////////////////////////////////////////////////////////////////////
void SysTick_Handler(void)
{
    SysTick_Handler_CALL();
    nTimeOutCnt++;
    sysTickFlag1mS = true;

    if (sysTickCnt++ >= 20)
    {
        sysTickCnt  = 0;
        sysTickFlag = true;
    }

}


////////////////////////////////////////////////////////////////////////////////
/// @brief  Setup the microcontroller system
///         Initialize the Embedded Flash Interface, the PLL and update the
///         SystemCoreClock variable.
/// @note   This function should be used only after reset.
/// @param  ClockSoucre : Select system clock source.
/// @param  tickEn : Enable or disable the systick.
/// @param  pCallback : The pointer point to the systick callback function.
/// @retval MCU ID.
////////////////////////////////////////////////////////////////////////////////
ErrorStatus  exSystemInit(EM_SystemClock ClockSoucre, EM_SYSTICK tickEn, u32* pCallback)
{
    // Configure the System clock frequency, HCLK, PCLK2 and PCLK1 prescalers
    // Configure the Flash Latency cycles and enable prefetch buffer

    RCCInitStruct_TypeDef  RCC_InitStructure;
    //  SYSCLK_HSE_12x;     // HSE_96MHz@8MHz
    RCC_InitStructure.RCC_SystemClock  = ClockSoucre;           //  SYSCLK_HSE_9x;      // HSE_72MHz@8MHz

    RCC_InitStructure.RCC_PrescaleAHB  = 1;                     // Range: 0-7:8-15; div1-div512
    RCC_InitStructure.RCC_PrescaleAPB1 = 1;                     // Range: 0:15; div1:div16
    RCC_InitStructure.RCC_PrescaleAPB2 = 1;                     // Range: 0:15; div1:div16
    RCC_InitStructure.RCC_PrescaleUSB  = 1;                     // Range: 0:1;  div1:div2
    RCC_InitStructure.SysTickEN = tickEn;
    RCC_InitStructure.SysTickPeriod = 1000;

    if (exRCC_Init(&RCC_InitStructure) == ERROR)
    {
        while(1)
        {
            // error
        }
    }



    return SUCCESS;
}


////////////////////////////////////////////////////////////////////////////////
///  @brief  System clock configuration
///  @param  enable: Enable or disable the systick.
///  @param  callbackPtr: The pointer point to the systick callback function.
///  @retval None.
////////////////////////////////////////////////////////////////////////////////
ErrorStatus  SetSystemClock(EM_SYSTICK enable, u32* callbackPtr)
{
#if defined(__EX_AES)
    return exSystemInit(SYSCLK_HSI_72MHz, enable, callbackPtr);
#else
//      return exSystemInit(SYSCLK_HSI_96MHz, enable, callbackPtr);
    return exSystemInit(SYSCLK_HSI_72MHz, enable, callbackPtr);


#endif
}

/// @}


/// @}

/// @}


