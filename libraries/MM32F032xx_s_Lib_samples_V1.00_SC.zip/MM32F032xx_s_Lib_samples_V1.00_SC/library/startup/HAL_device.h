////////////////////////////////////////////////////////////////////////////////
/// @file     HAL_device.h
/// @author   AE team
/// @version  v2.0.0
/// @date     2019-09-20
/// @brief    CMSIS Cortex-M Peripheral Access Layer for MindMotion
///           microcontroller devices
////////////////////////////////////////////////////////////////////////////////
/// @attention
///
/// THE EXISTING FIRMWARE IS ONLY FOR REFERENCE, WHICH IS DESIGNED TO PROVIDE
/// CUSTOMERS WITH CODING INFORMATION ABOUT THEIR PRODUCTS SO THEY CAN SAVE
/// TIME. THEREFORE, MINDMOTION SHALL NOT BE LIABLE FOR ANY DIRECT, INDIRECT OR
/// CONSEQUENTIAL DAMAGES ABOUT ANY CLAIMS ARISING OUT OF THE CONTENT OF SUCH
/// HARDWARE AND/OR THE USE OF THE CODING INFORMATION CONTAINED HEREIN IN
/// CONNECTION WITH PRODUCTS MADE BY CUSTOMERS.
///
/// <H2><CENTER>&COPY; COPYRIGHT 2019 MINDMOTION </CENTER></H2>
////////////////////////////////////////////////////////////////////////////////


// Define to prevent recursive inclusion  --------------------------------------
#ifndef __HAL_device_H
#define __HAL_device_H

//#undef
#undef __ENABLE_ADC
#undef __ENABLE_AES
#undef __ENABLE_BKP
#undef __ENABLE_CAN
#undef __ENABLE_CHIP_EEPROM
#undef __ENABLE_COMP
#undef __ENABLE_CRC
#undef __ENABLE_CRS
#undef __ENABLE_DAC
#undef __ENABLE_DIV
#undef __ENABLE_ETHERNET
#undef __ENABLE_FSMC
#undef __ENABLE_OPAMP
#undef __ENABLE_QSPI
#undef __ENABLE_RTC
#undef __ENABLE_SDIO
#undef __ENABLE_SQRT
#undef __ENABLE_TRNG
#undef __ENABLE_USB_DEVICE
#undef __ENABLE_USBOTG_DEVICE
#undef __ENABLE_USBOTG_HOST




//	|| \
//	defined() 	|| defined()
//	|| defined()
#if defined(___MM32F103x8) || defined(___MM32F103xB) || \
	defined(___MM32L073x)  || defined(___MM32L373x)  || \
	defined(___MM32W073x)  || defined(___MM32W373x)	 || \
	defined(___MM32SPIN06x)|| defined(___MM32SPIN46x)|| \
	defined(___MM32SPIN47x)|| defined(___MM32SPIN48x)
#define __ENABLE_CAN
#endif

#if defined(___MM32L373x)  || \
	defined(___MM32SPIN46x)|| defined(___MM32SPIN47x)
#define __ENABLE_DAC
#endif


#if defined(___MM32F032x6) || defined(___MM32F032x8) || \
	defined(___MM32F103x8) || defined(___MM32F103xB) || \
	defined(___MM32L362x)  || defined(___MM32L373x)  || \
	defined(___MM32L384x)  || defined(___MM32L395x)  || \
	defined(___MM32W362x)  || defined(___MM32W373x)
#define __ENABLE_RTC
#endif

#if defined(___MM32F103x8) || defined(___MM32F103xB) || \
	defined(___MM32L052x)  || defined(___MM32L062x)  || \
    defined(___MM32L072x)  || defined(___MM32L073x)  || \
	defined(___MM32L362x)  || defined(___MM32L373x)  || \
	defined(___MM32W062x)  || defined(___MM32W073x)  || \
	defined(___MM32W362x)  || defined(___MM32W373x)
#define __ENABLE_USB_DEVICE
#define __ENABLE_CRS
#endif

#if defined(___MM32L384x)  || defined(___MM32L395x)  || \
	defined(___MM32W384x)  || defined(___MM32W395x)
#define __ENABLE_USBOTG_DEVICE
#define __ENABLE_CHIP_EEPROM
#define __ENABLE_TRNG
#define __ENABLE_SDIO
#endif




//#define __MM0S1

#include "vcdefine_v1.h"
#include "mm32.h"
#endif /* __HAL_device_H */

/// @}


/// @}

/// @}



