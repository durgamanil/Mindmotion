#ifndef _MG_APP_H_
#define _MG_APP_H_

#include "HAL_conf.h"
//#define u8 unsigned char
//#define u16 unsigned short
#endif




