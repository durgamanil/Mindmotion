#ifndef __RF_IRQ_H__
#define __RF_IRQ_H__
#include "sys.h"
void Key_Shutter_Init(void);

#endif
