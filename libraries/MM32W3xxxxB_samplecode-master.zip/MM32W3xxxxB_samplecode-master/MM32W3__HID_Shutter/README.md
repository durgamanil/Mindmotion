# MM32W3xxxxB_n_samplecode

The procedure works for MM32W373PSB/MM32W073PFB

2020.4.3

1.Upload program to git

2.use updated lib v5.3.0, update i2c demo reference code.

2020.5.25

1.Modify the IRQ pin.  PC12-->PC9

2.Update software version information. SV5.3.0-->SV5.3.1

3.Add sch_mb021.pdf

2020.6.02

1.add HID_Shutter demo 
