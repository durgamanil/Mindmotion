/**
******************************************************************************
* @file     Timer.h
* @author   FAE Team
* @version  V1.0.0
* @date     2020/01/20
* @brief
*******************************************************************************
*/

#ifndef __TIMER_H
#define __TIMER_H

/* Includes ------------------------------------------------------------------*/
#include	"HAL_device.h"
#include	"HAL_conf.h"

/** @defgr Timer_Print_Private_Defines
* @{
*/

#define IR_FUNCTION_EN
//#define REMOTE_1
//#define REMOTE_2
#define REMOTE_3

#define VSP_OFF         0
#define VSP_ON          580
#define VSP_SPEED1      990     //
#define VSP_SPEED2      1480    //
#define VSP_SPEED3      1970    //
#define VSP_SPEED4      2470    //
#define VSP_SPEED5      2960    //
#define VSP_SPEED6      3450    //
    
extern unsigned int RFRXD_Value;
extern unsigned char ReverseFlag;

/**
* @}
*/



/** @defgroup Timer_Print_Private_FunctionPrototypes
* @{
*/

void TIM2_init(unsigned short prescaler, unsigned short period);
int TIM2_CapGetStatus(void);
void LED_Init(void);

/**
* @}
*/

#endif /* __TIMER_H */

