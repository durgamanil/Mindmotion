#ifndef __MOTOR_SPEED_SLOP_CONTROL_H
#define __MOTOR_SPEED_SLOP_CONTROL_H			   

#include "Whole_motor_structure.h"
#include "Whole_Motor_Parameters.h"

void Generate_Now_Speed_Command(Whole_Motor_Struct* Motor);
void Generate_Now_Power_Command(void);//20191108
#endif





























