extern void delay_10us(unsigned int n); //delay n*10us
extern void delay_100us(unsigned int n); //delay n*100us
extern void delay_ms(unsigned int n); //delay n*1ms

extern void delay_1us(void);
extern void delay_2us(void);
extern void delay_5us(void);
