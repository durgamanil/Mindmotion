/**
******************************************************************************
* @file     Timer.c
* @author   
* @version  V1.0.0
* @date     2020/01/20
* @brief
*******************************************************************************
*/

/* Includes ------------------------------------------------------------------*/
#include    "Timer.h"
#include "Whole_Motor_Parameters.h"
#include "Motor_function_initial.h"

/** @defgroup Timer_Private_Defines
* @{
*/

//#define LED4_ON()            GPIO_ResetBits(GPIOA,GPIO_Pin_15)                  // PA15
//#define LED4_OFF()           GPIO_SetBits(GPIOA,GPIO_Pin_15)                    // PA15
//#define LED4_TOGGLE()       (GPIO_ReadOutputDataBit(GPIOA,GPIO_Pin_15))? \
//                            (GPIO_ResetBits(GPIOA,GPIO_Pin_15)):         \
//                            (GPIO_SetBits(GPIOA,GPIO_Pin_15))                   // PA15

//#define LED3_ON()            GPIO_ResetBits(GPIOB,GPIO_Pin_3)                   // PB3
//#define LED3_OFF()           GPIO_SetBits(GPIOB,GPIO_Pin_3)                     // PB3
//#define LED3_TOGGLE()       (GPIO_ReadOutputDataBit(GPIOB,GPIO_Pin_3))?  \
//                            (GPIO_ResetBits(GPIOB,GPIO_Pin_3)):          \
//                            (GPIO_SetBits(GPIOB,GPIO_Pin_3))                    // PB3

//#define LED2_ON()            GPIO_ResetBits(GPIOB,GPIO_Pin_4)                   // PB4
//#define LED2_OFF()           GPIO_SetBits(GPIOB,GPIO_Pin_4)                     // PB4
//#define LED2_TOGGLE()       (GPIO_ReadOutputDataBit(GPIOB,GPIO_Pin_4))?  \
//                            (GPIO_ResetBits(GPIOB,GPIO_Pin_4)):          \
//                            (GPIO_SetBits(GPIOB,GPIO_Pin_4))                    // PB4

//#define LED1_ON()            GPIO_ResetBits(GPIOB,GPIO_Pin_5)                   // PB5
//#define LED1_OFF()           GPIO_SetBits(GPIOB,GPIO_Pin_5)                     // PB5
//#define LED1_TOGGLE()       (GPIO_ReadOutputDataBit(GPIOB,GPIO_Pin_5))?  \
//                            (GPIO_ResetBits(GPIOB,GPIO_Pin_5)):          \
//                            (GPIO_SetBits(GPIOB,GPIO_Pin_5))                    // PB5

/**
* @}
*/


/** @defgroup Timer_Private_Variables
* @{
*/

unsigned char IRData[4], IRDindex, IRCaptureOnOff, IRFlag, ReverseFlag;

unsigned char RunStatus, LED1Status;

unsigned short CapturePeriod, CaptureDuty;
unsigned short IRCMD;

unsigned int IRXData, RFRXD_Value, IRXDataArray;

/**
* @}
*/


/** @defgroup Timer_Private_Functions
* @{
*/

/*******************************************************************************
* @name   : void TIM2_IRQHandler(void)
* @brief  : 
* @param  : None
* @retval : None
********************************************************************************/
void TIM2_IRQHandler(void)
{
    if (TIM_GetITStatus(TIM2, TIM_IT_CC1) != RESET) {
        TIM_ClearITPendingBit(TIM2, TIM_IT_CC1);
        
        if (IRFlag == 1)
            return;
                
        if (TIM2->CCR1 > 12500 && TIM2->CCR1 < 14000) { //if (CapturePeriod > 5000 && CapturePeriod < 5800) {
            IRCaptureOnOff = 1;
        }
        
        if (IRCaptureOnOff == 1) {
            IRXDataArray = IRXDataArray << 1;
            if(TIM2->CCR1 > 1100 && TIM2->CCR1 < 1300) {
                __nop();
            } else if (TIM2->CCR1 > 2200 && TIM2->CCR1 < 2500) {
                IRXDataArray |= 1;
            }
            IRDindex++;
            
            if (IRDindex > 32) {
                IRDindex = 0;
                IRCaptureOnOff = 0;
				IRXData = IRXDataArray;
				IRXDataArray = 0;
    //            IRXData = IRXData >> 1;
                
    //            IRData[0] = (unsigned char)(IRXData >> 24);
    //            IRData[1] = (unsigned char)(IRXData >> 16);
    //            IRData[2] = (unsigned char)(IRXData >> 8);
    //            IRData[3] = (unsigned char)IRXData;
    //            IRCMD = (unsigned short)IRData[2] << 8;
    //            IRCMD |= IRData[3];
                IRFlag = 1;
                
                //TIM2->CR1 &= (uint16_t)(~0x0001);										//TIM2 disable
            }
        }
    }
}

/*******************************************************************************
* @name   : int TIM2_CapGetStatus(void)
* @brief  : 
* @param  : None
* @retval : None
*
*   For remote 1:
*
*   POWER ON/OFF -> 0x1B7E10EF
*            LED -> 0x1B7EE01F
*            FAN -> 0x1B7E609F
*              1 -> 0x1B7E807F
*              2 -> 0x1B7E40BF
*              3 -> 0x1B7EC03F
*              4 -> 0x1B7E20DF
*              5 -> 0x1B7EA05F
*              6 -> 0x1B7EA857
*             2H -> 0x1B7E906F
*             4H -> 0x1B7E08F7
*             8H -> 0x1B7E48B7
*        Reverse -> 0x1B7EC837
*          Smart -> 0x1B7E28D7
*
*
*	For remote 2:
*
*	OFF 			-> 0x01FEB847
*	ON  			-> 0x01FE38C7
*	15				-> 0x01FE48B7
*	30				-> 0x01FE7887
*	60				-> 0x01FEA05F
*	120				-> 0x01FE58A7
*	Middle button	-> 0x01FE30CF
*	50%				-> 0x01FE807F
*	100%			-> 0x01FE609F
*	LED				-> 0x01FE50AF
*	-				-> 0x01FEC03F
*	+				-> 0x01FE40BF

For remote 3(new 2):
*
*	OFF 			-> 0x807F_1DE2
*	ON  			-> 0x807F_1CE3
*	15				-> 0x807F_12ED
*	30				-> 0x807F_1EE1
*	60				-> 0x807F_05FA
*	120				-> 0x807F_1AE5
*	Middle button	-> 0x807F_0CF3
*	50%				-> 0x807F_01FE
*	100%			-> 0x807F_06F9
*	LED				-> 0x807F_0AF5
*	-				-> 0x807F_03FC
*	+				-> 0x807F_02FD
********************************************************************************/
#ifdef REMOTE_1 // Use remote 1 to control
int TIM2_CapGetStatus(void)
{
    unsigned char capsta;
    if (IRFlag == 1) 
	{
        IRFlag = 0;
        if ((IRXData & 0xFFFF0000) == 0x1B7E0000) 
		{

            if ((IRXData & 0xFFFF) == 0x10EF) // Power bottom  //20200221 Andy
			{     
                if(RunStatus==1) // motor is in run mode and user want to stop motor
				{
					RunStatus=0;
					RFRXD_Value = VSP_OFF;
					capsta = 5;
					return capsta;            
				}
				else // motor is in stop mode and user want to start motor
				{
					RunStatus=1;
					RFRXD_Value = VSP_ON;					
					return capsta;      
				}				
            }
			
            if ((IRXData & 0xFFFF) == 0x807F) // speed 1
			{     
                RFRXD_Value = VSP_ON;
                capsta = 6;
                return capsta;
            }
            
            if ((IRXData & 0xFFFF) == 0x40BF) // speed 2
			{     
                RFRXD_Value = VSP_SPEED1;
                capsta = 2;
                return capsta;
            }
            
            if ((IRXData & 0xFFFF) == 0xC03F) // speed 3
			{     
                RFRXD_Value = VSP_SPEED2;
                capsta = 3;
                return capsta;
            }
            
            if ((IRXData & 0xFFFF) == 0x20DF)  // speed 4
				{    
                RFRXD_Value = VSP_SPEED3;
                capsta = 4;
                return capsta;
            }
			
			if ((IRXData & 0xFFFF) == 0xA05F) // speed 5
			{    
                RFRXD_Value = VSP_SPEED4;
                capsta = 5;
                return capsta;
            }
			
			if ((IRXData & 0xFFFF) == 0xA857) // speed 6
			{     
                RFRXD_Value = VSP_SPEED5;
                capsta = 6;
                return capsta;
            }
			
			if ((IRXData & 0xFFFF) == 0x609F) // speed 7
			{     
                RFRXD_Value = VSP_SPEED6;
                capsta = 7;
                return capsta;
            }
			
			if ((IRXData & 0xFFFF) == 0xC837) // reverse 
			{                 
				 ReverseFlag = 1;
				 capsta ^= 1;
				 return capsta;
            }
			 
            if ((IRXData & 0xFFFF) == 0xE01F) // LED
			{     
					if(Motor1.info.u8ErrorCode ==0) //When the error isn't happened, user can control the LED do on/off switch //20200221 Andy
					{					
						LED1_TOGGLE();
						return capsta;
					}
				}
        
		}
    }
    return FALSE;
}
#endif // Use remote 2 to control

#ifdef REMOTE_2
int TIM2_CapGetStatus(void)
{
    unsigned char capsta;
    if (IRFlag == 1) 
	{
        IRFlag = 0;
        if ((IRXData & 0xFFFF0000) == 0x01FE0000) 
		{
			  if ((IRXData & 0xFFFF) == 0xB847) // user want to stop motor //OFF
			{     
                RFRXD_Value = VSP_OFF;
                capsta = 6;
                return capsta;
            }
			 if ((IRXData & 0xFFFF) == 0x38C7) // user want to start motor // ON
			{     
                RFRXD_Value = VSP_ON;
                capsta = 6;
                return capsta;
            }
			 if ((IRXData & 0xFFFF) == 0x48B7) // speed 1 //15
			{     
                RFRXD_Value = VSP_ON;
                capsta = 6;
                return capsta;
            }
            
            if ((IRXData & 0xFFFF) == 0x7887) // speed 2 //30
			{     
                RFRXD_Value = VSP_SPEED1;
                capsta = 2;
                return capsta;
            }
            
            if ((IRXData & 0xFFFF) == 0xA05F) // speed 3 //60
			{     
                RFRXD_Value = VSP_SPEED2;
                capsta = 3;
                return capsta;
            }
            
            if ((IRXData & 0xFFFF) == 0x58A7)  // speed 4 //120
				{    
                RFRXD_Value = VSP_SPEED3;
                capsta = 4;
                return capsta;
            }
			
			if ((IRXData & 0xFFFF) == 0x30CF) // speed 5 //Middle button
			{    
                RFRXD_Value = VSP_SPEED4;
                capsta = 5;
                return capsta;
            }
			
			if ((IRXData & 0xFFFF) == 0x807F) // speed 6 //50%
			{     
                RFRXD_Value = VSP_SPEED5;
                capsta = 6;
                return capsta;
            }
			
			if ((IRXData & 0xFFFF) == 0x609F) // speed 7 //100%
			{     
                RFRXD_Value = VSP_SPEED6;
                capsta = 7;
                return capsta;
            }
			if ((IRXData & 0xFFFF) == 0xC03F) // reverse //-
			{                 
				 ReverseFlag = 1;
				 capsta ^= 1;
				 return capsta;
            }
			 
            if ((IRXData & 0xFFFF) == 0x50AF) // LED //LED
			{     
					if(Motor1.info.u8ErrorCode ==0) //When the error isn't happened, user can control the LED do on/off switch //20200221 Andy
					{					
						LED1_TOGGLE();
						return capsta;
					}
				}
		}
    }
    return FALSE;
}
#endif

#ifdef REMOTE_3
int TIM2_CapGetStatus(void)
{
    unsigned char capsta;
    if (IRFlag == 1) 
	{
        IRFlag = 0;
        if ((IRXData & 0xFFFF0000) == 0x807F0000) 
		{
			  if ((IRXData & 0xFFFF) == 0x1DE2) // user want to stop motor //OFF
			{     
                RFRXD_Value = VSP_OFF;
                capsta = 6;
                return capsta;
            }
			 if ((IRXData & 0xFFFF) == 0x1CE3) // user want to start motor // ON
			{     
                RFRXD_Value = VSP_ON;
                capsta = 6;
                return capsta;
            }
			 if ((IRXData & 0xFFFF) == 0x12ED) // speed 1 //15
			{     
                RFRXD_Value = VSP_ON;
                capsta = 6;
                return capsta;
            }
            
            if ((IRXData & 0xFFFF) == 0x1EE1) // speed 2 //30
			{     
                RFRXD_Value = VSP_SPEED1;
                capsta = 2;
                return capsta;
            }
            
            if ((IRXData & 0xFFFF) == 0x05FA) // speed 3 //60
			{     
                RFRXD_Value = VSP_SPEED2;
                capsta = 3;
                return capsta;
            }
            
            if ((IRXData & 0xFFFF) == 0x1AE5)  // speed 4 //120
				{    
                RFRXD_Value = VSP_SPEED3;
                capsta = 4;
                return capsta;
            }
			
			if ((IRXData & 0xFFFF) == 0x0CF3) // speed 5 //Middle button
			{    
                RFRXD_Value = VSP_SPEED4;
                capsta = 5;
                return capsta;
            }
			
			if ((IRXData & 0xFFFF) == 0x01FE) // speed 6 //50%
			{     
                RFRXD_Value = VSP_SPEED5;
                capsta = 6;
                return capsta;
            }
			
			if ((IRXData & 0xFFFF) == 0x06F9) // speed 7 //100%
			{     
                RFRXD_Value = VSP_SPEED6;
                capsta = 7;
                return capsta;
            }
			if ((IRXData & 0xFFFF) == 0x03FC) // reverse //-
			{                 
				 ReverseFlag = 1;
				 capsta ^= 1;
				 return capsta;
            }
			 
            if ((IRXData & 0xFFFF) == 0x0AF5) // LED //LED
			{     
					if(Motor1.info.u8ErrorCode ==0) //When the error isn't happened, user can control the LED do on/off switch //20200221 Andy
					{					
						LED1_TOGGLE();
						return capsta;
					}
				}
		}
    }
    return FALSE;
}
#endif
/*******************************************************************************
* @name   : void TIM2_init(unsigned short prescaler, unsigned short period)
* @brief  : 
* @param  : None
* @retval : None
********************************************************************************/
void TIM2_init(unsigned short prescaler, unsigned short period)
{
    GPIO_InitTypeDef GPIO_InitStructure;
    TIM_TimeBaseInitTypeDef TIM_TimeBaseStructure;
    TIM_ICInitTypeDef TIMx_ICInitStructure;
    NVIC_InitTypeDef NVIC_InitStructure;

    RCC_AHBPeriphClockCmd(RCC_AHBPeriph_GPIOA, ENABLE);
    RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM2, ENABLE);
    RCC_APB2PeriphClockCmd(RCC_APB2Periph_SYSCFG, ENABLE);
    
    GPIO_PinAFConfig(GPIOA, GPIO_PinSource2, GPIO_AF_2);

    /* GPIOx */
    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_2;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IN_FLOATING;
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_Init(GPIOA, &GPIO_InitStructure);
    
    /* NVIC */
    NVIC_InitStructure.NVIC_IRQChannel = TIM2_IRQn;                     
    NVIC_InitStructure.NVIC_IRQChannelPriority = 4;
    NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
    NVIC_Init(&NVIC_InitStructure);
    
    /* TIMx */
    TIM_TimeBaseStructure.TIM_Prescaler = prescaler;
    TIM_TimeBaseStructure.TIM_Period = period;
    TIM_TimeBaseStructure.TIM_ClockDivision = 0;
    TIM_TimeBaseStructure.TIM_CounterMode = TIM_CounterMode_Up;
    //TIM_TimeBaseStructure.TIM_CounterMode = TIM_CounterMode_Down;
    TIM_TimeBaseInit(TIM2, &TIM_TimeBaseStructure);
    
    TIMx_ICInitStructure.TIM_Channel = TIM_Channel_1;                   
//    TIMx_ICInitStructure.TIM_ICPolarity = TIM_ICPolarity_Rising;       
    TIMx_ICInitStructure.TIM_ICPolarity = TIM_ICPolarity_Falling;
    TIMx_ICInitStructure.TIM_ICSelection = TIM_ICSelection_DirectTI;   
    TIMx_ICInitStructure.TIM_ICPrescaler = TIM_ICPSC_DIV1; 
    TIMx_ICInitStructure.TIM_ICFilter = 0x0; 
    TIM_PWMIConfig(TIM2, &TIMx_ICInitStructure);
    
    TIM_SelectInputTrigger(TIM2, TIM_TS_TI1FP1);     
    TIM_SelectSlaveMode(TIM2, TIM_SlaveMode_Reset);
    TIM_SelectHallSensor(TIM2, ENABLE);
    
    TIM_ITConfig(TIM2, TIM_IT_CC1, ENABLE);
    TIM_ClearITPendingBit(TIM2, TIM_IT_CC1);
    TIM_Cmd(TIM2, ENABLE);
    
}

/*******************************************************************************
* @name   : void LED_Init(void)
* @brief  : 
* @param  : None
* @retval : None
********************************************************************************/
//void LED_Init(void)
//{
//    GPIO_InitTypeDef  GPIO_InitStructure;

//    RCC_AHBPeriphClockCmd(RCC_AHBPeriph_GPIOA, ENABLE);
//    RCC_AHBPeriphClockCmd(RCC_AHBPeriph_GPIOB, ENABLE);
//    GPIO_InitStructure.GPIO_Pin  =  GPIO_Pin_15;
//    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
//    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
//    GPIO_Init(GPIOA, &GPIO_InitStructure);

//    GPIO_InitStructure.GPIO_Pin  = GPIO_Pin_3 | GPIO_Pin_4 | GPIO_Pin_5;
//    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
//    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
//    GPIO_Init(GPIOB, &GPIO_InitStructure);

//}

/**
* @}
*/

