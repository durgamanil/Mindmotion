#ifndef __MOTOR_FUNCTION_INITIAL_H
#define __MOTOR_FUNCTION_INITIAL_H 			   

#include "Whole_motor_structure.h"
#include "Whole_Motor_Parameters.h"

void init_motor_parameters(Whole_Motor_Struct* Motor);

#endif





























