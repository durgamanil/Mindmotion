#ifndef __LED_H
#define __LED_H	 
#include "HAL_conf.h"

//////////////////////////////////////////////////////////////////////////////////	 
//������
//LED��������	   
////////////////////////////////////////////////////////////////////////////////// 
#define PB12_ON()  GPIO_ResetBits(GPIOB,GPIO_Pin_12)	// PC12
#define PB12_OFF()  GPIO_SetBits(GPIOB,GPIO_Pin_12)	// PC12

void LED_Init(void);//��ʼ��

		 				    
#endif
