#ifndef __COMPARATOR_H
#define __COMPARATOR_H	 

void Init_Comparator(void);
		 				    
#endif
