#include "comparator.h"
#include "Whole_Motor_Parameters.h"

#ifdef ENABLE_OVER_CURRENT_COMP1_PROTECTION
	
/*

+------------------------------------------+     
|                 |                | COMP1 |  
|-----------------|----------------|-------|
|                 | CMP1_INM0	00 |  PA5  | 
|  CSR(bit5:4)    | CMP1_INM1	01 |  PA6  |
|                 | CMP1_INM2	10 |  PA7  | 
| Inverting Input | CMP1_INM3	11 |  CRV  |  
|-----------------|----------------|-------|
|  Non Inverting  | CMP1_INP_SEL 00|  PA1  | 
|    Input        | CMP1_INP_SEL 01|  PA2  | 
|  CSR(bit8:7)    | CMP1_INP_SEL 10|  PA3  |
|    		          | CMP1_INP_SEL 11|  PA4  |
+------------------------------------------+

*/
	#ifdef MM32SPIN05
	void Init_Comparator(void)
	{
		GPIO_InitTypeDef GPIO_InitStructure;                                           //GPIO Structure
		COMP_InitTypeDef COMP_InitStructure;                                           //COMP Structure
		
		RCC_AHBPeriphClockCmd(RCC_AHBPeriph_GPIOA, ENABLE);                            //GPIOA Clock
		GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AIN;                                  //GPIO Anolog Input
		GPIO_InitStructure.GPIO_Pin = GPIO_Pin_4;// | GPIO_Pin_1;                      //PA4
		GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;                              //GPIO Speed 50Mhz
		GPIO_Init(GPIOA, &GPIO_InitStructure);                                         //GPIOA Init

		RCC_APB2PeriphClockCmd(RCC_APB2Periph_COMP, ENABLE);                           //COMP Clock	
	//	COMP_InitStructure.COMP_InvertingInput = COMP_InvertingInput_IO2;				     //COMP Inverting Input PA6
	//	COMP_InitStructure.COMP_NonInvertingInput = COMP_NonInvertingInput_IO1;		   //COMP Noninverting Input PA0
	//	COMP_InitStructure.COMP_InvertingInput    = COMP_InvertingInput_DAC1;		     //COMP Inverting Input PA4
	//  COMP_InitStructure.COMP_NonInvertingInput = COMP_NonInvertingInput_IO4;	     //COMP Noninverting Input PA3
		#ifdef MM32SPIN06s //20200326
			COMP_InitStructure.Invert    = emCOMP_InvertingInput_IO2;           //COMP Inverting Input internal CRV reference voltage
			COMP_InitStructure.NonInvert = emCOMP_InvertingInput_VREFINT;	       //COMP Noninverting Input PA3
		  COMP_InitStructure.Output = emCOMP_Output_TIM1BKIN;                         //Trigger Timer1 Break 
		  COMP_InitStructure.OutputPol = emCOMP_NonInverted;                //Output Polarity
			COMP_InitStructure.Hysteresis = emCOMP_Hysteresis_Medium;                   //Hysteresis Voltage Level
			COMP_InitStructure.Mode = emCOMP_Mode_MediumSpeed;                          //Speed and Power Consumption Level
			COMP_InitStructure.COMP_Filter = COMP_Filter_4_Period;                         //COMP_Filter_4_Period;
			COMP_Init(COMP1, &COMP_InitStructure);                          //COMP1 Init
			
			#if 0
				ADC_VrefintCmd(ENABLE);
				SET_COMP_CRV(cHardCurrentVref, cHardCurrent);
			#else
				//SET_COMP_CRV(COMP_CRV_Sele_AVDD, INTERNAL_COMPARATOR_INM_REF_CRV_VOLTAGE);//(3_24) real is (3-2)/20 of 5V = 0.25V,(6_24) real is (6-2)/20 of 5V = 1V
			#endif
			
			COMP_Cmd(COMP1, ENABLE);                                        //COMP1 Enable
			
		#else
			COMP_InitStructure.COMP_InvertingInput    = COMP_InvertingInput_CRV;           //COMP Inverting Input internal CRV reference voltage
			COMP_InitStructure.COMP_NonInvertingInput = COMP_NonInvertingInput_IO3;	       //COMP Noninverting Input PA4
			COMP_InitStructure.COMP_Output = COMP_Output_TIM1BKIN;                         //Trigger Timer1 Break
			COMP_InitStructure.COMP_OutputPol = COMP_OutputPol_NonInverted;                //Output Polarity
			COMP_InitStructure.COMP_Hysteresis = COMP_Hysteresis_Medium;                   //Hysteresis Voltage Level
			COMP_InitStructure.COMP_Mode = COMP_Mode_MediumSpeed;                          //Speed and Power Consumption Level
			COMP_InitStructure.COMP_Filter = COMP_Filter_4_Period;                         //COMP_Filter_4_Period;
			COMP_Init(COMP_Selection_COMP1, &COMP_InitStructure);                          //COMP1 Init
			
			#if 0
				ADC_VrefintCmd(ENABLE);
				SET_COMP_CRV(cHardCurrentVref, cHardCurrent);
			#else
				SET_COMP_CRV(COMP_CRV_Sele_AVDD, INTERNAL_COMPARATOR_INM_REF_CRV_VOLTAGE);//(3_24) real is (3-2)/20 of 5V = 0.25V,(6_24) real is (6-2)/20 of 5V = 1V
			#endif
			
			COMP_Cmd(COMP_Selection_COMP1, ENABLE);                                        //COMP1 Enable
		#endif
		
		//COMP_InitStructure.COMP_BlankingSrce = COMP_BlankingSrce_None;                 		
		//ADC_TempSensorCmd(ENABLE);//for enable internal 1.2V vref 
		
		
			
			
	}
	#endif
//---------------------------------------------------------------------------------------------------------------------------	
/*

+--------------------------------------------------+     
|                 |                | COMP1 | COMP2 |  
|-----------------|----------------|---------------|
|                 | 1/4 VREFINT    |  OK   |  OK   | 
|                 | 1/2 VREFINT    |  OK   |  OK   |
|                 | 3/4 VREFINT    |  OK   |  OK   | 
| Inverting Input | VREFINT        |  OK   |  OK   | 
|                 | DAC1 OUT (PA4) |  OK   |  OK   | 
|                 | DAC2 OUT (PA5) |  OK   |  OK   |  
|                 | IO1            |  PA0  |  PA2  | 
|                 | IO2            |  PA6  |  PA6  |  
|-----------------|----------------|-------|-------|
|  Non Inverting  | IO1            |  PA0  |  PA0  | 
|    Input        | IO2            |  PA1  |  PA1  | 
|    		      | IO3            |  PA2  |  PA2  |
|    		      | IO4            |  PA3  |  PA3  |
|    		      | IO5            |  PA4  |  PA4  | 
|    		      | IO6            |  PA5  |  PA5  |
|    		      | IO7            |  PA6  |  PA6  |
|    		      | IO8            |  PA7  |  PA7  |
+--------------------------------------------------+  

*/
  #ifdef MM32L073
	void Init_Comparator(void)
	{
		
		GPIO_InitTypeDef GPIO_InitStructure;                                           //GPIO Structure
		COMP_InitTypeDef COMP_InitStructure;                                           //COMP Structure
		
		RCC_AHBPeriphClockCmd(RCC_AHBPeriph_GPIOA, ENABLE);                            //GPIOA Clock
		GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AIN;                                  //GPIO Anolog Input
		GPIO_InitStructure.GPIO_Pin = GPIO_Pin_4;// | GPIO_Pin_1;                      //PA4
		GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;                              //GPIO Speed 50Mhz
		GPIO_Init(GPIOA, &GPIO_InitStructure);                                         //GPIOA Init

		RCC_APB2PeriphClockCmd(RCC_APB2Periph_COMP, ENABLE);                           //COMP Clock	
	//	COMP_InitStructure.COMP_InvertingInput = COMP_InvertingInput_IO2;				     //COMP Inverting Input PA6
	//	COMP_InitStructure.COMP_NonInvertingInput = COMP_NonInvertingInput_IO1;		   //COMP Noninverting Input PA0
	//	COMP_InitStructure.COMP_InvertingInput    = COMP_InvertingInput_DAC1;		     //COMP Inverting Input PA4
	//  COMP_InitStructure.COMP_NonInvertingInput = COMP_NonInvertingInput_IO4;	     //COMP Noninverting Input PA3
		COMP_InitStructure.COMP_InvertingInput    = INTERNAL_COMPARATOR_INM_REF_VOLTAGE;//COMP Inverting Input internal vref 1.2V
		COMP_InitStructure.COMP_NonInvertingInput = COMP_NonInvertingInput_IO5;	       //COMP Noninverting Input PA4
		
		COMP_InitStructure.COMP_Output = COMP_Output_TIM1BKIN;                         //Trigger Timer1 Break
		COMP_InitStructure.COMP_BlankingSrce = COMP_BlankingSrce_None;                 
		COMP_InitStructure.COMP_OutputPol = COMP_OutputPol_NonInverted;                //Output Polarity
		COMP_InitStructure.COMP_Hysteresis = COMP_Hysteresis_Medium;                   //Hysteresis Voltage Level
		COMP_InitStructure.COMP_Mode = COMP_Mode_MediumSpeed;                          //Speed and Power Consumption Level
		COMP_Init(COMP_Selection_COMP1, &COMP_InitStructure);                          //COMP1 Init
		
		COMP_Cmd(COMP_Selection_COMP1, ENABLE);                                        //COMP1 Enable	
	}
	#endif
#endif

