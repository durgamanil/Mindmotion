#include "dma.h"
#include "Whole_Motor_Parameters.h"

extern   __IO uint32_t u32DMA1ShuntRADCCHAddress;
__IO int32_t  s32DMAtoADDR5[3];
__IO uint32_t u32DMAtoT3CC1[2];

#ifdef ENABLE_1_SHUNT_R_TO_MEASURE_3_PHASE_CURRENT
///////////ADC DMA/////////////////////////////////////
void DMA_ADCTrigDMA_init(void)
{
	  //NVIC_InitTypeDef NVIC_InitStructure;//for enable DMA1 INTERRUPT
    DMA_InitTypeDef DMA_InitStructure;

    DMA_DeInit(DMA1_Channel1);
    RCC_AHBPeriphClockCmd(RCC_AHBPeriph_DMA1, ENABLE);
    
	  DMA_InitStructure.DMA_PeripheralBaseAddr = u32DMA1ShuntRADCCHAddress;
    DMA_InitStructure.DMA_MemoryBaseAddr = (u32)s32DMAtoADDR5;
    DMA_InitStructure.DMA_DIR = DMA_DIR_PeripheralSRC;
    DMA_InitStructure.DMA_BufferSize = 2;
    DMA_InitStructure.DMA_PeripheralInc = DMA_PeripheralInc_Disable;
    DMA_InitStructure.DMA_MemoryInc = DMA_MemoryInc_Enable;
    DMA_InitStructure.DMA_PeripheralDataSize = DMA_PeripheralDataSize_Word; 
    DMA_InitStructure.DMA_MemoryDataSize = DMA_MemoryDataSize_Word;
    DMA_InitStructure.DMA_Mode = DMA_Mode_Normal;// DMA_Mode_Normal;
    DMA_InitStructure.DMA_Priority = DMA_Priority_High;
    DMA_InitStructure.DMA_M2M = DMA_M2M_Disable;//DMA_M2M_Enable;
	
	  #ifdef MM32SPIN06s
			DMA_InitStructure.DMA_Auto_reload = DMA_Auto_Reload_Enable;//20200403 added
	  #endif
	
    DMA_Init(DMA1_Channel1, &DMA_InitStructure);
//	DMA_Cmd(DMA1_Channel1, ENABLE);

    //for enable DMA1 INTERRUPT
//    NVIC_InitStructure.NVIC_IRQChannel = DMA1_Channel1_IRQn;
//    NVIC_InitStructure.NVIC_IRQChannelPriority = 2;
//    NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
//    NVIC_Init(&NVIC_InitStructure);
//    DMA_ITConfig(DMA1_Channel1, DMA_IT_TC, ENABLE);
	
}

///////////TIM3 DMA/////////////////////////////////////
void DMA_Timer3CC1TrigDMA_init(void)
{
    DMA_InitTypeDef DMA_InitStructure;

    DMA_DeInit(DMA1_Channel4);
    RCC_AHBPeriphClockCmd(RCC_AHBPeriph_DMA1, ENABLE);
    
    DMA_InitStructure.DMA_PeripheralBaseAddr = (uint32_t)(&(TIM3->CCR1));
    DMA_InitStructure.DMA_MemoryBaseAddr = (uint32_t)u32DMAtoT3CC1;
    DMA_InitStructure.DMA_DIR = DMA_DIR_PeripheralDST;
    DMA_InitStructure.DMA_BufferSize = 1;
    DMA_InitStructure.DMA_PeripheralInc = DMA_PeripheralInc_Disable;
    DMA_InitStructure.DMA_MemoryInc = DMA_MemoryInc_Disable;
    DMA_InitStructure.DMA_PeripheralDataSize = DMA_PeripheralDataSize_Word; 
    DMA_InitStructure.DMA_MemoryDataSize = DMA_MemoryDataSize_Word;
    DMA_InitStructure.DMA_Mode = DMA_Mode_Normal;// DMA_Mode_Normal;
    DMA_InitStructure.DMA_Priority = DMA_Priority_VeryHigh;
    DMA_InitStructure.DMA_M2M = DMA_M2M_Disable;//DMA_M2M_Enable;
    DMA_Init(DMA1_Channel4, &DMA_InitStructure);
	
		DMA_Cmd(DMA1_Channel4, ENABLE);
}
#endif

