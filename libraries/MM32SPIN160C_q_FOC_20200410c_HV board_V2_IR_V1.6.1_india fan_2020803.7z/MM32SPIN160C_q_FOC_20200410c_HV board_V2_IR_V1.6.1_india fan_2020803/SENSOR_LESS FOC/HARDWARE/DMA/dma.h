#ifndef __DMA_H
#define __DMA_H	 

void DMA_Timer3CC1TrigDMA_init(void);
void DMA_ADCTrigDMA_init(void);

#endif
