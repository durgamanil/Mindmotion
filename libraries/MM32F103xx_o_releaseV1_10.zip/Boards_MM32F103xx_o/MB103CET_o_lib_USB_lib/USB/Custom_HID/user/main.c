/******************** (C) COPYRIGHT 2018 MindMotion ********************
* File Name          : main.c
* Version            : V1.0.0
* Date               : 2018/08/21
* Description        : Custom HID demo main file
********************************************************************************
* THE PRESENT FIRMWARE WHICH IS FOR GUIDANCE ONLY AIMS AT PROVIDING CUSTOMERS
* WITH CODING INFORMATION REGARDING THEIR PRODUCTS IN ORDER FOR THEM TO SAVE TIME.
* AS A RESULT, MindMotion SHALL NOT BE HELD LIABLE FOR ANY DIRECT,
* INDIRECT OR CONSEQUENTIAL DAMAGES WITH RESPECT TO ANY CLAIMS ARISING FROM THE
* CONTENT OF SUCH FIRMWARE AND/OR THE USE MADE BY CUSTOMERS OF THE CODING
* INFORMATION CONTAINED HEREIN IN CONNECTION WITH THEIR PRODUCTS.
*******************************************************************************/

/* Includes ------------------------------------------------------------------*/
#include "HAL_device.h"
#include "usb_lib.h"
#include "hw_config.h"

#define UART_SEND_EN   1

//for sprintf start
char printBuf[100];
void Uart_ConfigInit(u32 bound);
void UartSendGroup(u8* buf,u16 len);
void UartSendAscii(char *str);
void UartSendByte(u8 data);
//end 

/* Private typedef -----------------------------------------------------------*/
/* Private define ------------------------------------------------------------*/
/* Private macro -------------------------------------------------------------*/
/* Private variables ---------------------------------------------------------*/
/* Extern variables ----------------------------------------------------------*/
/* Private function prototypes -----------------------------------------------*/
void Delay(__IO uint32_t nCount);

/* Private functions ---------------------------------------------------------*/

/*******************************************************************************
* Function Name  : main.
* Description    : main routine.
* Input          : None.
* Output         : None.
* Return         : None.
*******************************************************************************/
int main(void)
{
  Set_System();

  USB_Interrupts_Config();

  Set_USBClock();
  Uart_ConfigInit(1000000);
  USB_Init();
  
  while (1)
  {
      
  }
}

/*******************************************************************************
* Function Name  : Uart_ConfigInit.
* Input          : None.
* Output         : None.
* Return         : None.
*******************************************************************************/
void Uart_ConfigInit(u32 bound)
{
    GPIO_InitTypeDef GPIO_InitStructure;
    UART_InitTypeDef UART_InitStructure;

    RCC_APB1PeriphClockCmd(RCC_APB1Periph_UART2, ENABLE);

    UART_InitStructure.UART_BaudRate = bound;
    UART_InitStructure.UART_WordLength = UART_WordLength_8b;
    UART_InitStructure.UART_StopBits = UART_StopBits_1;
    UART_InitStructure.UART_Parity = UART_Parity_No;
    UART_InitStructure.UART_HardwareFlowControl = UART_HardwareFlowControl_None;
    UART_InitStructure.UART_Mode = UART_Mode_Rx | UART_Mode_Tx;	

    UART_Init(UART2, &UART_InitStructure); 

    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_2;       
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP;	
    GPIO_Init(GPIOA, &GPIO_InitStructure);        

    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_3;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IN_FLOATING;
    GPIO_Init(GPIOA, &GPIO_InitStructure);
    GPIO_PinAFConfig( GPIOA,GPIO_PinSource2,GPIO_AF_7);
    GPIO_PinAFConfig( GPIOA,GPIO_PinSource3,GPIO_AF_7);
    UART_Cmd(UART2, ENABLE);                  
}

/*******************************************************************************
* Function Name  : UartSendByte.
* Input          : dat.
* Output         : dat.
* Return         : None.
*******************************************************************************/
void UartSendByte(u8 dat)
{
    #if (UART_SEND_EN  == 1)
    UART_SendData( UART2, dat);
    while(!UART_GetFlagStatus(UART2,UART_FLAG_TXEPT));
    #endif
}

/*******************************************************************************
* Function Name  : UartSendGroup.
* Input          : *buf,len.
* Output         : *buf.
* Return         : None.
*******************************************************************************/
void UartSendGroup(u8* buf,u16 len)
{
    while(len--)
        UartSendByte(*buf++);
}

/*******************************************************************************
* Function Name  : UartSendAscii.
* Input          : *str.
* Output         : *str.
* Return         : None.
*******************************************************************************/
void UartSendAscii(char *str)
{
    while(*str)
        UartSendByte(*str++);
}


/*******************************************************************************
* Function Name  : Delay
* Description    : Inserts a delay time.
* Input          : nCount: specifies the delay time length.
* Output         : None
* Return         : None
*******************************************************************************/
void Delay(__IO uint32_t nCount)
{
  for(; nCount!= 0;nCount--);
}

#ifdef  USE_FULL_ASSERT
/*******************************************************************************
* Function Name  : assert_failed
* Description    : Reports the name of the source file and the source line number
*                  where the assert_param error has occurred.
* Input          : - file: pointer to the source file name
*                  - line: assert_param error line source number
* Output         : None
* Return         : None
*******************************************************************************/
void assert_failed(uint8_t* file, uint32_t line)
{ 
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */

  /* Infinite loop */
  while(1)
  {
  }
}
#endif

/******************* (C) COPYRIGHT 2018 MindMotion *****END OF FILE****/
