#ifndef __UART_H
#define __UART_H
#include "HAL_conf.h"
#include  "stdio.h"
#include "dtype.h"


void uart_initwBaudRate(void);

#endif


