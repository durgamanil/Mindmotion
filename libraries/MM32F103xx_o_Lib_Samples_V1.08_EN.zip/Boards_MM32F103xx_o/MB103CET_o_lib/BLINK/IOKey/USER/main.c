#include "HAL_conf.h"
#include "HAL_device.h"
#include "stdio.h"


static u8  fac_us = 0;

static u16 fac_ms = 0;

void delay_init(void);
void delay_ms(u16 nms);
void LED_Init(void);
void KEY_Init(void);
u8 KEY_Scan(u8 mode);

#define LED4_ON()  GPIO_ResetBits(GPIOB,GPIO_Pin_5)
#define LED4_OFF()  GPIO_SetBits(GPIOB,GPIO_Pin_5)
#define LED4_TOGGLE()  (GPIO_ReadOutputDataBit(GPIOB,GPIO_Pin_5))?(GPIO_ResetBits(GPIOB,GPIO_Pin_5)):(GPIO_SetBits(GPIOB,GPIO_Pin_5))

#define LED3_ON()  GPIO_ResetBits(GPIOB,GPIO_Pin_4)
#define LED3_OFF()  GPIO_SetBits(GPIOB,GPIO_Pin_4)
#define LED3_TOGGLE()  (GPIO_ReadOutputDataBit(GPIOB,GPIO_Pin_4))?(GPIO_ResetBits(GPIOB,GPIO_Pin_4)):(GPIO_SetBits(GPIOB,GPIO_Pin_4))

#define LED1_ON()  GPIO_ResetBits(GPIOA,GPIO_Pin_15)
#define LED1_OFF()  GPIO_SetBits(GPIOA,GPIO_Pin_15)
#define LED1_TOGGLE()  (GPIO_ReadOutputDataBit(GPIOA,GPIO_Pin_15))?(GPIO_ResetBits(GPIOA,GPIO_Pin_15)):(GPIO_SetBits(GPIOA,GPIO_Pin_15))

#define KEY1  GPIO_ReadInputDataBit(GPIOC,GPIO_Pin_13)//Read button 1
#define WK_UP  GPIO_ReadInputDataBit(GPIOA,GPIO_Pin_0)//Read button 2 
#define KEY3  GPIO_ReadInputDataBit(GPIOB,GPIO_Pin_10)//Read button 3
#define KEY4  GPIO_ReadInputDataBit(GPIOB,GPIO_Pin_11)//Read button 4

#define KEY1_PRES	1		//KEY1 
#define WKUP_PRES	2		//WK_UP  
#define KEY3_PRES	3		//KEY3 
#define KEY4_PRES	4		//KEY4 

/********************************************************************************************************
**Function information :main(void)
**Function description :
**Input parameters :none
**Output parameters :none
********************************************************************************************************/
int main(void)
{
    u8 t = 0;

    delay_init();
    /* initialization hardware interface connected with LED*/
    LED_Init();
    /* initialization hardware interface connected with keys*/
    KEY_Init();

    while(1) {

        t = KEY_Scan(0);
        switch(t) {
            /*K1 is not connected to PC13 by default, and the resetreset button is connected by default, and so pressing K1 will reset */
            case KEY1_PRES:
                LED1_TOGGLE();
                break;
            case KEY3_PRES:
                LED3_TOGGLE();
                break;
            case KEY4_PRES:
                LED4_TOGGLE();
                break;
            default:
                delay_ms(10);
        }
    }
}

/********************************************************************************************************
**Function information :LED_Init(void)
**Function description :LED initialization
**Input parameters :none
**Output parameters :none
********************************************************************************************************/
void LED_Init(void)
{
    GPIO_InitTypeDef  GPIO_InitStructure;

    RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOA | RCC_AHB1Periph_GPIOB, ENABLE);

    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_15;
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
    GPIO_Init(GPIOA, &GPIO_InitStructure);

    GPIO_InitStructure.GPIO_Pin  = GPIO_Pin_3 | GPIO_Pin_4 | GPIO_Pin_5;
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
    GPIO_Init(GPIOB, &GPIO_InitStructure);
    LED1_OFF();
    LED3_OFF();
    LED4_OFF();
}

/********************************************************************************************************
**Function information :void delay_init(void)
**Function description : initialization delay function
**Input parameters :
**Output parameters :
**Common functions :
********************************************************************************************************/
void delay_init(void)
{

    SysTick_CLKSourceConfig(SysTick_CLKSource_HCLK_Div8);

    fac_us = SystemCoreClock / 8000000;

    fac_ms = (u16)fac_us * 1000;
}

/********************************************************************************************************
**Function information :void delay_ms(u16 nms)
**Function description :delay nms
**Input parameters :nms
**Output parameters :
**    Remark :SysTick->LOAD 24 bit register,and so,maximum delay  :nms<=0xffffff*8*1000/SYSCLK,At 72 MHz,nms<=1864
********************************************************************************************************/
void delay_ms(u16 nms)
{
    u32 temp;

    SysTick->LOAD = (u32)nms * fac_ms;

    SysTick->VAL = 0x00;

    SysTick->CTRL |= SysTick_CTRL_ENABLE_Msk ;
    do {
        temp = SysTick->CTRL;
    }

    while((temp & 0x01) && !(temp & (1 << 16)));

    SysTick->CTRL &= ~SysTick_CTRL_ENABLE_Msk;

    SysTick->VAL = 0X00;
}


/********************************************************************************************************
**Function information :void KEY_Init(void)
**Function description :button  initialization function
**Input parameters :
**Output parameters :
**    Remark :
********************************************************************************************************/
void KEY_Init(void)
{
    GPIO_InitTypeDef GPIO_InitStructure;
    /*enable GPIOA,GPIOB,GPIOC clock */
    RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOA | RCC_AHB1Periph_GPIOB | RCC_AHB1Periph_GPIOC, ENABLE);

    /*PC13,K1*/
    GPIO_InitStructure.GPIO_Pin  = GPIO_Pin_13;
    /* configure pull-up  input */
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IPU;
    /* initializationGPIOC13*/
    GPIO_Init(GPIOC, &GPIO_InitStructure);

    /*PA0,K2(WK_UP)*/
    GPIO_InitStructure.GPIO_Pin  = GPIO_Pin_0;
    /* configure pull-down input */
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IPD;
    /* initializationGPIOA0*/
    GPIO_Init(GPIOA, &GPIO_InitStructure);

    /*PB10,PB11,K3,K4*/
    GPIO_InitStructure.GPIO_Pin  = GPIO_Pin_10 | GPIO_Pin_11;
    /* configure pull-up  input */
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IPU;
    /* initializationGPIOB.10,11*/
    GPIO_Init(GPIOB, &GPIO_InitStructure);
}


/********************************************************************************************************
**Function information :u8 KEY_Scan(u8 mode)
**Function description :button deal with function
**Input parameters :mode  mode:0,not  support continuous pressing ;1, support continuous pressing ;
**Output parameters :0,no button down ;KEY1_PRES,KEY1down ;WKUP_PRES,WK_UPdown ;KEY3_PRES,KEY3down ;KEY4_PRES,KEY4down
**    Remark :
********************************************************************************************************/
u8 KEY_Scan(u8 mode)
{

    static u8 key_up = 1;
    /*support double-click*/
    if(mode)key_up = 1;
    if(key_up && (KEY1 == 0 || WK_UP == 1 || KEY3 == 0 || KEY4 == 0)) {
        /*Debounce*/
        delay_ms(10);
        key_up = 0;
        if(KEY1 == 0)return KEY1_PRES;
        else if(WK_UP == 1)return WKUP_PRES;
        else if(KEY3 == 0)return KEY3_PRES;
        else if(KEY4 == 0)return KEY4_PRES;
    }
    else if(KEY1 == 1 && KEY3 == 1 && KEY4 == 1 && WK_UP == 0)key_up = 1;
    /*none button down */
    return 0;
}
