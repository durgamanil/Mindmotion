#include "HAL_conf.h"
#include "HAL_device.h"
#include "stdio.h"


static u8  fac_us = 0;

static u16 fac_ms = 0;
char printBuf[100];

void delay_init(void);
void delay_ms(u16 nms);
void UartSendGroup(u8* buf, u16 len);
void uart_initwBaudRate(u32 bound);
void LED_Init(void);
u8 FLASH_Program(void);

#define LED4_ON()  GPIO_ResetBits(GPIOB,GPIO_Pin_5)
#define LED4_OFF()  GPIO_SetBits(GPIOB,GPIO_Pin_5)
#define LED4_TOGGLE()  (GPIO_ReadOutputDataBit(GPIOB,GPIO_Pin_5))?(GPIO_ResetBits(GPIOB,GPIO_Pin_5)):(GPIO_SetBits(GPIOB,GPIO_Pin_5))

#define LED3_ON()  GPIO_ResetBits(GPIOB,GPIO_Pin_4)
#define LED3_OFF()  GPIO_SetBits(GPIOB,GPIO_Pin_4)
#define LED3_TOGGLE()  (GPIO_ReadOutputDataBit(GPIOB,GPIO_Pin_4))?(GPIO_ResetBits(GPIOB,GPIO_Pin_4)):(GPIO_SetBits(GPIOB,GPIO_Pin_4))

#define LED1_ON()  GPIO_ResetBits(GPIOA,GPIO_Pin_15)
#define LED1_OFF()  GPIO_SetBits(GPIOA,GPIO_Pin_15)
#define LED1_TOGGLE()  (GPIO_ReadOutputDataBit(GPIOA,GPIO_Pin_15))?(GPIO_ResetBits(GPIOA,GPIO_Pin_15)):(GPIO_SetBits(GPIOA,GPIO_Pin_15))

#define FLASH_PAGE_SIZE    ((uint16_t)0x400)
#define BANK1_WRITE_START_ADDR  ((uint32_t)0x08002800)
#define BANK1_WRITE_END_ADDR    ((uint32_t)0x08003200)
uint32_t Data = 0x12345679;
volatile FLASH_Status FLASHStatus = FLASH_COMPLETE;

/********************************************************************************************************
**Function information :main(void)
**Function description :
**Input parameters :none
**Output parameters :none
**    Remark :Choose to erase all before downloading the program
********************************************************************************************************/
int main(void)
{
    u8 t;
    delay_init();
    LED_Init();
    uart_initwBaudRate(9600);
    t = FLASH_Program();

    if(t == 0)
        while(1) {
            UartSendGroup((u8*)printBuf, sprintf(printBuf, "program ok\r\n"));
            LED1_TOGGLE();
            LED3_TOGGLE();
            LED4_TOGGLE();
            delay_ms(1000);
        }
    else
        while(1) {
            UartSendGroup((u8*)printBuf, sprintf(printBuf, "program error\r\n"));
            delay_ms(1000);
        }
}

/********************************************************************************************************
**Function information :void uart_initwBaudRate(u32 bound)
**Function description :UART initialization
**Input parameters :bound
**Output parameters :
**    Remark :
********************************************************************************************************/
void uart_initwBaudRate(u32 bound)
{

    GPIO_InitTypeDef GPIO_InitStructure;
    UART_InitTypeDef UART_InitStructure;

    RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOA, ENABLE);

    /*UART1_TX   GPIOA.9*/
    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_9;
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;

    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP;
    GPIO_Init(GPIOA, &GPIO_InitStructure);
    GPIO_PinAFConfig(GPIOA, GPIO_PinSource9, GPIO_AF_7);

    /*UART1_RX  GPIOA.10 initialization*/
    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_10;
    /*Floating input*/
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IN_FLOATING;
    GPIO_Init(GPIOA, &GPIO_InitStructure);
    GPIO_PinAFConfig(GPIOA, GPIO_PinSource10, GPIO_AF_7);

    /*UART  initialization configure */
    RCC_APB2PeriphClockCmd(RCC_APB2Periph_UART1, ENABLE);


    UART_InitStructure.UART_BaudRate = bound;

    UART_InitStructure.UART_WordLength = UART_WordLength_8b;

    UART_InitStructure.UART_StopBits = UART_StopBits_1;

    UART_InitStructure.UART_Parity = UART_Parity_No;

    UART_InitStructure.UART_HardwareFlowControl = UART_HardwareFlowControl_None;

    UART_InitStructure.UART_Mode = UART_Mode_Rx | UART_Mode_Tx;
    /* initialization UART 1*/
    UART_Init(UART1, &UART_InitStructure);

    UART_ITConfig(UART1, UART_IT_RXIEN, ENABLE);
    /*enable  UART 1*/
    UART_Cmd(UART1, ENABLE);
}

/********************************************************************************************************
**Function information :u8 FLASH_Program(void)
**Function description :Program FLASH Bank1
**Input parameters :
**Output parameters :
**    Remark :
********************************************************************************************************/
u8 FLASH_Program(void)
{

    /* Unlock the Flash Bank1 Program Erase controller */
    FLASH_Unlock();

    /* Clear All pending flags */
    FLASH_ClearFlag(FLASH_FLAG_EOP | FLASH_FLAG_PGERR | FLASH_FLAG_WRPRTERR);

    FLASH_ErasePage(BANK1_WRITE_START_ADDR);

    FLASH_ClearFlag(FLASH_FLAG_EOP );

    FLASHStatus = FLASH_ProgramWord(0x08001FFC, Data);

    FLASH_ClearFlag(FLASH_FLAG_EOP );

    FLASH_Lock();

    UartSendGroup((u8*)printBuf, sprintf(printBuf, "%x\r\n", (*(__IO uint32_t*) 0x08001FFC)));

    if((*(__IO uint32_t*) 0x08001FFC) != Data) {
        return 1;
    }
    return 0;
}

/********************************************************************************************************
**Function information :void delay_init(void)
**Function description : initialization delay function
**Input parameters :
**Output parameters :
**Common functions :
********************************************************************************************************/
void delay_init(void)
{

    SysTick_CLKSourceConfig(SysTick_CLKSource_HCLK_Div8);

    fac_us = SystemCoreClock / 8000000;

    fac_ms = (u16)fac_us * 1000;
}


/********************************************************************************************************
**Function information :void delay_ms(u16 nms)
**Function description :delay nms
**Input parameters :nms
**Output parameters :
**    Remark :SysTick->LOAD 24 bit register,and so,maximum delay  :nms<=0xffffff*8*1000/SYSCLK,At 72 MHz,nms<=1864
********************************************************************************************************/
void delay_ms(u16 nms)
{
    u32 temp;

    SysTick->LOAD = (u32)nms * fac_ms;

    SysTick->VAL = 0x00;

    SysTick->CTRL |= SysTick_CTRL_ENABLE_Msk ;
    do {
        temp = SysTick->CTRL;
    }

    while((temp & 0x01) && !(temp & (1 << 16)));

    SysTick->CTRL &= ~SysTick_CTRL_ENABLE_Msk;

    SysTick->VAL = 0X00;
}

/********************************************************************************************************
**Function information :LED_Init(void)
**Function description :LED initialization
**Input parameters :none
**Output parameters :none
********************************************************************************************************/
void LED_Init(void)
{
    GPIO_InitTypeDef  GPIO_InitStructure;

    RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOA | RCC_AHB1Periph_GPIOB, ENABLE);

    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_15;
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
    GPIO_Init(GPIOA, &GPIO_InitStructure);

    GPIO_InitStructure.GPIO_Pin  = GPIO_Pin_4 | GPIO_Pin_5;
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
    GPIO_Init(GPIOB, &GPIO_InitStructure);
    LED1_OFF();
    LED3_OFF();
    LED4_OFF();
}


/********************************************************************************************************
**Function information :void UartSendByte(u8 dat)
**Function description :UART send  data
**Input parameters :dat
**Output parameters :
**    Remark :
********************************************************************************************************/
void UartSendByte(u8 dat)
{
    UART_SendData( UART1, dat);
    while(!UART_GetFlagStatus(UART1, UART_FLAG_TXEPT));
}


/********************************************************************************************************
**Function information :void UartSendGroup(u8* buf,u16 len)
**Function description :UART send  data
**Input parameters :buf,len
**Output parameters :
**    Remark :
********************************************************************************************************/
void UartSendGroup(u8* buf, u16 len)
{
    while(len--)
        UartSendByte(*buf++);
}
