#include "HAL_conf.h"
#include "HAL_device.h"
#include "stdio.h"

u16 ADCVAL;

static u8  fac_us = 0;

static u16 fac_ms = 0;
extern u32 SystemCoreClock;
char printBuf[100];

void delay_init(void);
void uart_initwBaudRate(u32 bound);
void ADC1_SingleChannel(uint8_t ADC_Channel_x);
void GPIO_Configuration(void);
u16 Get_Adc_Average(uint8_t ADC_Channel_x, uint8_t times);
u16 ADC1_SingleChannel_Get(uint8_t ADC_Channel_x);
void delay_ms(u16 nms);
void UartSendGroup(u8* buf, u16 len);

/********************************************************************************************************
**Function information :int main (void)
**Function description :
**Input parameters :
**Output parameters :
**Common functions :
********************************************************************************************************/
int main(void)
{
    float fValue;
    delay_init();
    uart_initwBaudRate(9600);


    /* configure ADC1 single  conversions  mode ,channel 1enable */
    ADC1_SingleChannel( ADC_Channel_1);
    while(1) {
        ADCVAL = Get_Adc_Average(ADC_Channel_1, 5);
        fValue = ((float)ADCVAL / 4095) * 3.3;
        UartSendGroup((u8*)printBuf, sprintf(printBuf, "ADC1_CH_1=%.2fV\r\n", fValue));
        delay_ms(1000);
    }
}


/********************************************************************************************************
**Function information :void delay_init(void)
**Function description : initialization delay function
**Input parameters :
**Output parameters :
**Common functions :
********************************************************************************************************/
void delay_init(void)
{

    SysTick_CLKSourceConfig(SysTick_CLKSource_HCLK_Div8);

    fac_us = SystemCoreClock / 8000000;

    fac_ms = (u16)fac_us * 1000;
}


/********************************************************************************************************
**Function information :void delay_ms(u16 nms)
**Function description :delay nms
**Input parameters :nms
**Output parameters :
**    Remark :SysTick->LOAD 24 bit register,and so,maximum delay  :nms<=0xffffff*8*1000/SYSCLK,At 72 MHz,nms<=1864
********************************************************************************************************/
void delay_ms(u16 nms)
{
    u32 temp;

    SysTick->LOAD = (u32)nms * fac_ms;

    SysTick->VAL = 0x00;

    SysTick->CTRL |= SysTick_CTRL_ENABLE_Msk ;
    do {
        temp = SysTick->CTRL;
    }

    while((temp & 0x01) && !(temp & (1 << 16)));

    SysTick->CTRL &= ~SysTick_CTRL_ENABLE_Msk;

    SysTick->VAL = 0X00;
}


/********************************************************************************************************
**Function information :void uart_initwBaudRate(u32 bound)
**Function description :UART initialization
**Input parameters :bound
**Output parameters :
**    Remark :
********************************************************************************************************/
void uart_initwBaudRate(u32 bound)
{

    GPIO_InitTypeDef GPIO_InitStructure;
    UART_InitTypeDef UART_InitStructure;

    RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOA, ENABLE);

    /*UART1_TX   GPIOA.9*/
    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_9;
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;

    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP;
    GPIO_Init(GPIOA, &GPIO_InitStructure);
    GPIO_PinAFConfig(GPIOA, GPIO_PinSource9, GPIO_AF_7);

    /*UART1_RX  GPIOA.10 initialization*/
    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_10;
    /*Floating input*/
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IN_FLOATING;
    GPIO_Init(GPIOA, &GPIO_InitStructure);
    GPIO_PinAFConfig(GPIOA, GPIO_PinSource10, GPIO_AF_7);

    /*UART  initialization configure */
    RCC_APB2PeriphClockCmd(RCC_APB2Periph_UART1, ENABLE);


    UART_InitStructure.UART_BaudRate = bound;

    UART_InitStructure.UART_WordLength = UART_WordLength_8b;

    UART_InitStructure.UART_StopBits = UART_StopBits_1;

    UART_InitStructure.UART_Parity = UART_Parity_No;

    UART_InitStructure.UART_HardwareFlowControl = UART_HardwareFlowControl_None;

    UART_InitStructure.UART_Mode = UART_Mode_Rx | UART_Mode_Tx;
    /* initialization UART 1*/
    UART_Init(UART1, &UART_InitStructure);

    UART_ITConfig(UART1, UART_IT_RXIEN, ENABLE);
    /*enable  UART 1*/
    UART_Cmd(UART1, ENABLE);
}


/********************************************************************************************************
**Function information :void ADC1_SingleChannel(uint8_t ADC_Channel_x)
**Function description : configure ADC1single  conversions  mode
**Input parameters :ADC_Channel_x , x 0~8
**Output parameters :none
**    Remark :
********************************************************************************************************/
void ADC1_SingleChannel(uint8_t ADC_Channel_x)
{
    ADC_InitTypeDef  ADC_InitStructure;


    GPIO_Configuration();
    RCC_APB2PeriphClockCmd(RCC_APB2Periph_ADC1, ENABLE);

    /* Initialize the ADC_PRESCARE values */
    ADC_InitStructure.ADC_PRESCARE = ADC_PCLK2_PRESCARE_16;
    /* Initialize the ADC_Mode member */
    ADC_InitStructure.ADC_Mode = ADC_Mode_Single;
    /* Initialize the ADC_DataAlign member */
    ADC_InitStructure.ADC_DataAlign = ADC_DataAlign_Right;
    /* Initialize the ADC_ExternalTrigConv member */
    /*ADC1 channel 1,PA1*/
    ADC_InitStructure.ADC_ExternalTrigConv = ADC_ExternalTrigConv_T1_CC1;
    ADC_Init(ADC1, &ADC_InitStructure);

    /*Block all channel */
    ADC_RegularChannelConfig(ADC1, 9, 0, 0);

    ADC_RegularChannelConfig(ADC1, ADC_Channel_x, 0, 0);

    ADC_Cmd(ADC1, ENABLE);

}


/********************************************************************************************************
**Function information :void GPIO_Configuration(void)
**Function description :GPIO configure
**Input parameters :
**Output parameters :
**    Remark :
********************************************************************************************************/
void GPIO_Configuration(void)
{
    GPIO_InitTypeDef GPIO_InitStructure;
    RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOA, ENABLE);

    GPIO_InitStructure.GPIO_Pin  =  GPIO_Pin_1 | GPIO_Pin_2;
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AIN;
    GPIO_Init(GPIOA, &GPIO_InitStructure);
}


/********************************************************************************************************
**Function information :Get_Adc_Average(uint8_t ADC_Channel_x,uint8_t times)
**Function description :Get the average value of the ADC1 sample value several times
**Input parameters :ADC_Channel_x , x 0~8
**Output parameters :puiADData ADC read data
********************************************************************************************************/
u16 Get_Adc_Average(uint8_t ADC_Channel_x, uint8_t times)
{
    u32 temp_val = 0;
    u8 t;
    u8 delay;
    for(t = 0; t < times; t++) {
        temp_val += ADC1_SingleChannel_Get(ADC_Channel_x);
        for(delay = 0; delay < 100; delay++);
    }
    return temp_val / times;
}


/********************************************************************************************************
**Function information :ADC1_SingleChannel_Get(uint8_t ADC_Channel_x)
**Function description :Get ADC1 conversion data
**Input parameters :ADC_Channel_x , x 0~8
**Output parameters :puiADData ADC read data
********************************************************************************************************/
u16 ADC1_SingleChannel_Get(uint8_t ADC_Channel_x)
{
    u16 puiADData;

    ADC_SoftwareStartConvCmd(ADC1, ENABLE);

    while(!(ADC1->ADSTA & ADC_FLAG_EOC));

    puiADData = ADC1->ADDATA & 0xfff;

    ADC_ClearFlag(ADC1, ADC_FLAG_EOC);
    /*ADST bit in ADCR register is enabled, software conversion is complete*/

    return puiADData;
}


/********************************************************************************************************
**Function information :void UartSendByte(u8 dat)
**Function description :UART send  data
**Input parameters :dat
**Output parameters :
**    Remark :
********************************************************************************************************/
void UartSendByte(u8 dat)
{
    UART_SendData( UART1, dat);
    while(!UART_GetFlagStatus(UART1, UART_FLAG_TXEPT));
}


/********************************************************************************************************
**Function information :void UartSendGroup(u8* buf,u16 len)
**Function description :UART send  data
**Input parameters :buf,len
**Output parameters :
**    Remark :
********************************************************************************************************/
void UartSendGroup(u8* buf, u16 len)
{
    while(len--)
        UartSendByte(*buf++);
}
