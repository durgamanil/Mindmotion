#include "HAL_conf.h"
#include "HAL_device.h"
#include "stdio.h"

void HSE_Pll_test(unsigned int pllmul);

/********************************************************************************************************
**Function information :int main (void)
**Function description :After booting,ARMLED toggle
**Input parameters :
**Output parameters :
********************************************************************************************************/
int main(void)
{
    /* System clock source switch*/
    HSE_Pll_test(RCC_PLLMul_12);

    while(1) {
    }
}


/********************************************************************************************************
**Function information :SystemClk_HSEInit (void)
**Function description :system clock  initialization function , initialization
**Input parameters :none
**Output parameters :none
********************************************************************************************************/
void SystemClk_HSEInit(void)
{
    GPIO_InitTypeDef  GPIO_InitStructure;
    RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOA, ENABLE);

    /*mco  pa8*/
    GPIO_InitStructure.GPIO_Pin  = GPIO_Pin_8;
    GPIO_InitStructure.GPIO_Speed =  GPIO_Speed_10MHz;

    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP;
    GPIO_Init(GPIOA, &GPIO_InitStructure);
    GPIO_PinAFConfig(GPIOA, GPIO_PinSource8, GPIO_AF_0);

    RCC_DeInit();

    RCC_HSEConfig(RCC_HSE_ON);
    while(1) {
        if(RCC_WaitForHSEStartUp() != 0) {
            break;
        }
    }

    /* System clock source switch*/
    RCC_SYSCLKConfig(RCC_SYSCLKSource_HSE);
    /*output system clock*/
    RCC_MCOConfig(RCC_MCO_SYSCLK);
}


/********************************************************************************************************
**Function information :SystemClkPll(unsigned int pllmul)
**Function description :System clock source switch
**Input parameters :pllmul,multiple
**Output parameters :none
********************************************************************************************************/
void SystemClkPll(unsigned int pllmul)
{
    /*enable PLL*/
    RCC_PLLCmd(ENABLE);

    while(1) {
        /*wait PLL ready*/
        if(RCC->CR & 0x02000000) {
            break;
        }
    }

    /* clock wait  status */
    FLASH_SetLatency(FLASH_Latency_2);

    /*output PLL clock*/
    RCC_MCOConfig(RCC_MCO_PLLCLK_Div2);
    /* System clock source switch */
    RCC_SYSCLKConfig(RCC_SYSCLKSource_PLLCLK);
}


/********************************************************************************************************
**Function information :HSE_Pll_test(unsigned int pllmul)
**Function description :System clock source switch
**Input parameters :pllmul,multiple
**Output parameters :none
********************************************************************************************************/
void HSE_Pll_test(unsigned int pllmul)
{
    SystemClk_HSEInit();

    RCC_PLLConfig(RCC_PLLSource_HSE_Div1, pllmul);
    SystemClkPll(pllmul);
}


/********************************************************************************************************
**Function information :LSE_clk()
**Function description :nternal low frequency clock and observe PA8 through oscilloscope pin 32.786KHz
**Input parameters :none
**Output parameters :none
********************************************************************************************************/
void LSE_clk()
{
    GPIO_InitTypeDef  GPIO_InitStructure;
    RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOA, ENABLE);

    /*mco  pa8*/
    GPIO_InitStructure.GPIO_Pin  = GPIO_Pin_8;
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;

    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP;
    GPIO_Init(GPIOA, &GPIO_InitStructure);
    GPIO_PinAFConfig(GPIOA, GPIO_PinSource8, GPIO_AF_0);

    RCC_APB1PeriphClockCmd(RCC_APB1Periph_PWR, ENABLE);
    RCC_APB1PeriphClockCmd(RCC_APB1Periph_BKP, ENABLE);

    /*enable PWR_CR DBP bit*/
    PWR_BackupAccessCmd(ENABLE);

    RCC_LSEConfig(RCC_LSE_ON);

    while(1) {
        /*wait clock ready*/
        if(RCC->BDCR & 0x00000002) {
            break;
        }
    }
    /*output LSE CLOCK*/
    RCC_MCOConfig(RCC_MCO_LSE);
}


/********************************************************************************************************
**Function information :HSE_HSI_Change()
**Function description :System clock source switch
**Input parameters :none
**Output parameters :none
********************************************************************************************************/
void HSE_HSI_Change()
{
    /*CSS on*/
    RCC_ClockSecuritySystemCmd(ENABLE);
    SystemClk_HSEInit();

    /*close HESON*/
    RCC->CR &= 0xfffeffff;
}

