#include "HAL_conf.h"
#include "HAL_device.h"
#include "stdio.h"

void HSI_Pll_test(unsigned int pllmul);

/********************************************************************************************************
**Function information :int main (void)
**Function description :After booting,ARMLED toggle
**Input parameters :
**Output parameters :
********************************************************************************************************/
int main(void)
{
    /* HSI Octave*/
    HSI_Pll_test(RCC_PLLMul_6);

    while(1) {

    }
}


/********************************************************************************************************
**Function information :SystemClk_HSIInit (void)
**Function description :SYSTEM clock  initialization function ,
**Input parameters :none
**Output parameters :none
********************************************************************************************************/
void SystemClk_HSIInit()
{

    GPIO_InitTypeDef  GPIO_InitStructure;
    RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOA, ENABLE);
    /*mco  pa8*/
    GPIO_InitStructure.GPIO_Pin  = GPIO_Pin_8;
    GPIO_InitStructure.GPIO_Speed =  GPIO_Speed_10MHz;

    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP;
    GPIO_Init(GPIOA, &GPIO_InitStructure);
    GPIO_PinAFConfig(GPIOA, GPIO_PinSource8, GPIO_AF_0);
    /*ENABLE HSI */
    RCC_HSICmd(ENABLE);

    /*USE MCO OUTPUT SYSTEM CLOCK */
    RCC_MCOConfig(RCC_MCO_SYSCLK);
    /* HSI as the system clock source */
    RCC_SYSCLKConfig(RCC_SYSCLKSource_HSI);
}

/********************************************************************************************************
**Function information :SystemClkPll(unsigned int pllmul)
**Function description :PLL  clock
**Input parameters : pllmul,multiple
**Output parameters :none
********************************************************************************************************/
void SystemClkPll(unsigned int pllmul)
{
    /*enable PLL*/
    RCC_PLLCmd(ENABLE);

    while(1) {
        /*PLL ready*/
        if(RCC->CR & 0x02000000) {
            break;
        }
    }

    /* clock wait  status */
    FLASH_SetLatency(FLASH_Latency_2);

    /*output system clock*/
    RCC_MCOConfig(RCC_MCO_PLLCLK_Div2);
    /* PLL as the system clock source */
    RCC_SYSCLKConfig(RCC_SYSCLKSource_PLLCLK);
}

/********************************************************************************************************
**Function information :HSE_Pll_test(unsigned int pllmul)
**Function description :System clock source switch
**Input parameters :pllmul,multiple
**Output parameters :none
********************************************************************************************************/
void HSI_Pll_test(unsigned int pllmul)
{

    SystemClk_HSIInit();

    RCC_PLLConfig(RCC_PLLSource_HSI_Div4, pllmul);
    SystemClkPll(pllmul);
}

/********************************************************************************************************
**Function information :LSI_clk()
**Function description :LSI confinge
**Input parameters :none
**Output parameters :none
********************************************************************************************************/
void LSI_clk()
{

    GPIO_InitTypeDef  GPIO_InitStructure;
    RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOA, ENABLE);
    /*mco  pa8*/
    GPIO_InitStructure.GPIO_Pin  = GPIO_Pin_8;
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;

    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP;
    GPIO_Init(GPIOA, &GPIO_InitStructure);
    GPIO_PinAFConfig(GPIOA, GPIO_PinSource8, GPIO_AF_0);
    //open lsi on
    RCC_LSICmd(ENABLE);

    while(1) {
        /*wait clock ready*/
        if(RCC->CSR & 0x00000002) {
            break;
        }
    }

    RCC_MCOConfig(RCC_MCO_LSI);
}
