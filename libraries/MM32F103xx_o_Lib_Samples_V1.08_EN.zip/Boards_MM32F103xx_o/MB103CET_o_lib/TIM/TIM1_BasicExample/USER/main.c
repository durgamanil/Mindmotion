#include "HAL_conf.h"
#include "HAL_device.h"
#include "stdio.h"

void DelayMs(u32 ulMs);
void NVIC_Configuration(void);
void SysInit(void);
extern u32 SystemCoreClock;
void uart_initwBaudRate(u32 bound);
void Tim1_UPCount_test(u16 Prescaler, u16 Period);
void Tim1_UPStatusOVCheck_test(void);
void UartSendGroup(u8* buf, u16 len);

char printBuf[100];

/********************************************************************************************************
**Function information :int main (void)
**Function description :
**Input parameters :
**Output parameters :
**Common functions :
********************************************************************************************************/
int main(void)
{
    unsigned int uiCnt = 0;
    uart_initwBaudRate(9600);

    /*PCLK2 clock (96MHz) 9600 frequency division, counter value is 10000, overflow every 1 second*/
    Tim1_UPCount_test(SystemCoreClock / 10000 - 1, 10000 - 1);
    while(1) {
        for(uiCnt = 0; ; uiCnt++) {
            /*wait Timer overflow */
            Tim1_UPStatusOVCheck_test();


            UartSendGroup((u8*)printBuf, sprintf(printBuf, "0x%x\r\n", uiCnt));
        }
    }
}

/********************************************************************************************************
**Function information :void uart_initwBaudRate(u32 bound)
**Function description :UART initialization
**Input parameters :bound
**Output parameters :
**    Remark :
********************************************************************************************************/
void uart_initwBaudRate(u32 bound)
{

    GPIO_InitTypeDef GPIO_InitStructure;
    UART_InitTypeDef UART_InitStructure;

    RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOA, ENABLE);

    /*UART1_TX   GPIOA.9*/
    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_9;
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;

    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP;
    GPIO_Init(GPIOA, &GPIO_InitStructure);
    GPIO_PinAFConfig(GPIOA, GPIO_PinSource9, GPIO_AF_7);

    /*UART1_RX  GPIOA.10 initialization*/
    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_10;
    /*Floating input*/
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IN_FLOATING;
    GPIO_Init(GPIOA, &GPIO_InitStructure);
    GPIO_PinAFConfig(GPIOA, GPIO_PinSource10, GPIO_AF_7);

    /*UART  initialization configure */
    RCC_APB2PeriphClockCmd(RCC_APB2Periph_UART1, ENABLE);


    UART_InitStructure.UART_BaudRate = bound;

    UART_InitStructure.UART_WordLength = UART_WordLength_8b;

    UART_InitStructure.UART_StopBits = UART_StopBits_1;

    UART_InitStructure.UART_Parity = UART_Parity_No;

    UART_InitStructure.UART_HardwareFlowControl = UART_HardwareFlowControl_None;

    UART_InitStructure.UART_Mode = UART_Mode_Rx | UART_Mode_Tx;
    /* initialization UART 1*/
    UART_Init(UART1, &UART_InitStructure);

    UART_ITConfig(UART1, UART_IT_RXIEN, ENABLE);
    /*enable  UART 1*/
    UART_Cmd(UART1, ENABLE);
}

/********************************************************************************************************
**Function information :void Tim1_UPCount_test1(u16 Period,u16 Prescaler)
**Function description : configure Timer 1Count up mode
**Input parameters :Period 16-bit counter reload value,Prescaler Clock prescaler value
**Output parameters :none
********************************************************************************************************/
void Tim1_UPCount_test(u16 Prescaler, u16 Period)
{
    TIM_TimeBaseInitTypeDef TIM_StructInit;


    RCC_APB2PeriphClockCmd(RCC_APB2Periph_TIM1, ENABLE);


    TIM_StructInit.TIM_Period = Period;

    TIM_StructInit.TIM_Prescaler = Prescaler;

    TIM_StructInit.TIM_ClockDivision = TIM_CKD_DIV1;

    TIM_StructInit.TIM_CounterMode = TIM_CounterMode_Down;
    TIM_StructInit.TIM_RepetitionCounter = 0;
    TIM_TimeBaseInit(TIM1, &TIM_StructInit);

    TIM_Cmd(TIM1, ENABLE);


    TIM_ClearFlag(TIM1, TIM_FLAG_Update);
}


/********************************************************************************************************
**Function information :Tim1_UPStatusOVCheck_test1(void)
**Function description :wait Timer overflow
**Input parameters :none
**Output parameters :none
********************************************************************************************************/
void Tim1_UPStatusOVCheck_test(void)
{

    while(TIM_GetFlagStatus(TIM1, TIM_FLAG_Update) == RESET);

    TIM_ClearFlag(TIM1, TIM_FLAG_Update);
}


/********************************************************************************************************
**Function information :void UartSendByte(u8 dat)
**Function description :UART send  data
**Input parameters :dat
**Output parameters :
**    Remark :
********************************************************************************************************/
void UartSendByte(u8 dat)
{
    UART_SendData( UART1, dat);
    while(!UART_GetFlagStatus(UART1, UART_FLAG_TXEPT));
}


/********************************************************************************************************
**Function information :void UartSendGroup(u8* buf,u16 len)
**Function description :UART send  data
**Input parameters :buf,len
**Output parameters :
**    Remark :
********************************************************************************************************/
void UartSendGroup(u8* buf, u16 len)
{
    while(len--)
        UartSendByte(*buf++);
}

