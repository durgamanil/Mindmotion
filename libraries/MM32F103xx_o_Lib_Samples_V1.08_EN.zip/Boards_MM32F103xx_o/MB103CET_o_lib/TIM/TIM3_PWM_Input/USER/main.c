#include "HAL_conf.h"
#include "HAL_device.h"
#include "stdio.h"


static u8  fac_us = 0;

static u16 fac_ms = 0;
char printBuf[100];
u16 period = 0;
u16 duty  = 0;
u8 CollectFlag = 0;

void delay_init(void);
void uart_initwBaudRate(u32 bound);
void delay_ms(u16 nms);
void UartSendGroup(u8* buf, u16 len);
void TIM3_PWM_Init(u16 arr, u16 psc);
void TIM4_PWMINPUT_INIT(u16 arr, u16 psc);

/********************************************************************************************************
**Function information :int main (void)
**Function description :Connect PB7 and PA6 (Ain4) on the board with DuPont cable
**Input parameters :
**Output parameters :
**Common functions :uart_printf("0x%x\r\n",Uart1RxTest(UART1));   uart_printf("0x%x",sizeof(u32));
********************************************************************************************************/
extern u16 period;
extern u16 duty ;
extern u8 CollectFlag ;
extern u32 SystemCoreClock;

/*PB7As input capture pin, connect PB7 and PA6*/
int main(void)
{
    delay_init();
    uart_initwBaudRate(9600);


    TIM3_PWM_Init(1000 - 1, SystemCoreClock / 1000000 - 1);
    /* configure Duty cycle*/
    TIM_SetCompare1(TIM3, 200);

    /*pwm input initialization capture at 1M frequency*/
    TIM4_PWMINPUT_INIT(0xFFFF, SystemCoreClock / 1000000 - 1);

    UartSendGroup((u8*)printBuf, sprintf(printBuf, "Please connect PB7 and PA6\r\n"));

    while(1) {
        if(CollectFlag == 1) {
            /*print Duty cycle*/
            UartSendGroup((u8*)printBuf, sprintf(printBuf, "duty  	= %d%% \r\n", duty * 100 / period));

            UartSendGroup((u8*)printBuf, sprintf(printBuf, "cycle 	= %dKHz\r\n", 1000 / period));

            UartSendGroup((u8*)printBuf, sprintf(printBuf, "period  = %dus\r\n", period));
            CollectFlag = 0;
        }
        delay_ms(100);
    }
}


/********************************************************************************************************
**Function information :void TIM3_PWM_Init(u16 arr,u16 psc)
**Function description :TIM3 PWM initialization
**Input parameters :u16 arr,u16 psc
**Output parameters :
**Common functions :
********************************************************************************************************/
void TIM3_PWM_Init(u16 arr, u16 psc)
{
    GPIO_InitTypeDef GPIO_InitStructure;
    TIM_TimeBaseInitTypeDef  TIM_TimeBaseStructure;
    TIM_OCInitTypeDef  TIM_OCInitStructure;

    RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM3, ENABLE);
    RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOA, ENABLE);

    // configure This pin multiplexes the push-pull output function and outputs the PWM pulse waveform of TIM3 CH1
    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_6;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP;
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_Init(GPIOA, &GPIO_InitStructure);
    GPIO_PinAFConfig(GPIOA, GPIO_PinSource6, GPIO_AF_2);


    TIM_TimeBaseStructure.TIM_Period = arr;

    TIM_TimeBaseStructure.TIM_Prescaler = psc;
    /* configure Clock division :TDTS = Tck_tim*/
    TIM_TimeBaseStructure.TIM_ClockDivision = 0;
    /*TIMCount up mode */
    TIM_TimeBaseStructure.TIM_CounterMode = TIM_CounterMode_Up;

    TIM_TimeBaseInit(TIM3, &TIM_TimeBaseStructure);

    /* choose Timer  mode :TIM pulse width modulation  mode 1*/
    TIM_OCInitStructure.TIM_OCMode = TIM_OCMode_PWM1;
    /*compare output enable */
    TIM_OCInitStructure.TIM_OutputState = TIM_OutputState_Enable;

    TIM_OCInitStructure.TIM_Pulse = 0;

    TIM_OCInitStructure.TIM_OCPolarity = TIM_OCPolarity_High;


    TIM_OC1Init(TIM3, &TIM_OCInitStructure);

    TIM_OC1PreloadConfig(TIM3, TIM_OCPreload_Enable);


    TIM_ARRPreloadConfig(TIM3, ENABLE);

    /*enable TIMx peripheral*/
    TIM_Cmd(TIM3, ENABLE);
}


/********************************************************************************************************
**Function information :void TIM4_PWMINPUT_INIT(u16 arr,u16 psc)
**Function description :PWM input  initialization
**Input parameters :
**Output parameters :
**Common functions :
********************************************************************************************************/
void TIM4_PWMINPUT_INIT(u16 arr, u16 psc)
{
    TIM_TimeBaseInitTypeDef  TIM_TimeBaseStructure;
    NVIC_InitTypeDef 		 NVIC_InitStructure;
    TIM_ICInitTypeDef        TIM4_ICInitStructure;
    GPIO_InitTypeDef         GPIO_InitStructure;

    /*Open TIM4 clock*/
    RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM4, ENABLE);
    /*open gpioB clock*/
    RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOB, ENABLE);

    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_7;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IN_FLOATING;
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_Init(GPIOB, &GPIO_InitStructure);
    GPIO_PinAFConfig(GPIOB, GPIO_PinSource7, GPIO_AF_2);


    TIM_TimeBaseStructure.TIM_Period = arr;

    TIM_TimeBaseStructure.TIM_Prescaler = psc;
    /* configure Clock division :TDTS = Tck_tim*/
    TIM_TimeBaseStructure.TIM_ClockDivision = 0;
    /*TIMCount up mode */
    TIM_TimeBaseStructure.TIM_CounterMode = TIM_CounterMode_Up;

    TIM_TimeBaseInit(TIM4, &TIM_TimeBaseStructure);

    /* configure interrupt priority*/
    NVIC_InitStructure.NVIC_IRQChannel = TIM4_IRQn;
    NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 0;
    NVIC_InitStructure.NVIC_IRQChannelSubPriority = 1;
    NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
    NVIC_Init(&NVIC_InitStructure);

    TIM4_ICInitStructure.TIM_Channel = TIM_Channel_2;
    TIM4_ICInitStructure.TIM_ICPolarity = TIM_ICPolarity_Rising;
    TIM4_ICInitStructure.TIM_ICSelection = TIM_ICSelection_DirectTI;
    TIM4_ICInitStructure.TIM_ICPrescaler = TIM_ICPSC_DIV1;
    TIM4_ICInitStructure.TIM_ICFilter = 0x0;

    //TIM_ICInit(TIM4, &TIM4_ICInitStructure);
    /*PWM input  configure */
    TIM_PWMIConfig(TIM4, &TIM4_ICInitStructure);


    TIM_SelectInputTrigger(TIM4, TIM_TS_TI2FP2);
    /* configure  master and slave reset  mode */
    TIM_SelectSlaveMode(TIM4, TIM_SlaveMode_Reset);
    TIM_SelectMasterSlaveMode(TIM4, TIM_MasterSlaveMode_Enable);
    /* interrupt  configure */
    TIM_ITConfig(TIM4, TIM_IT_CC2 | TIM_IT_Update, ENABLE);
    /*clear  interrupt flag */
    TIM_ClearITPendingBit(TIM4, TIM_IT_CC2 | TIM_IT_Update);
    TIM_Cmd(TIM4, ENABLE);
}

/********************************************************************************************************
**Function information :void TIM4_IRQHandler(void)
**Function description :TIM4 interrupt function
**Input parameters :
**Output parameters :
**Common functions :
********************************************************************************************************/
void TIM4_IRQHandler(void)
{

    if (TIM_GetITStatus(TIM4, TIM_IT_CC2) != RESET) {

        duty = TIM_GetCapture1(TIM4);

        period	=	TIM_GetCapture2(TIM4);
        CollectFlag = 1;

    }
    /*clear  interrupt flag */
    TIM_ClearITPendingBit(TIM4, TIM_IT_CC2 | TIM_IT_Update);
}


/********************************************************************************************************
**Function information :void delay_init(void)
**Function description : initialization delay function
**Input parameters :
**Output parameters :
**Common functions :
********************************************************************************************************/
void delay_init(void)
{

    SysTick_CLKSourceConfig(SysTick_CLKSource_HCLK_Div8);

    fac_us = SystemCoreClock / 8000000;

    fac_ms = (u16)fac_us * 1000;
}


/********************************************************************************************************
**Function information :void delay_ms(u16 nms)
**Function description :delay nms
**Input parameters :nms
**Output parameters :
**    Remark :SysTick->LOAD 24 bit register,and so,maximum delay  :nms<=0xffffff*8*1000/SYSCLK,At 72 MHz,nms<=1864
********************************************************************************************************/
void delay_ms(u16 nms)
{
    u32 temp;

    SysTick->LOAD = (u32)nms * fac_ms;

    SysTick->VAL = 0x00;

    SysTick->CTRL |= SysTick_CTRL_ENABLE_Msk ;
    do {
        temp = SysTick->CTRL;
    }

    while((temp & 0x01) && !(temp & (1 << 16)));

    SysTick->CTRL &= ~SysTick_CTRL_ENABLE_Msk;

    SysTick->VAL = 0X00;
}

/********************************************************************************************************
**Function information :void uart_initwBaudRate(u32 bound)
**Function description :UART initialization
**Input parameters :bound
**Output parameters :
**    Remark :
********************************************************************************************************/
void uart_initwBaudRate(u32 bound)
{

    GPIO_InitTypeDef GPIO_InitStructure;
    UART_InitTypeDef UART_InitStructure;

    RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOA, ENABLE);

    /*UART1_TX   GPIOA.9*/
    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_9;
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;

    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP;
    GPIO_Init(GPIOA, &GPIO_InitStructure);
    GPIO_PinAFConfig(GPIOA, GPIO_PinSource9, GPIO_AF_7);

    /*UART1_RX  GPIOA.10 initialization*/
    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_10;
    /*Floating input*/
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IN_FLOATING;
    GPIO_Init(GPIOA, &GPIO_InitStructure);
    GPIO_PinAFConfig(GPIOA, GPIO_PinSource10, GPIO_AF_7);

    /*UART  initialization configure */
    RCC_APB2PeriphClockCmd(RCC_APB2Periph_UART1, ENABLE);


    UART_InitStructure.UART_BaudRate = bound;

    UART_InitStructure.UART_WordLength = UART_WordLength_8b;

    UART_InitStructure.UART_StopBits = UART_StopBits_1;

    UART_InitStructure.UART_Parity = UART_Parity_No;

    UART_InitStructure.UART_HardwareFlowControl = UART_HardwareFlowControl_None;

    UART_InitStructure.UART_Mode = UART_Mode_Rx | UART_Mode_Tx;
    /* initialization UART 1*/
    UART_Init(UART1, &UART_InitStructure);

    UART_ITConfig(UART1, UART_IT_RXIEN, ENABLE);
    /*enable  UART 1*/
    UART_Cmd(UART1, ENABLE);
}


/********************************************************************************************************
**Function information :void UartSendByte(u8 dat)
**Function description :UART send  data
**Input parameters :dat
**Output parameters :
**    Remark :
********************************************************************************************************/
void UartSendByte(u8 dat)
{
    UART_SendData( UART1, dat);
    while(!UART_GetFlagStatus(UART1, UART_FLAG_TXEPT));
}


/********************************************************************************************************
**Function information :void UartSendGroup(u8* buf,u16 len)
**Function description :UART send  data
**Input parameters :buf,len
**Output parameters :
**    Remark :
********************************************************************************************************/
void UartSendGroup(u8* buf, u16 len)
{
    while(len--)
        UartSendByte(*buf++);
}

