#include "HAL_conf.h"
#include "HAL_device.h"
#include "stdio.h"

char printBuf[100];

void uart_initwBaudRate(u32 bound);
void UartSendGroup(u8* buf, u16 len);
void Write_Iwdg_ON(unsigned short int IWDG_Prescaler, unsigned short int Reload);
void PVU_CheckStatus(void);
void RVU_CheckStatus(void);
void Write_Iwdg_RL(void);

/********************************************************************************************************
**Function information :int main (void)
**Function description :
**Input parameters :
**Output parameters :
********************************************************************************************************/
int main(void)
{
    uart_initwBaudRate(9600);
    UartSendGroup((u8*)printBuf, sprintf(printBuf, "uart ok!\r\n"));
    /* configure reset wite time 1.6s*/
    Write_Iwdg_ON(IWDG_Prescaler_32, 0xf);
    while(1) {
        /*none reset program enter while(1),The system keeps printing  UART  data*/
        Write_Iwdg_RL();
    }
}

/********************************************************************************************************
**Function information :void uart_initwBaudRate(u32 bound)
**Function description :UART initialization
**Input parameters :bound
**Output parameters :
**    Remark :
********************************************************************************************************/
void uart_initwBaudRate(u32 bound)
{

    GPIO_InitTypeDef GPIO_InitStructure;
    UART_InitTypeDef UART_InitStructure;

    RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOA, ENABLE);

    /*UART1_TX   GPIOA.9*/
    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_9;
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;

    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP;
    GPIO_Init(GPIOA, &GPIO_InitStructure);
    GPIO_PinAFConfig(GPIOA, GPIO_PinSource9, GPIO_AF_7);

    /*UART1_RX  GPIOA.10 initialization*/
    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_10;
    /*Floating input*/
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IN_FLOATING;
    GPIO_Init(GPIOA, &GPIO_InitStructure);
    GPIO_PinAFConfig(GPIOA, GPIO_PinSource10, GPIO_AF_7);

    /*UART  initialization configure */
    RCC_APB2PeriphClockCmd(RCC_APB2Periph_UART1, ENABLE);


    UART_InitStructure.UART_BaudRate = bound;

    UART_InitStructure.UART_WordLength = UART_WordLength_8b;

    UART_InitStructure.UART_StopBits = UART_StopBits_1;

    UART_InitStructure.UART_Parity = UART_Parity_No;

    UART_InitStructure.UART_HardwareFlowControl = UART_HardwareFlowControl_None;

    UART_InitStructure.UART_Mode = UART_Mode_Rx | UART_Mode_Tx;
    /* initialization UART 1*/
    UART_Init(UART1, &UART_InitStructure);

    UART_ITConfig(UART1, UART_IT_RXIEN, ENABLE);
    /*enable  UART 1*/
    UART_Cmd(UART1, ENABLE);
}

/********************************************************************************************************
**Function information :Write_Iwdg_PR(void)
**Function description :Enable IWDG
**Input parameters :IWDG_Prescaler can  IWDG_Prescaler_X, X 4,8,16,32,64,128,256,
**Output parameters :none
**    Remark :Reload<=0xfff,  LSI :40KHz   Tiwdg=(X/LSI)*Reload
********************************************************************************************************/
void Write_Iwdg_ON(unsigned short int IWDG_Prescaler, unsigned short int Reload)
{
    /*Enable LSI*/
    RCC_LSICmd(ENABLE);
    while(RCC_GetFlagStatus(RCC_FLAG_LSIRDY) == RESET);

    /* configure  clock  */
    PVU_CheckStatus();
    IWDG_WriteAccessCmd(0x5555);
    IWDG_SetPrescaler(IWDG_Prescaler);

    /* configure  value */
    RVU_CheckStatus();
    IWDG_WriteAccessCmd(0x5555);
    IWDG_SetReload(Reload & 0xfff);

    /*Reloads IWDG counter with value defined in the reload register */
    IWDG_ReloadCounter();
    IWDG_Enable();
}

/********************************************************************************************************
**Function information :PVU_CheckStatus(void)
**Function description :Checks whether the specified IWDG flag is set or not
**Input parameters :none
**Output parameters :none
********************************************************************************************************/
void PVU_CheckStatus(void)
{
    while(1) {
        /*Checks whether the specified IWDG flag is set or not */
        if(IWDG_GetFlagStatus(IWDG_FLAG_PVU) == RESET) {
            break;
        }
    }
}

/********************************************************************************************************
**Function information :RVU_CheckStatus(void)
**Function description :IWDG Flag
**Input parameters :none
**Output parameters :none
********************************************************************************************************/
void RVU_CheckStatus(void)
{
    while(1) {

        if(IWDG_GetFlagStatus(IWDG_FLAG_RVU) == RESET) {
            break;
        }
    }
}

/********************************************************************************************************
**Function information :void Write_Iwdg_RL(void)
**Function description :write function
**Input parameters :
**Output parameters :none
********************************************************************************************************/
void Write_Iwdg_RL(void)
{
    IWDG_ReloadCounter();
}

/********************************************************************************************************
**Function information :void UartSendByte(u8 dat)
**Function description :UART send  data
**Input parameters :dat
**Output parameters :
**    Remark :
********************************************************************************************************/
void UartSendByte(u8 dat)
{
    UART_SendData( UART1, dat);
    while(!UART_GetFlagStatus(UART1, UART_FLAG_TXEPT));
}


/********************************************************************************************************
**Function information :void UartSendGroup(u8* buf,u16 len)
**Function description :UART send  data
**Input parameters :buf,len
**Output parameters :
**    Remark :
********************************************************************************************************/
void UartSendGroup(u8* buf, u16 len)
{
    while(len--)
        UartSendByte(*buf++);
}

