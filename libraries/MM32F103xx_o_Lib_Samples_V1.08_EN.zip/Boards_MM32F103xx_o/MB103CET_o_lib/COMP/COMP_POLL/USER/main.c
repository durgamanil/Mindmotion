#include "HAL_conf.h"
#include "HAL_device.h"
#include "stdio.h"

char printBuf[100];
void UartSendGroup(u8* buf, u16 len);
void UartSendAscii(char *str);
void Comp_Config(uint32_t COMP_Selection_COMPx);
unsigned char Comp_StatusCheck(uint32_t COMP_Selection_COMPx);
void uart_initwBaudRate(u32 bound);
void GPIO_ConfigInit(void);
void RCC_ConfigInit(void);

/********************************************************************************************************
**Function information :int main (void)
**Function description :
**Input parameters :
**Output parameters :
********************************************************************************************************/
int main(void)
{
    int a, i;
    uart_initwBaudRate(9600);
    RCC_ConfigInit();

    Comp_Config(COMP_Selection_COMP1);

    while(1) {
        a = Comp_StatusCheck( COMP_Selection_COMP1);

        if(a == 0) {
            /*Forward input  less than reverse input */
            UartSendGroup((u8*)printBuf, sprintf(printBuf, "INP < INM \r\n"));
        }
        else if(a == 1) {
            /*Forward input  greater than reverse input */
            UartSendGroup((u8*)printBuf, sprintf(printBuf, "INP > INM \r\n"));
        }
        else {

            UartSendGroup((u8*)printBuf, sprintf(printBuf, "Param Error \r\n"));
        }
        i = 1000000; while(i--);
    }
}

/********************************************************************************************************
**Function information :void RCC_ConfigInit(void)
**Function description : clock  initialization
**Input parameters :
**Output parameters :
********************************************************************************************************/
void RCC_ConfigInit(void)
{

    RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOA, ENABLE);
    RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOB, ENABLE);
    RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOC, ENABLE);
    RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOD, ENABLE);

}

/********************************************************************************************************
**Function information :void GPIO_ConfigInit(void)
**Function description :GPIO configure
**Input parameters :
**Output parameters :
********************************************************************************************************/
void GPIO_ConfigInit(void)
{
    GPIO_InitTypeDef GPIO_InitStructure;

    GPIO_InitStructure.GPIO_Pin  =  GPIO_Pin_1 | GPIO_Pin_6;
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AIN;
    GPIO_Init(GPIOA, &GPIO_InitStructure);

}

/********************************************************************************************************
**Function information :void uart_initwBaudRate(u32 bound)
**Function description :UART initialization
**Input parameters :bound
**Output parameters :
**    Remark :
********************************************************************************************************/
void uart_initwBaudRate(u32 bound)
{

    GPIO_InitTypeDef GPIO_InitStructure;
    UART_InitTypeDef UART_InitStructure;

    RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOA, ENABLE);

    /*UART1_TX   GPIOA.9*/
    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_9;
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;

    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP;
    GPIO_Init(GPIOA, &GPIO_InitStructure);
    GPIO_PinAFConfig(GPIOA, GPIO_PinSource9, GPIO_AF_7);

    /*UART1_RX  GPIOA.10 initialization*/
    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_10;
    /*Floating input*/
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IN_FLOATING;
    GPIO_Init(GPIOA, &GPIO_InitStructure);
    GPIO_PinAFConfig(GPIOA, GPIO_PinSource10, GPIO_AF_7);

    /*UART  initialization configure */
    RCC_APB2PeriphClockCmd(RCC_APB2Periph_UART1, ENABLE);


    UART_InitStructure.UART_BaudRate = bound;

    UART_InitStructure.UART_WordLength = UART_WordLength_8b;

    UART_InitStructure.UART_StopBits = UART_StopBits_1;

    UART_InitStructure.UART_Parity = UART_Parity_No;

    UART_InitStructure.UART_HardwareFlowControl = UART_HardwareFlowControl_None;

    UART_InitStructure.UART_Mode = UART_Mode_Rx | UART_Mode_Tx;
    /* initialization UART 1*/
    UART_Init(UART1, &UART_InitStructure);

    UART_ITConfig(UART1, UART_IT_RXIEN, ENABLE);
    /*enable  UART 1*/
    UART_Cmd(UART1, ENABLE);
}

/********************************************************************************************************
**Function information :void UartSendByte(u8 dat)
**Function description :UART send  data
**Input parameters :
**Output parameters :
********************************************************************************************************/
void UartSendByte(u8 dat)
{
    UART_SendData( UART1, dat);
    while(!UART_GetFlagStatus(UART1, UART_FLAG_TXEPT));
}

/********************************************************************************************************
**Function information :void UartSendGroup(u8* buf,u16 len)
**Function description :UART send  data
**Input parameters :buf,len
**Output parameters :
**    Remark :
********************************************************************************************************/
void UartSendGroup(u8* buf, u16 len)
{
    while(len--)
        UartSendByte(*buf++);
}


/********************************************************************************************************
**Function information :void Comp_Config(uint32_t COMP_Selection_COMPx)
**Function description :COMP initialization
**Input parameters :
**Output parameters :
**    Remark :
********************************************************************************************************/
void Comp_Config(uint32_t COMP_Selection_COMPx)
{
    COMP_InitTypeDef COMP_InitStructure;
    GPIO_ConfigInit();
    RCC_APB2PeriphClockCmd(RCC_APB2Periph_COMP, ENABLE);

    /*comparer reverse input  3/4 Vref*/
    COMP_InitStructure.COMP_InvertingInput = COMP_InvertingInput_IO2;
    /* configure PA1 Comparator forward  input */
    COMP_InitStructure.COMP_NonInvertingInput = COMP_NonInvertingInput_IO2;
    COMP_InitStructure.COMP_Output = COMP_Output_None;
    COMP_InitStructure.COMP_BlankingSrce = COMP_BlankingSrce_None;
    COMP_InitStructure.COMP_OutputPol = COMP_OutputPol_NonInverted;
    COMP_InitStructure.COMP_Hysteresis = COMP_Hysteresis_No;
    COMP_InitStructure.COMP_Mode = COMP_Mode_MediumSpeed;

    COMP_Init(COMP_Selection_COMPx, &COMP_InitStructure);

    COMP_Cmd(COMP_Selection_COMPx, ENABLE);
}


/********************************************************************************************************
**Function information :unsigned char Comp_StatusCheck(uint32_t COMP_Selection_COMPx)
**Function description :COMP status check
**Input parameters :
**Output parameters :
**    Remark :
********************************************************************************************************/
unsigned char Comp_StatusCheck(uint32_t COMP_Selection_COMPx)
{
    unsigned char chCapStatus = 2;
    if(COMP_GetOutputLevel(COMP_Selection_COMPx) == 0) {
        chCapStatus = 0;
    }
    else {
        chCapStatus = 1;
    }
    return chCapStatus;
}
