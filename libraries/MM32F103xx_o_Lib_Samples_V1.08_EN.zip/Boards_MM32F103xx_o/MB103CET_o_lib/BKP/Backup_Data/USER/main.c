#include "HAL_conf.h"
#include "HAL_device.h"
#include "stdio.h"


static u8  fac_us = 0;

static u16 fac_ms = 0;

void delay_init(void);
void LED_Init(void);
void delay_ms(u16 nms);
u8 BKP_DATA(void);
void WriteToBackupReg(u16 FirstBackupData);
u8 CheckBackupReg(u16 FirstBackupData);

u16 BKPDataReg[10] = {
    BKP_DR1, BKP_DR2, BKP_DR3, BKP_DR4, BKP_DR5, BKP_DR6, BKP_DR7, BKP_DR8,
    BKP_DR9, BKP_DR10
};
u16 testdata[10] = {
    0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07, 0x08, 0x09, 0x0a
};

#define LED4_OFF()  GPIO_SetBits(GPIOB,GPIO_Pin_5)
#define LED4_TOGGLE()  (GPIO_ReadOutputDataBit(GPIOB,GPIO_Pin_5))?(GPIO_ResetBits(GPIOB,GPIO_Pin_5)):(GPIO_SetBits(GPIOB,GPIO_Pin_5))

#define LED3_OFF()  GPIO_SetBits(GPIOB,GPIO_Pin_4)
#define LED3_TOGGLE()  (GPIO_ReadOutputDataBit(GPIOB,GPIO_Pin_4))?(GPIO_ResetBits(GPIOB,GPIO_Pin_4)):(GPIO_SetBits(GPIOB,GPIO_Pin_4))

#define LED1_OFF()  GPIO_SetBits(GPIOA,GPIO_Pin_15)
#define LED1_TOGGLE()  (GPIO_ReadOutputDataBit(GPIOA,GPIO_Pin_15))?(GPIO_ResetBits(GPIOA,GPIO_Pin_15)):(GPIO_SetBits(GPIOA,GPIO_Pin_15))

/********************************************************************************************************
**Function information :int main(void)
**Function description :
**Input parameters :
**Output parameters :
********************************************************************************************************/
int main(void)
{
    u8 flag = 0;
    delay_init();
    LED_Init();
    /*Write data to BKP. If it succeeds, the LED will flash fully. If it fails, it will flash quickly.*/
    flag = BKP_DATA();

    if(flag == 0) {
        while(1) {
            LED1_TOGGLE();
            LED3_TOGGLE();
            LED4_TOGGLE();
            /*BKP dataRead and write success, slow flash*/
            delay_ms(5000);
        }
    }
    else {
        while(1) {
            LED1_TOGGLE();
            LED3_TOGGLE();
            LED4_TOGGLE();
            /*BKP dataRead and write failed, flashing*/
            delay_ms(500);
        }
    }
}


/********************************************************************************************************
**Function information :void delay_init(void)
**Function description : initialization delay function
**Input parameters :
**Output parameters :
**Common functions :
********************************************************************************************************/
void delay_init(void)
{

    SysTick_CLKSourceConfig(SysTick_CLKSource_HCLK_Div8);

    fac_us = SystemCoreClock / 8000000;

    fac_ms = (u16)fac_us * 1000;
}
/********************************************************************************************************
**Function information :LED_Init(void)
**Function description :LED initialization
**Input parameters :none
**Output parameters :none
********************************************************************************************************/
void LED_Init(void)
{
    GPIO_InitTypeDef  GPIO_InitStructure;

    RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOA | RCC_AHB1Periph_GPIOB, ENABLE);

    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_15;
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
    GPIO_Init(GPIOA, &GPIO_InitStructure);

    GPIO_InitStructure.GPIO_Pin  = GPIO_Pin_4 | GPIO_Pin_5;
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
    GPIO_Init(GPIOB, &GPIO_InitStructure);
    LED1_OFF();
    LED3_OFF();
    LED4_OFF();
}

/********************************************************************************************************
**Function information :void delay_ms(u16 nms)
**Function description :delay nms
**Input parameters :nms
**Output parameters :
**    Remark :SysTick->LOAD 24 bit register,and so,maximum delay  :nms<=0xffffff*8*1000/SYSCLK,At 72 MHz,nms<=1864
********************************************************************************************************/
void delay_ms(u16 nms)
{
    u32 temp;

    SysTick->LOAD = (u32)nms * fac_ms;

    SysTick->VAL = 0x00;

    SysTick->CTRL |= SysTick_CTRL_ENABLE_Msk ;
    do {
        temp = SysTick->CTRL;
    }

    while((temp & 0x01) && !(temp & (1 << 16)));

    SysTick->CTRL &= ~SysTick_CTRL_ENABLE_Msk;

    SysTick->VAL = 0X00;
}


/********************************************************************************************************
**Function information :BKP_DATA(void)
**Function description : BKP data read and write  test ,Determine whether the data written and read are consistent
**Input parameters :FirstBackupData
**Output parameters :i
********************************************************************************************************/
u8 BKP_DATA(void)
{
    u8 i;
    /* Enable PWR and BKP clock */
    RCC_APB1PeriphClockCmd(RCC_APB1Periph_PWR | RCC_APB1Periph_BKP, ENABLE);

    /* Enable write access to Backup domain */
    PWR_BackupAccessCmd(ENABLE);

    /* Clear Tamper pin Event(TE) pending flag */
    BKP_ClearFlag();

    WriteToBackupReg(0x55);

    i = CheckBackupReg(0x55);
    return i;
}


/********************************************************************************************************
**Function information :WriteToBackupReg(u16 FirstBackupData)
**Function description : Write data to BKP data register
**Input parameters :FirstBackupData
**Output parameters :none
********************************************************************************************************/
void WriteToBackupReg(u16 FirstBackupData)
{
    uint32_t index = 0;

    for (index = 0; index < 10; index++) {

        BKP_WriteBackupRegister(BKPDataReg[index], testdata[index]);
    }
}


/********************************************************************************************************
**Function information :CheckBackupReg(u16 FirstBackupData)
**Function description : Determine whether the data is written correctly
**Input parameters :FirstBackupData
**Output parameters :Write error:index+1��Write success :0
********************************************************************************************************/
u8 CheckBackupReg(u16 FirstBackupData)
{
    u32 index = 0;

    for (index = 0; index < 10; index++) {
        if (BKP_ReadBackupRegister(BKPDataReg[index]) != testdata[index]) {
            return (index + 1);
        }
    }

    return 0;
}
