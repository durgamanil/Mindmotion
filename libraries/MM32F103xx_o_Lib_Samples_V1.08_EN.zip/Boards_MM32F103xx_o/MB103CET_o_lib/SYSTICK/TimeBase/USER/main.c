#include "HAL_conf.h"
#include "HAL_device.h"
#include "stdio.h"

void delay_init(void);
void delay_ms(u16 nms);
void LED_Init(void);


static u8  fac_us = 0;

static u16 fac_ms = 0;

#define LED4_ON()  GPIO_ResetBits(GPIOB,GPIO_Pin_5)
#define LED4_OFF()  GPIO_SetBits(GPIOB,GPIO_Pin_5)
#define LED4_TOGGLE()  (GPIO_ReadOutputDataBit(GPIOB,GPIO_Pin_5))?(GPIO_ResetBits(GPIOB,GPIO_Pin_5)):(GPIO_SetBits(GPIOB,GPIO_Pin_5))

#define LED3_ON()  GPIO_ResetBits(GPIOB,GPIO_Pin_4)
#define LED3_OFF()  GPIO_SetBits(GPIOB,GPIO_Pin_4)
#define LED3_TOGGLE()  (GPIO_ReadOutputDataBit(GPIOB,GPIO_Pin_4))?(GPIO_ResetBits(GPIOB,GPIO_Pin_4)):(GPIO_SetBits(GPIOB,GPIO_Pin_4))

#define LED1_ON()  GPIO_ResetBits(GPIOA,GPIO_Pin_15)
#define LED1_OFF()  GPIO_SetBits(GPIOA,GPIO_Pin_15)
#define LED1_TOGGLE()  (GPIO_ReadOutputDataBit(GPIOA,GPIO_Pin_15))?(GPIO_ResetBits(GPIOA,GPIO_Pin_15)):(GPIO_SetBits(GPIOA,GPIO_Pin_15))

/********************************************************************************************************
**Function information :int main (void)
**Function description :After booting,LED 2s
**Input parameters :
**Output parameters :
********************************************************************************************************/

int main(void)
{
    /*delay  function  initialization*/
    delay_init();
    /* test GPIO*/
    LED_Init();

    while(1) {
        LED1_TOGGLE();
        LED3_TOGGLE();
        LED4_TOGGLE();
        delay_ms(1000);
    }
}

/********************************************************************************************************
**Function information :LED_Init(void)
**Function description :LED initialization
**Input parameters :none
**Output parameters :none
********************************************************************************************************/
void LED_Init(void)
{
    GPIO_InitTypeDef  GPIO_InitStructure;

    RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOA | RCC_AHB1Periph_GPIOB, ENABLE);

    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_15;
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
    GPIO_Init(GPIOA, &GPIO_InitStructure);

    GPIO_InitStructure.GPIO_Pin  = GPIO_Pin_3 | GPIO_Pin_4 | GPIO_Pin_5;
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
    GPIO_Init(GPIOB, &GPIO_InitStructure);
    LED1_OFF();
    LED3_OFF();
    LED4_OFF();
}

/********************************************************************************************************
**Function information :void delay_init(void)
**Function description : initialization delay function
**Input parameters :
**Output parameters :
**Common functions :
********************************************************************************************************/
void delay_init(void)
{

    SysTick_CLKSourceConfig(SysTick_CLKSource_HCLK_Div8);

    fac_us = SystemCoreClock / 8000000;

    fac_ms = (u16)fac_us * 1000;
}


/********************************************************************************************************
**Function information :void delay_ms(u16 nms)
**Function description :delay nms
**Input parameters :nms
**Output parameters :
**    Remark :SysTick->LOAD 24 bit register,and so,maximum delay  :nms<=0xffffff*8*1000/SYSCLK,At 72 MHz,nms<=1864
********************************************************************************************************/
void delay_ms(u16 nms)
{
    u32 temp;

    SysTick->LOAD = (u32)nms * fac_ms;

    SysTick->VAL = 0x00;

    SysTick->CTRL |= SysTick_CTRL_ENABLE_Msk ;
    do {
        temp = SysTick->CTRL;
    }

    while((temp & 0x01) && !(temp & (1 << 16)));

    SysTick->CTRL &= ~SysTick_CTRL_ENABLE_Msk;

    SysTick->VAL = 0X00;
}

