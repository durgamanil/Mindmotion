#include "HAL_conf.h"
#include "HAL_device.h"
#include "stdio.h"

u32 TEXT_TO_SEND[] = {'1', '2', '3', '4', '5', '6', '7', '8', '9'};
#define TEXT_LENTH 9
u8 SendBuff[(TEXT_LENTH + 2) * 100];

u16 DMA1_MEM_LEN;
char printBuf[100];

void uart_initwBaudRate(u32 bound);
void MYDMA_Config(DMA_Channel_TypeDef* DMA_CHx, u32 cpar, u32 cmar, u16 cndtr);
void MYDMA_Enable(DMA_Channel_TypeDef*DMA_CHx);
void UartSendGroup(u8* buf, u16 len);

/********************************************************************************************************
**Function information :int main (void)
**Function description :After booting, UART print  data(MM32link-option open  UART )
**Input parameters :
**Output parameters :
********************************************************************************************************/
int main(void)
{
    u16 i;
    u8 t = 0;

    /* UART  initialization 9600*/
    uart_initwBaudRate(9600);

    MYDMA_Config(DMA1_Channel4, (u32)&UART1->TDR, (u32)SendBuff, (TEXT_LENTH + 2) * 10);
    UartSendGroup((u8*)printBuf, sprintf(printBuf, "\r\nDMA DATA:\r\n"));

    for(i = 0; i < (TEXT_LENTH + 2) * 100; i++) {

        if(t >= TEXT_LENTH) {
            SendBuff[i++] = 0x0d;
            SendBuff[i] = 0x0a;
            t = 0;
        }

        else SendBuff[i] = TEXT_TO_SEND[t++];
    }

    /*enable uart1 DMA*/
    UART_DMACmd(UART1, UART_DMAReq_EN, ENABLE);

    MYDMA_Enable(DMA1_Channel4);


    while(1) {

        if(DMA_GetFlagStatus(DMA1_FLAG_TC4) != RESET) {

            DMA_ClearFlag(DMA1_FLAG_TC4);
            break;
        }
    }

    UartSendGroup((u8*)printBuf, sprintf(printBuf, "\r\nUART DMA TEST OK!\r\n"));

    while(1);
}

/********************************************************************************************************
**Function information :void uart_initwBaudRate(u32 bound)
**Function description :UART initialization
**Input parameters :bound
**Output parameters :
**    Remark :
********************************************************************************************************/
void uart_initwBaudRate(u32 bound)
{

    GPIO_InitTypeDef GPIO_InitStructure;
    UART_InitTypeDef UART_InitStructure;

    RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOA, ENABLE);

    /*UART1_TX   GPIOA.9*/
    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_9;
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;

    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP;
    GPIO_Init(GPIOA, &GPIO_InitStructure);
    GPIO_PinAFConfig(GPIOA, GPIO_PinSource9, GPIO_AF_7);

    /*UART1_RX  GPIOA.10 initialization*/
    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_10;
    /*Floating input*/
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IN_FLOATING;
    GPIO_Init(GPIOA, &GPIO_InitStructure);
    GPIO_PinAFConfig(GPIOA, GPIO_PinSource10, GPIO_AF_7);

    /*UART  initialization configure */
    RCC_APB2PeriphClockCmd(RCC_APB2Periph_UART1, ENABLE);


    UART_InitStructure.UART_BaudRate = bound;

    UART_InitStructure.UART_WordLength = UART_WordLength_8b;

    UART_InitStructure.UART_StopBits = UART_StopBits_1;

    UART_InitStructure.UART_Parity = UART_Parity_No;

    UART_InitStructure.UART_HardwareFlowControl = UART_HardwareFlowControl_None;

    UART_InitStructure.UART_Mode = UART_Mode_Rx | UART_Mode_Tx;
    /* initialization UART 1*/
    UART_Init(UART1, &UART_InitStructure);

    UART_ITConfig(UART1, UART_IT_RXIEN, ENABLE);
    /*enable  UART 1*/
    UART_Cmd(UART1, ENABLE);
}

/********************************************************************************************************
**Function information :MYDMA_Config(DMA_Channel_TypeDef* DMA_CHx,u32 cpar,u32 cmar,u16 cndtr)
**Function description :DMA configure can be modified according to Input parameters
**Input parameters :none
**Output parameters :none
********************************************************************************************************/
void MYDMA_Config(DMA_Channel_TypeDef* DMA_CHx, u32 cpar, u32 cmar, u16 cndtr)
{
    DMA_InitTypeDef DMA_InitStructure;
    RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_DMA1, ENABLE);


    DMA_DeInit(DMA_CHx);
    DMA1_MEM_LEN = cndtr;

    DMA_InitStructure.DMA_PeripheralBaseAddr = cpar;

    DMA_InitStructure.DMA_MemoryBaseAddr = cmar;

    DMA_InitStructure.DMA_DIR = DMA_DIR_PeripheralDST;

    DMA_InitStructure.DMA_BufferSize = cndtr;

    DMA_InitStructure.DMA_PeripheralInc = DMA_PeripheralInc_Disable;

    DMA_InitStructure.DMA_MemoryInc = DMA_MemoryInc_Enable;

    DMA_InitStructure.DMA_PeripheralDataSize = DMA_PeripheralDataSize_Byte;

    DMA_InitStructure.DMA_MemoryDataSize = DMA_MemoryDataSize_Byte;

    DMA_InitStructure.DMA_Mode = DMA_Mode_Normal;

    DMA_InitStructure.DMA_Priority = DMA_Priority_Medium;

    DMA_InitStructure.DMA_M2M = DMA_M2M_Disable;

    DMA_Init(DMA_CHx, &DMA_InitStructure);

}

/********************************************************************************************************
**Function information :MYDMA_Enable(DMA_Channel_TypeDef*DMA_CHx)
**Function description :Start a DMA transfer
**Input parameters :none
**Output parameters :none
********************************************************************************************************/
void MYDMA_Enable(DMA_Channel_TypeDef*DMA_CHx)
{

    DMA_Cmd(DMA_CHx, DISABLE );

    DMA_Cmd(DMA_CHx, ENABLE);
}

/********************************************************************************************************
**Function information :void UartSendByte(u8 dat)
**Function description :UART send  data
**Input parameters :dat
**Output parameters :
**    Remark :
********************************************************************************************************/
void UartSendByte(u8 dat)
{
    UART_SendData( UART1, dat);
    while(!UART_GetFlagStatus(UART1, UART_FLAG_TXEPT));
}


/********************************************************************************************************
**Function information :void UartSendGroup(u8* buf,u16 len)
**Function description :UART send  data
**Input parameters :buf,len
**Output parameters :
**    Remark :
********************************************************************************************************/
void UartSendGroup(u8* buf, u16 len)
{
    while(len--)
        UartSendByte(*buf++);
}
