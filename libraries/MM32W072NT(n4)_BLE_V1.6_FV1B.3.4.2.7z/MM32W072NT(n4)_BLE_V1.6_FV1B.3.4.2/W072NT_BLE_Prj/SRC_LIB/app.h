#ifndef _MG_APP_H_
#define _MG_APP_H_
//#define u8 unsigned char
//#define u16 unsigned short
#endif
