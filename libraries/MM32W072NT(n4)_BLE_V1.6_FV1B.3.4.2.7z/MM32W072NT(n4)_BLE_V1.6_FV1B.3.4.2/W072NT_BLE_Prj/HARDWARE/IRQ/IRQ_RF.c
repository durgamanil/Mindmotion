#include "irq_rf.h"
#include "mg_api.h"

unsigned char pld_adv[] = {
	0x02,  0x01,0x06,
	0x09,  0xFF,0x00,0x00,0x80,0x00,0x00,0x00,0xA7,0xF9,
	0x05,  0x03,0xE7,0xFE,0xE0,0xFE,
	0x06,  0x09,0x4C,0x53,0x4C,0x45,0x44,
};

/********************************************************************************************************
**������Ϣ ��LED_Init(void)                        
**�������� ��LED��ʼ��
**������� ����
**������� ����
********************************************************************************************************/

void IRQ_RF(void)
{

	GPIO_InitTypeDef        GPIO_InitStructure;
	NVIC_InitTypeDef  NVIC_InitStructure;
	EXTI_InitTypeDef  EXTI_InitStructure;
	
	RCC_AHBPeriphClockCmd(RCC_AHBPeriph_GPIOB, ENABLE);
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_SYSCFG, ENABLE);
	RCC_APB1PeriphClockCmd(RCC_APB1Periph_PWR, ENABLE);
	//IRQ - pb8
	GPIO_InitStructure.GPIO_Pin  = GPIO_Pin_8;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_2MHz;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IPU; //��������   
	GPIO_Init(GPIOB, &GPIO_InitStructure);
	
	SYSCFG_EXTILineConfig(GPIO_PortSourceGPIOB, GPIO_PinSource8);

	EXTI_InitStructure.EXTI_Line = EXTI_Line8;
	EXTI_InitStructure.EXTI_Mode = EXTI_Mode_Interrupt;
	EXTI_InitStructure.EXTI_Trigger = EXTI_Trigger_Falling;
	EXTI_InitStructure.EXTI_LineCmd = ENABLE;
	EXTI_Init(&EXTI_InitStructure);
	
	NVIC_InitStructure.NVIC_IRQChannel = EXTI4_15_IRQn;
	NVIC_InitStructure.NVIC_IRQChannelPriority = 0;
	NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
	NVIC_Init(&NVIC_InitStructure);
	
	PWR->CR = PWR->CR & 0xfffd; //PDDS = 0;enter stop mode
	SCB->SCR |= 0x4;
	
}

char IsIrqEnabled(void) //porting api
{
    return (!(GPIO_ReadInputData(GPIOB) & 0x100));
}

void EXTI4_15_IRQHandler(void)
{
	EXTI_ClearITPendingBit(EXTI_Line8); 
}


static void Write_Buf(unsigned char Addr,__int64 Data)
{
	__int64 temp=Data;
	mg_writeBuf(Addr,(unsigned char *)(&temp),8);
}


void BLEON()
{
	mg_writeReg(0x00,0x01); //add
	mg_activate(0x53);

	Write_Buf(0x01,0x00100c0a02);
	Write_Buf(0x02,0x0000010a30);
	Write_Buf(0x04,0x00002d12c0); //txgain(1)
	Write_Buf(0x05,0x0000096e5a); 
	Write_Buf(0x06,0x000005012c);
	Write_Buf(0x0b,0x0040217080); //0x0040214080
	Write_Buf(0x0c,0x0000040080); 
	Write_Buf(0x0d,0x0000001202); 
	Write_Buf(0x0f,0x0000244302);
	Write_Buf(0x11,0x000a080e24); 
	Write_Buf(0x13,0x0000002281); 
	Write_Buf(0x14,0x000000c01c); 
	Write_Buf(0x16,0x000000008e);
	Write_Buf(0x1a,0x0000000048);
	Write_Buf(0x1b,0x000000004e); //
	mg_writeReg(0x1c,0x30);
	Write_Buf(0x1e,0x30); 

	mg_activate(0x56);

	ble_set_adv_data(pld_adv,sizeof(pld_adv));
	//	test_carrier(80,TXPWR_0DBM);
	//	while(1);
	ble_run_interrupt_start(160*2); //320*0.625=200 ms
}


