/******************** (C) COPYRIGHT 2018 MindMotion ********************
* File Name          : usb_endp.c
* Version            : V1.0.0
* Date               : 2018/08/21
* Description        : Endpoint routines
********************************************************************************
* THE PRESENT FIRMWARE WHICH IS FOR GUIDANCE ONLY AIMS AT PROVIDING CUSTOMERS
* WITH CODING INFORMATION REGARDING THEIR PRODUCTS IN ORDER FOR THEM TO SAVE TIME.
* AS A RESULT, MindMotion SHALL NOT BE HELD LIABLE FOR ANY DIRECT,
* INDIRECT OR CONSEQUENTIAL DAMAGES WITH RESPECT TO ANY CLAIMS ARISING FROM THE
* CONTENT OF SUCH FIRMWARE AND/OR THE USE MADE BY CUSTOMERS OF THE CODING
* INFORMATION CONTAINED HEREIN IN CONNECTION WITH THEIR PRODUCTS.
*******************************************************************************/

/* Includes ------------------------------------------------------------------*/
#include "platform_config.h"
#include "HAL_device.h"
#include "usb_lib.h"
#include "usb_istr.h"

/* Private typedef -----------------------------------------------------------*/
/* Private define ------------------------------------------------------------*/
/* Private macro -------------------------------------------------------------*/
/* Private variables ---------------------------------------------------------*/
uint8_t Receive_Buffer[2];
extern __IO uint8_t PrevXferComplete;
/* Private function prototypes -----------------------------------------------*/
/* Private functions ---------------------------------------------------------*/
/*******************************************************************************
* Function Name  : EP1_OUT_Callback.
* Description    : EP1 OUT Callback Routine.
* Input          : None.
* Output         : None.
* Return         : None.
*******************************************************************************/
void EP1_OUT_Callback(void)
{
    uint8_t Led_State;
    
    PMAToUserBufferCopy(Receive_Buffer, ENDP1, 2);
    
    if (Receive_Buffer[1] == 0){
        Led_State = 0;        
    }
    else {
        Led_State = 1;        
    }
    switch (Receive_Buffer[0]){
    case 1: 
        if (Led_State != 0){
            GPIO_ResetBits(GPIOA, GPIO_Pin_8);        
        }
        else{
            GPIO_SetBits(GPIOA, GPIO_Pin_8);        
        }
        break;
    case 2: 
        if (Led_State != 0){
            GPIO_ResetBits(GPIOA, GPIO_Pin_8);        
        }
        else{
            GPIO_SetBits(GPIOA, GPIO_Pin_8);        
        }
        break;
    default:
        break;
    }
}

/*******************************************************************************
* Function Name  : EP1_IN_Callback.
* Description    : EP1 IN Callback Routine.
* Input          : None.
* Output         : None.
* Return         : None.
*******************************************************************************/
void EP1_IN_Callback(void)
{
  PrevXferComplete = 1;
}

/******************* (C) COPYRIGHT 2018 MindMotion *****END OF FILE****/

