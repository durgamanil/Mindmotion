/******************** (C) COPYRIGHT 2018 MindMotion ********************
* File Name          : hw_config.c
* Version            : V1.0.0
* Date               : 2018/08/21
* Description        : Hardware Configuration & Setup
********************************************************************************
* THE PRESENT FIRMWARE WHICH IS FOR GUIDANCE ONLY AIMS AT PROVIDING CUSTOMERS
* WITH CODING INFORMATION REGARDING THEIR PRODUCTS IN ORDER FOR THEM TO SAVE TIME.
* AS A RESULT, MindMotion SHALL NOT BE HELD LIABLE FOR ANY DIRECT,
* INDIRECT OR CONSEQUENTIAL DAMAGES WITH RESPECT TO ANY CLAIMS ARISING FROM THE
* CONTENT OF SUCH FIRMWARE AND/OR THE USE MADE BY CUSTOMERS OF THE CODING
* INFORMATION CONTAINED HEREIN IN CONNECTION WITH THEIR PRODUCTS.
*******************************************************************************/

/* Includes ------------------------------------------------------------------*/
#include "MM32F103xx_o_it.h"
#include "usb_lib.h"
#include "usb_prop.h"
#include "usb_desc.h"
#include "hw_config.h"
#include "platform_config.h"
#include "usb_pwr.h"

/* Private typedef -----------------------------------------------------------*/
/* Private define ------------------------------------------------------------*/
/* Private macro -------------------------------------------------------------*/
/* Private variables ---------------------------------------------------------*/

/* Extern variables ----------------------------------------------------------*/
extern uint8_t buffer_in[VIRTUAL_COM_PORT_DATA_SIZE];
extern uint32_t count_in;
extern LINE_CODING linecoding;

/* Private function prototypes -----------------------------------------------*/
/* Private functions ---------------------------------------------------------*/
/*******************************************************************************
* Function Name  : Set_System
* Description    : Configures Main system clocks & power
* Input          : None.
* Return         : None.
*******************************************************************************/
void Set_System(void)
{
    GPIO_InitTypeDef GPIO_InitStructure;
//    UART_InitTypeDef UART_InitStructure;  

    /* Setup the microcontroller system. Initialize the Embedded Flash Interface,  
       initialize the PLL and update the SystemFrequency variable. */
//    SystemInit();

    /* Enable GPIOA, GPIOD and UART1 clock */
    RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOA|RCC_AHB1Periph_GPIOB|RCC_AHB1Periph_GPIOC|RCC_AHB1Periph_GPIOD, ENABLE);   
    
    RCC_APB2PeriphClockCmd(RCC_APB2Periph_UART1, ENABLE);
    
    RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOB, ENABLE); 
    /*uart1_tx  pa9 PB6*/
    GPIO_InitStructure.GPIO_Pin  = GPIO_Pin_6;   			                
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_2MHz;      
    /*�����������*/        
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP; 		                
    GPIO_Init(GPIOB, &GPIO_InitStructure);                                  
    GPIO_PinAFConfig(GPIOB, GPIO_PinSource6, GPIO_AF_7);                    
    
    /*uart1_rx  pa10 PB7*/        
    GPIO_InitStructure.GPIO_Pin  = GPIO_Pin_7;  			                
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_2MHz;  
    /*��������*/        
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IPU;			                   
    GPIO_Init(GPIOB, &GPIO_InitStructure);  
    GPIO_PinAFConfig(GPIOB, GPIO_PinSource7, GPIO_AF_7);
    

    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_0|GPIO_Pin_1|GPIO_Pin_2;
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
    GPIO_Init(GPIOC, &GPIO_InitStructure);
    
    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_8;
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
    GPIO_Init(GPIOA, &GPIO_InitStructure);
    
    GPIO_SetBits(GPIOA, GPIO_Pin_8);
    
}

/*******************************************************************************
* Function Name  : Set_USBClock
* Description    : Configures USB Clock input (48MHz)
* Input          : None.
* Return         : None.
*******************************************************************************/
void Set_USBClock(void)
{
  /* Select USBCLK source */
//  RCC_USBCLKConfig(RCC_USBCLKSource_PLLCLK_Div1);
  RCC->CFGR &= ~(0x3<<22);
  RCC->CFGR |= (0x0<<22);

  /* Enable USB clock */
  RCC->AHB2ENR |= 0x1<<7;
}

/*******************************************************************************
* Function Name  : Enter_LowPowerMode
* Description    : Power-off system clocks and power while entering suspend mode
* Input          : None.
* Return         : None.
*******************************************************************************/
void Enter_LowPowerMode(void)
{
  /* Set the device state to suspend */
  bDeviceState = SUSPENDED;
}

/*******************************************************************************
* Function Name  : Leave_LowPowerMode
* Description    : Restores system clocks and power while exiting suspend mode
* Input          : None.
* Return         : None.
*******************************************************************************/
void Leave_LowPowerMode(void)
{
  DEVICE_INFO *pInfo = &Device_Info;

  /* Set the device state to the correct state */
  if (pInfo->Current_Configuration != 0)
  {
    /* Device configured */
    bDeviceState = CONFIGURED;
  }
  else
  {
    bDeviceState = ATTACHED;
  }
}

/*******************************************************************************
* Function Name  : USB_Interrupts_Config
* Description    : Configures the USB interrupts
* Input          : None.
* Return         : None.
*******************************************************************************/
void USB_Interrupts_Config(void)
{
    NVIC_InitTypeDef NVIC_InitStructure;
    
    /* 2 bit for pre-emption priority, 2 bits for subpriority */
    NVIC_PriorityGroupConfig(NVIC_PriorityGroup_2);
    
    NVIC_InitStructure.NVIC_IRQChannel = USB_OTG_FS_IRQn;
    NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 0;
    NVIC_InitStructure.NVIC_IRQChannelSubPriority = 0;
    NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
    NVIC_Init(&NVIC_InitStructure);
    
    /* Enable UART1 Interrupt */
    NVIC_InitStructure.NVIC_IRQChannel = UART1_IRQn;
    NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 0;
    NVIC_Init(&NVIC_InitStructure);
    
    NVIC_InitStructure.NVIC_IRQChannel = DMA1_Channel4_IRQn;
    NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 0;
    NVIC_Init(&NVIC_InitStructure);
}

/*******************************************************************************
* Function Name  : USB_Cable_Config
* Description    : Software Connection/Disconnection of USB Cable
* Input          : None.
* Return         : Status
*******************************************************************************/
void USB_Cable_Config (FunctionalState NewState)
{
  if (NewState != DISABLE)
  {
    _SetUSB_Connect;
  }
  else
  {
    _SetUSB_Disconnect;
  }
}

///*******************************************************************************
//* Function Name  :  UART_Config_Default.
//* Description    :  configure the UART1 with default values.
//* Input          :  None.
//* Return         :  None.
//*******************************************************************************/
//void UART_Config_Default(void)
//{    
//  /* UART1 default configuration */
//  /* UART1 configured as follow:
//        - BaudRate = 9600 baud  
//        - Word Length = 8 Bits
//        - One Stop Bit
//        - Parity Odd
//        - Hardware flow control desabled
//        - Receive and transmit enabled
//  */
//  UART_InitStructure.UART_BaudRate = 9600;
//  UART_InitStructure.UART_WordLength = UART_WordLength_8b;
//  UART_InitStructure.UART_StopBits = UART_StopBits_1;
//  UART_InitStructure.UART_Parity = UART_Parity_Odd;
//  UART_InitStructure.UART_HardwareFlowControl = UART_HardwareFlowControl_None;
//  UART_InitStructure.UART_Mode = UART_Mode_Rx | UART_Mode_Tx;
//
//  /* Configure the UART1 */
//  UART_Init(UART1, &UART_InitStructure);
//  UART_Cmd(UART1, ENABLE);
//  /* Enable the UART Receive interrupt */
//  UART_ITConfig(UART1, UART_IT_RXIEN, ENABLE);
//}






extern uint8_t status_UsbUart;
/*******************************************************************************
* Function Name  : USB_To_UART_Send_Data.
* Description    : send the received data from USB to the UART 0.
* Input          : data_buffer: data address.
                   Nb_bytes: number of bytes to send.
* Return         : none.
*******************************************************************************/
//void USB_To_UART_Send_Data(uint8_t* data_buffer, uint8_t* Nb_bytes)
//{
//  uint32_t i;                       
//  if((status_UsbUart>>1)&0x01)
//  {
//      status_UsbUart |= 1<< 4;      //UART���ڷ���
//      for (i = 0; i < *Nb_bytes; i++)
//      {
//        UART_SendData(UART1, *(data_buffer + i));
//        while(UART_GetFlagStatus(UART1,UART_FLAG_TXEMPTY) == RESET); 
//      }
//      *Nb_bytes = 0;
//      status_UsbUart &= ~(1<< 4);   //UART�������
//      status_UsbUart &= ~(1<< 1);   
//  }
//}



/*******************************************************************************
* Function Name  : Get_SerialNum.
* Description    : Create the serial number string descriptor.
* Input          : None.
* Output         : None.
* Return         : None.
*******************************************************************************/
void Get_SerialNum(void)
{
  uint32_t Device_Serial0, Device_Serial1, Device_Serial2;

  Device_Serial0 = *(__IO uint32_t*)(0x1FFFF7E8);
  Device_Serial1 = *(__IO uint32_t*)(0x1FFFF7EC);
  Device_Serial2 = *(__IO uint32_t*)(0x1FFFF7F0);

  if (Device_Serial0 != 0)
  {
    Virtual_Com_Port_StringSerial[2] = (uint8_t)(Device_Serial0 & 0x000000FF);
    Virtual_Com_Port_StringSerial[4] = (uint8_t)((Device_Serial0 & 0x0000FF00) >> 8);
    Virtual_Com_Port_StringSerial[6] = (uint8_t)((Device_Serial0 & 0x00FF0000) >> 16);
    Virtual_Com_Port_StringSerial[8] = (uint8_t)((Device_Serial0 & 0xFF000000) >> 24);

    Virtual_Com_Port_StringSerial[10] = (uint8_t)(Device_Serial1 & 0x000000FF);
    Virtual_Com_Port_StringSerial[12] = (uint8_t)((Device_Serial1 & 0x0000FF00) >> 8);
    Virtual_Com_Port_StringSerial[14] = (uint8_t)((Device_Serial1 & 0x00FF0000) >> 16);
    Virtual_Com_Port_StringSerial[16] = (uint8_t)((Device_Serial1 & 0xFF000000) >> 24);

    Virtual_Com_Port_StringSerial[18] = (uint8_t)(Device_Serial2 & 0x000000FF);
    Virtual_Com_Port_StringSerial[20] = (uint8_t)((Device_Serial2 & 0x0000FF00) >> 8);
    Virtual_Com_Port_StringSerial[22] = (uint8_t)((Device_Serial2 & 0x00FF0000) >> 16);
    Virtual_Com_Port_StringSerial[24] = (uint8_t)((Device_Serial2 & 0xFF000000) >> 24);
  }
}

/******************* (C) COPYRIGHT 2018 MindMotion *****END OF FILE****/
