/* Includes ------------------------------------------------------------------*/
#include <string.h>
#include "usb_lib.h"
#include "usb_prop.h"
#include "usb_desc.h"

void VCP_SendRxBufPacketToUsb(void);

/* Private typedef -----------------------------------------------------------*/
/* Private define ------------------------------------------------------------*/
#define UART_RX_DATA_SIZE   512

/* Private macro -------------------------------------------------------------*/
/* Private variables ---------------------------------------------------------*/
UART_InitTypeDef UART_InitStructure;
extern DMA_InitTypeDef  DMA_InitStructure;

uint8_t  UART_Rx_Buffer[UART_RX_DATA_SIZE]; 
uint32_t UART_Rx_ptr_in ;
uint32_t UART_Rx_ptr_out ;
uint32_t UART_Rx_length ;
uint8_t  USB_Tx_State ;
uint16_t USB_Tx_length;
uint16_t USB_Tx_ptr;

/* Extern variables ----------------------------------------------------------*/
extern LINE_CODING linecoding;

/* Private function prototypes -----------------------------------------------*/
/* Private functions ---------------------------------------------------------*/


/*******************************************************************************
* Function Name  : VCP_Data_InISR.
* Description    : EPxIN USB transfer complete ISR. Send pending data if any.
* Input          : None.
* Return         : none.
*******************************************************************************/
void VCP_Data_InISR(void)
{
  VCP_SendRxBufPacketToUsb();
}

/*******************************************************************************
* Function Name  :  UART_Config_Default.
* Description    :  configure the UART1 with default values.
* Input          :  None.
* Return         :  None.
*******************************************************************************/
void UART_Config_Default(void)
{    
  /* UART1 default configuration */
  /* UART1 configured as follow:
        - BaudRate = 9600 baud  
        - Word Length = 8 Bits
        - One Stop Bit
        - Parity Odd
        - Hardware flow control desabled
        - Receive and transmit enabled
  */
  UART_InitStructure.UART_BaudRate = 9600;
  UART_InitStructure.UART_WordLength = UART_WordLength_8b;
  UART_InitStructure.UART_StopBits = UART_StopBits_1;
  UART_InitStructure.UART_Parity = UART_Parity_Odd;
  UART_InitStructure.UART_HardwareFlowControl = UART_HardwareFlowControl_None;
  UART_InitStructure.UART_Mode = UART_Mode_Rx | UART_Mode_Tx;

  /* Configure the UART1 */
  UART_Init(UART1, &UART_InitStructure);
  UART_Cmd(UART1, ENABLE);
  /* Enable the UART Receive interrupt */
  UART_ITConfig(UART1, UART_IT_RXIEN, ENABLE);
}


/*******************************************************************************
* Function Name  :  UART_Config.
* Description    :  Configure the UART 1 according to the linecoding structure.
* Input          :  None.
* Return         :  Configuration status
                    TRUE : configuration done with success
                    FALSE : configuration aborted.
*******************************************************************************/
bool UART_Config(void)
{
  /* set the Stop bit*/
  switch (linecoding.format)
  {
    case 0:
      UART_InitStructure.UART_StopBits = UART_StopBits_1;
      break;
    case 1:
      UART_InitStructure.UART_StopBits = UART_StopBits_1;//1.5old
      break;
    case 2:
      UART_InitStructure.UART_StopBits = UART_StopBits_2;
      break;
    default :
    {
      UART_Config_Default();
      return (FALSE);
    }
  }

  /* set the parity bit*/
  switch (linecoding.paritytype)
  {
    case 0:
      UART_InitStructure.UART_Parity = UART_Parity_No;
      break;
    case 1:
      UART_InitStructure.UART_Parity = UART_Parity_Even;
      break;
    case 2:
      UART_InitStructure.UART_Parity = UART_Parity_Odd;
      break;
    default :
    {
      UART_Config_Default();
      return (FALSE);
    }
  }

  switch (linecoding.datatype)
  {
    case 0x07:
      /* With this configuration a parity (Even or Odd) should be set */
      UART_InitStructure.UART_WordLength = UART_WordLength_8b;
      break;
    case 0x08:
      if (UART_InitStructure.UART_Parity == UART_Parity_No)
      {
        UART_InitStructure.UART_WordLength = UART_WordLength_8b;
      }
      else 
      {
        UART_InitStructure.UART_WordLength = UART_WordLength_6b;//
      }
      
      break;
    default :
    {
      UART_Config_Default();
      return (FALSE);
    }
  }

  UART_InitStructure.UART_BaudRate = linecoding.bitrate;
  UART_InitStructure.UART_HardwareFlowControl = UART_HardwareFlowControl_None;
  UART_InitStructure.UART_Mode = UART_Mode_Rx | UART_Mode_Tx;
  UART_Init(UART1, &UART_InitStructure);
  UART_Cmd(UART1, ENABLE);
  /* Enable the UART Receive interrupt */
  UART_ITConfig(UART1, UART_IT_RXIEN, ENABLE);
  return (TRUE);
}


/*******************************************************************************
* Function Name  : USB_To_USART_Send_Data.
* Description    : send the received data from USB to the UART 0.
* Input          : data_buffer: data address.
                   Nb_bytes: number of bytes to send.
* Return         : none.
*******************************************************************************/
void USB_To_UART_Send_Data(uint8_t* data_buffer, uint8_t Nb_bytes)
{
  uint32_t i;
  
  for (i = 0; i < Nb_bytes; i++){
      UART_SendData(UART1, *(data_buffer + i));
      while(!UART_GetFlagStatus(UART1,UART_FLAG_TXEPT));
  }
}


/*******************************************************************************
* Function Name  : VCP_SendRxBufPacketToUsb.
* Description    : send data from USART_Rx_Buffer to the USB. Manage the segmentation
*                  into USB FIFO buffer. Commit one packet to the USB at each call.
* Input          : globals:
*                  - USB_Tx_State: transmit state variable
*                  - USART_Rx_Buffer: buffer of data to be sent
*                  - USART_Rx_length: amount of data (in bytes) ready to be sent
*                  - USART_Rx_ptr_out: index in USART_Rx_Buffer of the first data
*                    to send
* Return         : none.
*******************************************************************************/
void VCP_SendRxBufPacketToUsb(void) 
{
//  uint16_t USB_Tx_ptr;
//  uint16_t USB_Tx_length;
  
//  if (USB_Tx_State == 1)
//  {
//    if (UART_Rx_length == 0) 
//    {
      USB_Tx_State = 0;
//    }
//    else 
//    {
//      if (UART_Rx_length > VIRTUAL_COM_PORT_DATA_SIZE){
//        USB_Tx_ptr = UART_Rx_ptr_out;
//        USB_Tx_length = VIRTUAL_COM_PORT_DATA_SIZE;
//        
//        UART_Rx_ptr_out += VIRTUAL_COM_PORT_DATA_SIZE;
//        UART_Rx_length -= VIRTUAL_COM_PORT_DATA_SIZE;    
//      }
//      else 
//      {
//        USB_Tx_ptr = UART_Rx_ptr_out;
//        USB_Tx_length = UART_Rx_length;
//        
//        UART_Rx_ptr_out += UART_Rx_length;
//        UART_Rx_length = 0;
//      }
//      
//      UserToPMABufferCopy(&UART_Rx_Buffer[USB_Tx_ptr], ENDP1, USB_Tx_length);        
//    }
//  }
}

/*******************************************************************************
* Function Name  : Handle_USBAsynchXfer.
* Description    : send data to USB.
* Input          : None.
* Return         : none.
*******************************************************************************/
void Handle_USBAsynchXfer (void)
{
    if(USB_Tx_State != 1){
        if (UART_Rx_ptr_out == UART_RX_DATA_SIZE){
            UART_Rx_ptr_out = 0;
        }
        
        if(UART_Rx_ptr_out == UART_Rx_ptr_in) 
        {
            USB_Tx_State = 0; 
            return;
        }
        
        if(UART_Rx_ptr_out > UART_Rx_ptr_in) {/* rollback */
            UART_Rx_length = UART_RX_DATA_SIZE - UART_Rx_ptr_out;
        }
        else {
            UART_Rx_length = UART_Rx_ptr_in - UART_Rx_ptr_out;
        }
        
        if (UART_Rx_length > VIRTUAL_COM_PORT_DATA_SIZE){
            USB_Tx_ptr = UART_Rx_ptr_out;
            USB_Tx_length = VIRTUAL_COM_PORT_DATA_SIZE;
            
            UART_Rx_ptr_out += VIRTUAL_COM_PORT_DATA_SIZE;	
            UART_Rx_length -= VIRTUAL_COM_PORT_DATA_SIZE;	
        }
        else{
            USB_Tx_ptr = UART_Rx_ptr_out;
            USB_Tx_length = UART_Rx_length;
            
            UART_Rx_ptr_out += UART_Rx_length;
            UART_Rx_length = 0;
        }
        USB_Tx_State = 1; 
        
        UserToPMABufferCopy(&UART_Rx_Buffer[USB_Tx_ptr], ENDP1, USB_Tx_length);        
    }
}

/*******************************************************************************
* Function Name  : UART_To_USB_Send_Data.
* Description    : send the received data from UART 0 to USB.
* Input          : None.
* Return         : none.
*******************************************************************************/
void UART_To_USB_Send_Data(void)
{
    if (linecoding.datatype == 7){
        UART_Rx_Buffer[UART_Rx_ptr_in] = UART_ReceiveData(UART1) & 0x7F;
    }
    else if (linecoding.datatype == 8){
        UART_Rx_Buffer[UART_Rx_ptr_in] = UART_ReceiveData(UART1);
    }
    
    UART_Rx_ptr_in++;

    if(UART_Rx_ptr_in == UART_RX_DATA_SIZE){
        UART_Rx_ptr_in = 0;
    }
}






