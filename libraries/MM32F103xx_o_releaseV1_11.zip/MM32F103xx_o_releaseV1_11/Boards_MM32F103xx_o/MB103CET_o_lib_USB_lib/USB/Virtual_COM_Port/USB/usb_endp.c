/******************** (C) COPYRIGHT 2018 MindMotion ********************
* File Name          : usb_endp.c
* Version            : V1.0.0
* Date               : 2018/08/21
* Description        : Endpoint routines
********************************************************************************
* THE PRESENT FIRMWARE WHICH IS FOR GUIDANCE ONLY AIMS AT PROVIDING CUSTOMERS
* WITH CODING INFORMATION REGARDING THEIR PRODUCTS IN ORDER FOR THEM TO SAVE TIME.
* AS A RESULT, MindMotion SHALL NOT BE HELD LIABLE FOR ANY DIRECT,
* INDIRECT OR CONSEQUENTIAL DAMAGES WITH RESPECT TO ANY CLAIMS ARISING FROM THE
* CONTENT OF SUCH FIRMWARE AND/OR THE USE MADE BY CUSTOMERS OF THE CODING
* INFORMATION CONTAINED HEREIN IN CONNECTION WITH THEIR PRODUCTS.
*******************************************************************************/

/* Includes ------------------------------------------------------------------*/
#include "usb_lib.h"
#include "usb_desc.h"
#include "usb_mem.h"
#include "hw_config.h"
#include "usb_istr.h"
#include "usb_pwr.h"
#include "hw_config.h"
/* Private typedef -----------------------------------------------------------*/
/* Private define ------------------------------------------------------------*/

/* Interval between sending IN packets in frame number (1 frame = 1ms) */
#define VCOMPORT_IN_FRAME_INTERVAL             3

/* Private macro -------------------------------------------------------------*/
/* Private variables ---------------------------------------------------------*/

uint8_t USB_Rx_Buffer[VIRTUAL_COM_PORT_DATA_SIZE];


uint8_t buffer_out[VIRTUAL_COM_PORT_DATA_SIZE];
uint8_t buffer_in[VIRTUAL_COM_PORT_DATA_SIZE];

uint8_t status_UsbUart = 0;
uint8_t len_UsbToUart = 0;
uint8_t len_UartToUsb = 0;
__IO uint32_t count_out = 0;
uint32_t count_in = 0;
u8 empty_flag = 0;
extern u8 rxUsbBufOdd[16] ;
extern USB_OTG_BDT_TypeDef *pUSB_OTG_BDT;
/* Private function prototypes -----------------------------------------------*/
/* Private functions ---------------------------------------------------------*/
/*******************************************************************************
* Function Name  : EP3_IN_Callback
* Description    :
* Input          : None.
* Output         : None.
* Return         : None.
*******************************************************************************/
void EP3_OUT_Callback(void)
{
    uint8_t USB_Rx_Cnt;
    
    USB_Rx_Cnt = (pUSB_OTG_BDT + ENDP3)->RX_BUF[rxUsbBufOdd[ENDP3]].FORMAT >> 16;
    USB_Rx_Cnt &= 0x1FF;
//    PMAToUserBufferCopy(USB_Rx_Buffer, ENDP3, count_out);
    PMAToUserBuffer(USB_Rx_Buffer, ENDP3, USB_Rx_Cnt);
    USB_To_UART_Send_Data(USB_Rx_Buffer, USB_Rx_Cnt);
    
    (pUSB_OTG_BDT + ENDP3)->RX_BUF[rxUsbBufOdd[ENDP3]].FORMAT |= 1 << 7;
    
    
//    status_UsbUart |= 0x1<<1;
    //USB数据接收
}

/*******************************************************************************
* Function Name  : EP1_IN_Callback
* Description    :
* Input          : None.
* Output         : None.
* Return         : None.
*******************************************************************************/
void EP1_IN_Callback(void)
{
    VCP_Data_InISR();
}





/*******************************************************************************
* Function Name  : SOF_Callback / INTR_SOFINTR_Callback
* Description    :
* Input          : None.
* Output         : None.
* Return         : None.
*******************************************************************************/
void SOF_Callback(void)
{
    static uint32_t FrameCount = 0;
    
    if(bDeviceState == CONFIGURED){
        if (FrameCount++ == VCOMPORT_IN_FRAME_INTERVAL){
            /* Reset the frame counter */
            FrameCount = 0;
            
            /* Check the data to be sent through IN pipe */
            Handle_USBAsynchXfer();
        }
    }
}

/******************* (C) COPYRIGHT 2018 MindMotion *****END OF FILE****/

