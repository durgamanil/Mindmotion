#include "usb_lib.h"


extern USB_OTG_BDT_TypeDef *pUSB_OTG_BDT;
//extern u8 txUsbBufOdd ;

uint32_t USB_SIL_Init(void)
{
    /* USB interrupts initialization */
    /* clear pending interrupts */
    USB_OTG_FS->INT_STAT = USB_OTG_FS->INT_STAT;
    
    
    SetBDTAddress(PMAAddr);
    
    USB_OTG_FS->ADDR = 0;
    USB_OTG_FS->CTL |= OTG_FS_CTL_ODD_RST; 
    USB_OTG_FS->CTL &= ~OTG_FS_CTL_ODD_RST; //reset BDT ping/pang bits
    
    pUSB_OTG_BDT = (USB_OTG_BDT_TypeDef*)GetBDTAddress();
    
    EndPointBDInit( pUSB_OTG_BDT + 0, EP0BufferAddress);  //EP0 BDT
    EndPointBDInit( pUSB_OTG_BDT + 1, EP1BufferAddress);  //EP1 BDT
    EndPointBDInit( pUSB_OTG_BDT + 2, EP2BufferAddress);  //EP2 BDT
    EndPointBDInit( pUSB_OTG_BDT + 3, EP3BufferAddress);  //EP3 BDT
    
//    USB_OTG_FS->INT_ENB = USB_INT_STAT_RST | USB_INT_STAT_TOK_DNE;
    USB_OTG_FS->INT_ENB = OTG_FS_INT_ENB_USB_RST_EN | OTG_FS_INT_ENB_TOK_DNE_EN;
    
    return 0;
}