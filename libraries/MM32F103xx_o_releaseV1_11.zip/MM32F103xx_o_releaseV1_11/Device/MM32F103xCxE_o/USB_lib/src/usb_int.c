/******************** (C) COPYRIGHT 2018 MindMotion ********************
* File Name          : usb_int.c
* Version            : V1.0.0
* Date               : 2018/08/21
* Description        : Endpoint CTR (Low and High) interrupt's service routines
********************************************************************************
* THE PRESENT FIRMWARE WHICH IS FOR GUIDANCE ONLY AIMS AT PROVIDING CUSTOMERS
* WITH CODING INFORMATION REGARDING THEIR PRODUCTS IN ORDER FOR THEM TO SAVE TIME.
* AS A RESULT, MindMotion SHALL NOT BE HELD LIABLE FOR ANY DIRECT,
* INDIRECT OR CONSEQUENTIAL DAMAGES WITH RESPECT TO ANY CLAIMS ARISING FROM THE
* CONTENT OF SUCH FIRMWARE AND/OR THE USE MADE BY CUSTOMERS OF THE CODING
* INFORMATION CONTAINED HEREIN IN CONNECTION WITH THEIR PRODUCTS.
*******************************************************************************/

/* Includes ------------------------------------------------------------------*/
#include "usb_lib.h"

/* Private typedef -----------------------------------------------------------*/
/* Private define ------------------------------------------------------------*/
/* Private macro -------------------------------------------------------------*/
/* Private variables ---------------------------------------------------------*/


/* Extern variables ----------------------------------------------------------*/
extern void (*pEpInt_IN[7])(void);    /*  Handles IN  interrupts   */
extern void (*pEpInt_OUT[7])(void);   /*  Handles OUT interrupts   */
extern USB_OTG_BDT_TypeDef *pUSB_OTG_BDT;
/* Private function prototypes -----------------------------------------------*/
USB_OTG_BDT_TypeDef *pUSB_OTG_BDT;

extern u8 rxUsbBufOdd[16] ;
//u8 txUsbBufOdd[16] ;

u8 epInDataNum[16] ;

u8 setupPacket[8] ;
/* Private functions ---------------------------------------------------------*/

/*******************************************************************************
* Function Name  : CTR_LP.
* Description    : Low priority Endpoint Correct Transfer interrupt's service
*                  routine.
* Input          : None.
* Output         : None.
* Return         : None.
*******************************************************************************/
void CTR_LP(void)
{
//    GPIOA->ODR ^= GPIO_Pin_8;
    uint32_t wEp = 0,wEpBDFormat = 0;
    uint32_t wEpTx = 0, wEpOdd = 0;
    uint32_t wEpTokPid = 0;
    uint32_t wEpStat = 0;
    
    wEpStat = USB_OTG_FS->STAT;
    _ClrUSB_INT_STA(OTG_FS_INT_STAT_TOK_DNE);
    wEp = (wEpStat >> 4) & 0x0f;           //��ȡ�ж϶˵��
    wEpTx = (wEpStat >> 3) & 0x01;
    wEpOdd = (wEpStat >> 2) & 0x01;
    
    EPindex = wEp;
    
    if(wEpTx == 0){ //RX
        rxUsbBufOdd[wEp] = wEpOdd;
        pInformation->pOTG_BD = &pUSB_OTG_BDT[wEp].RX_BUF[wEpOdd];
        wEpBDFormat = pUSB_OTG_BDT[wEp].RX_BUF[wEpOdd].FORMAT;
    }
    else{
        pInformation->pOTG_BD = &pUSB_OTG_BDT[wEp].TX_BUF[wEpOdd];
        wEpBDFormat = pUSB_OTG_BDT[wEp].TX_BUF[wEpOdd].FORMAT;
        pUSB_OTG_BDT[wEp].TX_BUF[wEpOdd].FORMAT = 0;
    }
    wEpTokPid = (wEpBDFormat >> 2) & 0xf; //TOKEN PID
    pInformation->BDByteCount = (wEpBDFormat & OTG_FS_BD_BC) >> OTG_FS_BD_BC_Pos;
    pInformation->BDOwn = (wEpBDFormat & OTG_FS_BD_OWN) >> OTG_FS_BD_OWN_Pos;
    pInformation->BDData01 = (wEpBDFormat & OTG_FS_BD_DATA01) >> OTG_FS_BD_DATA01_Pos;
    
    
    if(wEp == 0){       //EP0
        if(wEpTokPid == 0x0D){//setup token
            USB_OTG_FS->CTL &= ~OTG_FS_CTL_TXDSUSPEND_TOKENBUSY;//tip
            epInDataNum[0] = 1;
            Setup0_Process();
            return;
        }
        
        if(wEpTokPid == 0x01){//out token
            Out0_Process();
            return;
        }
        
        if(wEpTokPid == 0x9){//in token
            In0_Process();
            return;
        }
    }/* if(EPindex == 0) */
    else if(wEp != 0){
        if(wEpTokPid == 0x01) {//out token
            (*pEpInt_OUT[EPindex-1])(); 
        }
        if(wEpTokPid == 0x9) {//in token
            (*pEpInt_IN[EPindex-1])();
        }
    }/* if(EPindex != 0)*/    
}

/*******************************************************************************
* Function Name  : CTR_HP.
* Description    : High Priority Endpoint Correct Transfer interrupt's service 
*                  routine.
* Input          : None.
* Output         : None.
* Return         : None.
*******************************************************************************/
void CTR_HP(void)
{

}

/******************* (C) COPYRIGHT 2018 MindMotion *****END OF FILE****/
