/******************** (C) COPYRIGHT 2018 MindMotion ********************
* File Name          : usb_regs.h
* Version            : V1.0.0
* Date               : 2018/08/21
* Description        : Interface prototype functions to USB cell registers
********************************************************************************
* THE PRESENT FIRMWARE WHICH IS FOR GUIDANCE ONLY AIMS AT PROVIDING CUSTOMERS
* WITH CODING INFORMATION REGARDING THEIR PRODUCTS IN ORDER FOR THEM TO SAVE TIME.
* AS A RESULT, MindMotion SHALL NOT BE HELD LIABLE FOR ANY DIRECT,
* INDIRECT OR CONSEQUENTIAL DAMAGES WITH RESPECT TO ANY CLAIMS ARISING FROM THE
* CONTENT OF SUCH FIRMWARE AND/OR THE USE MADE BY CUSTOMERS OF THE CODING
* INFORMATION CONTAINED HEREIN IN CONNECTION WITH THEIR PRODUCTS.
*******************************************************************************/

/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef __USB_REGS_H
#define __USB_REGS_H


/* Exported constants --------------------------------------------------------*/
#define PMAAddr  (0x20007000L)  /* BDT base address   */
#define BDSize   (0x200)
#define EP0BufferAddress (PMAAddr + BDSize + 0x100 * 0)
#define EP1BufferAddress (PMAAddr + BDSize + 0x100 * 1)
#define EP2BufferAddress (PMAAddr + BDSize + 0x100 * 2)
#define EP3BufferAddress (PMAAddr + BDSize + 0x100 * 3)



/* endpoints enumeration */
#define ENDP0   ((uint8_t)0)
#define ENDP1   ((uint8_t)1)
#define ENDP2   ((uint8_t)2)
#define ENDP3   ((uint8_t)3)
#define ENDP4   ((uint8_t)4)

/* Exported macro ------------------------------------------------------------*/


#define _SetUSB_Connect  	            USB_OTG_FS->OTG_CTRL |= 0x80
#define _SetUSB_Disconnect  	        USB_OTG_FS->OTG_CTRL &= ~0x80
/* SetUSB_ISTR */
#define _ClrUSB_INT_STA(wRegValue)  	USB_OTG_FS->INT_STAT = wRegValue
/* GetUSB_ISTR */
#define _GetUSB_INT_STA()  	           USB_OTG_FS->INT_STAT

#define _ClrUSB_EPn_HALT(n)  	    USB_OTG_FS->EP_CTL[n] &= ~(1<<1);
#define _GetUSB_EPn_HALT(n)  	    ((USB_OTG_FS->EP_CTL[n]>>1) & 0x01)

/* GetEP_INT_STA */
#define _GetEP_STA()  	            (USB_OTG_FS->STAT)//(USB->rEP_INT_STATE)
//#define _GetEP_INT_STA()  	            (USB_OTG_FS->STAT)//(USB->rEP_INT_STATE)

/* Set_EP_EN */
#define _SetUSB_ADDR(wRegValue)	        USB_OTG_FS->ADDR = wRegValue //(USB->rADDR = (uint16_t)wRegValue)

 
////////////////////////////////////////////////////////////////////////////////
/// @brief OTG_FS_PER_ID Register Bit Definition
////////////////////////////////////////////////////////////////////////////////
#define OTG_FS_PER_ID_ID_Pos                    (0)
#define OTG_FS_PER_ID_ID                        (0x3FU << OTG_FS_PER_ID_ID_Pos)

////////////////////////////////////////////////////////////////////////////////
/// @brief OTG_FS_ID_COMP Register Bit Definition
////////////////////////////////////////////////////////////////////////////////
#define OTG_FS_ID_COMP_NID_Pos                  (0)
#define OTG_FS_ID_COMP_NID                      (0x3FU << OTG_FS_ID_COMP_NID_Pos)

////////////////////////////////////////////////////////////////////////////////
/// @brief OTG_FS_REV Register Bit Definition
////////////////////////////////////////////////////////////////////////////////
#define OTG_FS_REV_REV_Pos                      (0)
#define OTG_FS_REV_REV                          (0xFFU << OTG_FS_REV_REV_Pos)

////////////////////////////////////////////////////////////////////////////////
/// @brief OTG_FS_ADD_INFO Register Bit Definition
////////////////////////////////////////////////////////////////////////////////
#define OTG_FS_ADD_INFO_HOST_Pos                (0)
#define OTG_FS_ADD_INFO_HOST                    (0x01U << OTG_FS_ADD_INFO_HOST_Pos)
#define OTG_FS_ADD_INFO_IRQ_NUM_Pos             (3)
#define OTG_FS_ADD_INFO_IRQ_NUM                 (0x1FU << OTG_FS_ADD_INFO_IRQ_NUM_Pos)

////////////////////////////////////////////////////////////////////////////////
/// @brief OTG_FS_OTG_ISTAT Register Bit Definition
////////////////////////////////////////////////////////////////////////////////
#define OTG_FS_OTG_ISTAT_A_VBUS_VLD_CHG_Pos     (0)
#define OTG_FS_OTG_ISTAT_A_VBUS_VLD_CHG         (0x01U << OTG_FS_OTG_ISTAT_A_VBUS_VLD_CHG_Pos)
#define OTG_FS_OTG_ISTAT_B_SESS_END_CHG_Pos     (2)
#define OTG_FS_OTG_ISTAT_B_SESS_END_CHG         (0x01U << OTG_FS_OTG_ISTAT_B_SESS_END_CHG_Pos)
#define OTG_FS_OTG_ISTAT_SESS_VLD_CHG_Pos       (3)
#define OTG_FS_OTG_ISTAT_SESS_VLD_CHG           (0x01U << OTG_FS_OTG_ISTAT_SESS_VLD_CHG_Pos)
#define OTG_FS_OTG_ISTAT_LINE_STATE_CHG_Pos     (5)
#define OTG_FS_OTG_ISTAT_LINE_STATE_CHG         (0x01U << OTG_FS_OTG_ISTAT_LINE_STATE_CHG_Pos)
#define OTG_FS_OTG_ISTAT_1_MSEC_Pos             (6)
#define OTG_FS_OTG_ISTAT_1_MSEC                 (0x01U << OTG_FS_OTG_ISTAT_1_MSEC_Pos)
#define OTG_FS_OTG_ISTAT_ID_CHG_Pos             (7)
#define OTG_FS_OTG_ISTAT_ID_CHG                 (0x01U << OTG_FS_OTG_ISTAT_ID_CHG_Pos)

////////////////////////////////////////////////////////////////////////////////
/// @brief OTG_FS_OTG_ICTRL Register Bit Definition
////////////////////////////////////////////////////////////////////////////////
#define OTG_FS_OTG_ICTRL_A_VBUS_VLD_EN_Pos      (0)
#define OTG_FS_OTG_ICTRL_A_VBUS_VLD_EN          (0x01U << OTG_FS_OTG_ICTRL_A_VBUS_VLD_EN_Pos)
#define OTG_FS_OTG_ICTRL_B_SESS_END_EN_Pos      (2)
#define OTG_FS_OTG_ICTRL_B_SESS_END_EN          (0x01U << OTG_FS_OTG_ICTRL_B_SESS_END_EN_Pos)
#define OTG_FS_OTG_ICTRL_SESS_VLD_EN_Pos        (3)
#define OTG_FS_OTG_ICTRL_SESS_VLD_EN            (0x01U << OTG_FS_OTG_ICTRL_SESS_VLD_EN_Pos)
#define OTG_FS_OTG_ICTRL_LINE_STATE_EN_Pos      (5)
#define OTG_FS_OTG_ICTRL_LINE_STATE_EN          (0x01U << OTG_FS_OTG_ICTRL_LINE_STATE_EN_Pos)
#define OTG_FS_OTG_ICTRL_1_MSEC_EN_Pos          (6)
#define OTG_FS_OTG_ICTRL_1_MSEC_EN              (0x01U << OTG_FS_OTG_ICTRL_1_MSEC_EN_Pos)
#define OTG_FS_OTG_ICTRL_ID_EN_Pos              (7)
#define OTG_FS_OTG_ICTRL_ID_EN                  (0x01U << OTG_FS_OTG_ICTRL_ID_EN_Pos)

////////////////////////////////////////////////////////////////////////////////
/// @brief OTG_FS_OTG_STAT Register Bit Definition
////////////////////////////////////////////////////////////////////////////////
#define OTG_FS_OTG_STAT_A_VBUS_VLD_Pos          (0)
#define OTG_FS_OTG_STAT_A_VBUS_VLD              (0x01U << OTG_FS_OTG_STAT_A_VBUS_VLD_Pos)
#define OTG_FS_OTG_STAT_B_SESS_END_Pos          (2)
#define OTG_FS_OTG_STAT_B_SESS_END              (0x01U << OTG_FS_OTG_STAT_B_SESS_END_Pos)
#define OTG_FS_OTG_STAT_SESS_VLD_Pos            (3)
#define OTG_FS_OTG_STAT_SESS_VLD                (0x01U << OTG_FS_OTG_STAT_SESS_VLD_Pos)
#define OTG_FS_OTG_STAT_LINE_STATE_STABLE_Pos   (5)
#define OTG_FS_OTG_STAT_LINE_STATE_STABLE       (0x01U << OTG_FS_OTG_STAT_LINE_STATE_STABLE_Pos)
#define OTG_FS_OTG_STAT_1_MSEC_Pos              (6)
#define OTG_FS_OTG_STAT_1_MSEC                  (0x01U << OTG_FS_OTG_STAT_1_MSEC_Pos)
#define OTG_FS_OTG_STAT_ID_Pos                  (7)
#define OTG_FS_OTG_STAT_ID                      (0x01U << OTG_FS_OTG_STAT_ID_Pos)

////////////////////////////////////////////////////////////////////////////////
/// @brief OTG_FS_OTG_CTRL Register Bit Definition
////////////////////////////////////////////////////////////////////////////////
#define OTG_FS_OTG_CTRL_VBUS_DSCHG_Pos          (0)
#define OTG_FS_OTG_CTRL_VBUS_DSCHG              (0x01U << OTG_FS_OTG_CTRL_VBUS_DSCHG_Pos)
#define OTG_FS_OTG_CTRL_VBUS_CHG_Pos            (1)
#define OTG_FS_OTG_CTRL_VBUS_CHG                (0x01U << OTG_FS_OTG_CTRL_VBUS_CHG_Pos)
#define OTG_FS_OTG_CTRL_OTG_EN_Pos              (2)
#define OTG_FS_OTG_CTRL_OTG_EN                  (0x01U << OTG_FS_OTG_CTRL_OTG_EN_Pos)
#define OTG_FS_OTG_CTRL_VBUS_ON_Pos             (3)
#define OTG_FS_OTG_CTRL_VBUS_ON                 (0x01U << OTG_FS_OTG_CTRL_VBUS_ON_Pos)
#define OTG_FS_OTG_CTRL_DM_LOW_Pos              (4)
#define OTG_FS_OTG_CTRL_DM_LOW                  (0x01U << OTG_FS_OTG_CTRL_DM_LOW_Pos)
#define OTG_FS_OTG_CTRL_DP_LOW_Pos              (5)
#define OTG_FS_OTG_CTRL_DP_LOW                  (0x01U << OTG_FS_OTG_CTRL_DP_LOW_Pos)
#define OTG_FS_OTG_CTRL_DM_HIGH_Pos             (6)
#define OTG_FS_OTG_CTRL_DM_HIGH                 (0x01U << OTG_FS_OTG_CTRL_DM_HIGH_Pos)
#define OTG_FS_OTG_CTRL_DP_HIGH_Pos             (7)
#define OTG_FS_OTG_CTRL_DP_HIGH                 (0x01U << OTG_FS_OTG_CTRL_DP_HIGH_Pos)

////////////////////////////////////////////////////////////////////////////////
/// @brief OTG_FS_INT_STAT Register Bit Definition
////////////////////////////////////////////////////////////////////////////////
#define OTG_FS_INT_STAT_USB_RST_Pos             (0)
#define OTG_FS_INT_STAT_USB_RST                 (0x01U << OTG_FS_INT_STAT_USB_RST_Pos)
#define OTG_FS_INT_STAT_ERROR_Pos               (1)
#define OTG_FS_INT_STAT_ERROR                   (0x01U << OTG_FS_INT_STAT_ERROR_Pos)
#define OTG_FS_INT_STAT_SOF_TOK_Pos             (2)
#define OTG_FS_INT_STAT_SOF_TOK                 (0x01U << OTG_FS_INT_STAT_SOF_TOK_Pos)
#define OTG_FS_INT_STAT_TOK_DNE_Pos             (3)
#define OTG_FS_INT_STAT_TOK_DNE                 (0x01U << OTG_FS_INT_STAT_TOK_DNE_Pos)
#define OTG_FS_INT_STAT_SLEEP_Pos               (4)
#define OTG_FS_INT_STAT_SLEEP                   (0x01U << OTG_FS_INT_STAT_SLEEP_Pos)
#define OTG_FS_INT_STAT_RESUME_Pos              (5)
#define OTG_FS_INT_STAT_RESUME                  (0x01U << OTG_FS_INT_STAT_RESUME_Pos)
#define OTG_FS_INT_STAT_ATTACH_Pos              (6)
#define OTG_FS_INT_STAT_ATTACH                  (0x01U << OTG_FS_INT_STAT_ATTACH_Pos)
#define OTG_FS_INT_STAT_STALL_Pos               (7)
#define OTG_FS_INT_STAT_STALL                   (0x01U << OTG_FS_INT_STAT_STALL_Pos)

////////////////////////////////////////////////////////////////////////////////
/// @brief OTG_FS_INT_ENB Register Bit Definition
////////////////////////////////////////////////////////////////////////////////
#define OTG_FS_INT_ENB_USB_RST_EN_Pos           (0)
#define OTG_FS_INT_ENB_USB_RST_EN               (0x01U << OTG_FS_INT_ENB_USB_RST_EN_Pos)
#define OTG_FS_INT_ENB_ERROR_EN_Pos             (1)
#define OTG_FS_INT_ENB_ERROR_EN                 (0x01U << OTG_FS_INT_ENB_ERROR_EN_Pos)
#define OTG_FS_INT_ENB_SOF_TOK_EN_Pos           (2)
#define OTG_FS_INT_ENB_SOF_TOK_EN               (0x01U << OTG_FS_INT_ENB_SOF_TOK_EN_Pos)
#define OTG_FS_INT_ENB_TOK_DNE_EN_Pos           (3)
#define OTG_FS_INT_ENB_TOK_DNE_EN               (0x01U << OTG_FS_INT_ENB_TOK_DNE_EN_Pos)
#define OTG_FS_INT_ENB_SLEEP_EN_Pos             (4)
#define OTG_FS_INT_ENB_SLEEP_EN                 (0x01U << OTG_FS_INT_ENB_SLEEP_EN_Pos)
#define OTG_FS_INT_ENB_RESUME_EN_Pos            (5)
#define OTG_FS_INT_ENB_RESUME_EN                (0x01U << OTG_FS_INT_ENB_RESUME_EN_Pos)
#define OTG_FS_INT_ENB_ATTACH_EN_Pos            (6)
#define OTG_FS_INT_ENB_ATTACH_EN                (0x01U << OTG_FS_INT_ENB_ATTACH_EN_Pos)
#define OTG_FS_INT_ENB_STALL_EN_Pos             (7)
#define OTG_FS_INT_ENB_STALL_EN                 (0x01U << OTG_FS_INT_ENB_STALL_EN_Pos)

////////////////////////////////////////////////////////////////////////////////
/// @brief OTG_FS_ERR_STAT Register Bit Definition
////////////////////////////////////////////////////////////////////////////////
#define OTG_FS_ERR_STAT_PID_ERR_Pos             (0)
#define OTG_FS_ERR_STAT_PID_ERR                 (0x01U << OTG_FS_ERR_STAT_PID_ERR_Pos)
#define OTG_FS_ERR_STAT_CRC5_EOF_Pos            (1)
#define OTG_FS_ERR_STAT_CRC5_EOF                (0x01U << OTG_FS_ERR_STAT_CRC5_EOF_Pos)
#define OTG_FS_ERR_STAT_CRC16_Pos               (2)
#define OTG_FS_ERR_STAT_CRC16                   (0x01U << OTG_FS_ERR_STAT_CRC16_Pos)
#define OTG_FS_ERR_STAT_DFN8_Pos                (3)
#define OTG_FS_ERR_STAT_DFN8                    (0x01U << OTG_FS_ERR_STAT_DFN8_Pos)
#define OTG_FS_ERR_STAT_BTO_ERR_Pos             (4)
#define OTG_FS_ERR_STAT_BTO_ERR                 (0x01U << OTG_FS_ERR_STAT_BTO_ERR_Pos)
#define OTG_FS_ERR_STAT_DMA_ERR_Pos             (5)
#define OTG_FS_ERR_STAT_DMA_ERR                 (0x01U << OTG_FS_ERR_STAT_DMA_ERR_Pos)
#define OTG_FS_ERR_STAT_BTS_ERR_Pos             (7)
#define OTG_FS_ERR_STAT_BTS_ERR                 (0x01U << OTG_FS_ERR_STAT_BTS_ERR_Pos)

////////////////////////////////////////////////////////////////////////////////
/// @brief OTG_FS_ERR_ENB Register Bit Definition
////////////////////////////////////////////////////////////////////////////////
#define OTG_FS_ERR_ENB_PID_ERR_EN_Pos           (0)
#define OTG_FS_ERR_ENB_PID_ERR_EN               (0x01U << OTG_FS_ERR_ENB_PID_ERR_EN_Pos)
#define OTG_FS_ERR_ENB_CRC5_EOF_EN_Pos          (1)
#define OTG_FS_ERR_ENB_CRC5_EOF_EN              (0x01U << OTG_FS_ERR_ENB_CRC5_EOF_EN_Pos)
#define OTG_FS_ERR_ENB_CRC16_EN_Pos             (2)
#define OTG_FS_ERR_ENB_CRC16_EN                 (0x01U << OTG_FS_ERR_ENB_CRC16_EN_Pos)
#define OTG_FS_ERR_ENB_DFN8_EN_Pos              (3)
#define OTG_FS_ERR_ENB_DFN8_EN                  (0x01U << OTG_FS_ERR_ENB_DFN8_EN_Pos)
#define OTG_FS_ERR_ENB_BTO_ERR_EN_Pos           (4)
#define OTG_FS_ERR_ENB_BTO_ERR_EN               (0x01U << OTG_FS_ERR_ENB_BTO_ERR_EN_Pos)
#define OTG_FS_ERR_ENB_DMA_ERR_EN_Pos           (5)
#define OTG_FS_ERR_ENB_DMA_ERR_EN               (0x01U << OTG_FS_ERR_ENB_DMA_ERR_EN_Pos)
#define OTG_FS_ERR_ENB_BTS_ERR_EN_Pos           (7)
#define OTG_FS_ERR_ENB_BTS_ERR_EN               (0x01U << OTG_FS_ERR_ENB_BTS_ERR_EN_Pos)


////////////////////////////////////////////////////////////////////////////////
/// @brief OTG_FS_STAT Register Bit Definition
////////////////////////////////////////////////////////////////////////////////
#define OTG_FS_STAT_ODD_Pos                     (2)
#define OTG_FS_STAT_ODD                         (0x01U << OTG_FS_STAT_ODD_Pos)
#define OTG_FS_STAT_TX_Pos                      (3)
#define OTG_FS_STAT_TX                          (0x01U << OTG_FS_STAT_TX_Pos)
#define OTG_FS_STAT_ENDP_Pos                    (4)
#define OTG_FS_STAT_ENDP                        (0x0FU << OTG_FS_STAT_ENDP_Pos)

////////////////////////////////////////////////////////////////////////////////
/// @brief OTG_FS_CTL Register Bit Definition
////////////////////////////////////////////////////////////////////////////////
#define OTG_FS_CTL_USB_EN_SOF_EN_Pos            (0)
#define OTG_FS_CTL_USB_EN_SOF_EN                (0x01U << OTG_FS_CTL_USB_EN_SOF_EN_Pos)
#define OTG_FS_CTL_ODD_RST_Pos                  (1)
#define OTG_FS_CTL_ODD_RST                      (0x01U << OTG_FS_CTL_ODD_RST_Pos)
#define OTG_FS_CTL_RESUME_Pos                   (2)
#define OTG_FS_CTL_RESUME                       (0x01U << OTG_FS_CTL_RESUME_Pos)
#define OTG_FS_CTL_HOST_MODE_EN_Pos             (3)
#define OTG_FS_CTL_HOST_MODE_EN                 (0x01U << OTG_FS_CTL_HOST_MODE_EN_Pos)
#define OTG_FS_CTL_RESET_Pos                    (4)
#define OTG_FS_CTL_RESET                        (0x01U << OTG_FS_CTL_RESET_Pos)
#define OTG_FS_CTL_TXDSUSPEND_TOKENBUSY_Pos     (5)
#define OTG_FS_CTL_TXDSUSPEND_TOKENBUSY         (0x01U << OTG_FS_CTL_TXDSUSPEND_TOKENBUSY_Pos)
#define OTG_FS_CTL_SE0_Pos                      (6)
#define OTG_FS_CTL_SE0                          (0x01U << OTG_FS_CTL_SE0_Pos)
#define OTG_FS_CTL_JSTATE_Pos                   (7)
#define OTG_FS_CTL_JSTATE                       (0x01U << OTG_FS_CTL_JSTATE_Pos)

////////////////////////////////////////////////////////////////////////////////
/// @brief OTG_FS_ADDR Register Bit Definition
////////////////////////////////////////////////////////////////////////////////
#define OTG_FS_ADDR_ADDR_Pos                    (0)
#define OTG_FS_ADDR_ADDR                        (0x7FU << OTG_FS_ADDR_ADDR_Pos)
#define OTG_FS_ADDR_LS_EN_Pos                   (7)
#define OTG_FS_ADDR_LS_EN                       (0x01U << OTG_FS_ADDR_LS_EN_Pos)

////////////////////////////////////////////////////////////////////////////////
/// @brief OTG_FS_BDT_PAGE_01 Register Bit Definition
////////////////////////////////////////////////////////////////////////////////
#define OTG_FS_BDT_PAGE_01_BDT_BA_15_9_Pos      (1)
#define OTG_FS_BDT_PAGE_01_BDT_BA_15_9          (0x7FU << OTG_FS_BDT_PAGE_01_BDT_BA_15_9_Pos)

////////////////////////////////////////////////////////////////////////////////
/// @brief OTG_FS_FRM_NUML Register Bit Definition
////////////////////////////////////////////////////////////////////////////////
#define OTG_FS_FRM_NUML_FRM_Pos                 (0)
#define OTG_FS_FRM_NUML_FRM                     (0xFFU << OTG_FS_FRM_NUML_FRM_Pos)

////////////////////////////////////////////////////////////////////////////////
/// @brief OTG_FS_FRM_NUMH Register Bit Definition
////////////////////////////////////////////////////////////////////////////////
#define OTG_FS_FRM_NUMH_FRM_Pos                 (0)
#define OTG_FS_FRM_NUMH_FRM                     (0x07U << OTG_FS_FRM_NUMH_FRM_Pos)


////////////////////////////////////////////////////////////////////////////////
/// @brief OTG_FS_TOKEN Register Bit Definition
////////////////////////////////////////////////////////////////////////////////
#define OTG_FS_TOKEN_TOKEN_ENDPT_Pos            (0)
#define OTG_FS_TOKEN_TOKEN_ENDPT                (0x0FU << OTG_FS_TOKEN_TOKEN_ENDPT_Pos)
#define OTG_FS_TOKEN_TOKEN_PID_Pos              (4)
#define OTG_FS_TOKEN_TOKEN_PID                  (0x0FU << OTG_FS_TOKEN_TOKEN_PID_Pos)

////////////////////////////////////////////////////////////////////////////////
/// @brief OTG_FS_SOF_THLD Register Bit Definition
////////////////////////////////////////////////////////////////////////////////
#define OTG_FS_SOF_THLD_CNT_Pos                 (0)
#define OTG_FS_SOF_THLD_CNT                     (0xFFU << OTG_FS_SOF_THLD_CNT_Pos)

////////////////////////////////////////////////////////////////////////////////
/// @brief OTG_FS_BDT_PAGE_02 Register Bit Definition
////////////////////////////////////////////////////////////////////////////////
#define OTG_FS_BDT_PAGE_02_BDT_BA_23_16_Pos     (0)
#define OTG_FS_BDT_PAGE_02_BDT_BA_23_16         (0xFFU << OTG_FS_BDT_PAGE_02_BDT_BA_23_16_Pos)

////////////////////////////////////////////////////////////////////////////////
/// @brief OTG_FS_BDT_PAGE_03 Register Bit Definition
////////////////////////////////////////////////////////////////////////////////
#define OTG_FS_BDT_PAGE_03_BDT_BA_31_24_Pos     (0)
#define OTG_FS_BDT_PAGE_03_BDT_BA_31_24         (0xFFU << OTG_FS_BDT_PAGE_03_BDT_BA_31_24_Pos)

////////////////////////////////////////////////////////////////////////////////
/// @brief OTG_FS_EP_CTL Register Bit Definition
////////////////////////////////////////////////////////////////////////////////
#define OTG_FS_EP_CTL_EP_HSHK_Pos               (0)
#define OTG_FS_EP_CTL_EP_HSHK                   (0x01U << OTG_FS_EP_CTL_EP_HSHK_Pos)
#define OTG_FS_EP_CTL_EP_STALL_Pos              (1)
#define OTG_FS_EP_CTL_EP_STALL                  (0x01U << OTG_FS_EP_CTL_EP_STALL_Pos)
#define OTG_FS_EP_CTL_EP_TX_EN_Pos              (2)
#define OTG_FS_EP_CTL_EP_TX_EN                  (0x01U << OTG_FS_EP_CTL_EP_TX_EN_Pos)
#define OTG_FS_EP_CTL_EP_RX_EN_Pos              (3)
#define OTG_FS_EP_CTL_EP_RX_EN                  (0x01U << OTG_FS_EP_CTL_EP_RX_EN_Pos)
#define OTG_FS_EP_CTL_EP_CTL_DIS_Pos            (4)
#define OTG_FS_EP_CTL_EP_CTL_DIS                (0x01U << OTG_FS_EP_CTL_EP_CTL_DIS_Pos)
#define OTG_FS_EP_CTL_RETRY_DIS_Pos             (6)
#define OTG_FS_EP_CTL_RETRY_DIS                 (0x01U << OTG_FS_EP_CTL_RETRY_DIS_Pos)
#define OTG_FS_EP_CTL_HOST_WO_HUB_Pos           (7)
#define OTG_FS_EP_CTL_HOST_WO_HUB               (0x01U << OTG_FS_EP_CTL_HOST_WO_HUB_Pos)


////////////////////////////////////////////////////////////////////////////////
/// @brief OTG_FS Buffer Descriptor Bit Definition
////////////////////////////////////////////////////////////////////////////////

#define OTG_FS_BD_TOK_PID_Pos                   (2)
#define OTG_FS_BD_TOK_PID                       (0x0FU << OTG_FS_BD_TOK_PID_Pos)
#define OTG_FS_BD_DATA01_Pos                    (6)
#define OTG_FS_BD_DATA01                        (0x01U << OTG_FS_BD_DATA01_Pos)
#define OTG_FS_BD_OWN_Pos                       (7)
#define OTG_FS_BD_OWN                           (0x01U << OTG_FS_BD_OWN_Pos)
#define OTG_FS_BD_BC_Pos                        (16)
#define OTG_FS_BD_BC                            (0x3FFU << OTG_FS_BD_BC_Pos)
#define OTG_FS_BD_ADDRESS_Pos                   (0)
#define OTG_FS_BD_ADDRESS                       (0xFFFFFFFFU << OTG_FS_BD_ADDRESS_Pos)















/* External variables --------------------------------------------------------*/
extern __IO uint16_t wIstr;  /* ISTR register last read value */

/* Exported functions ------------------------------------------------------- */
void EndPointBDInit( USB_OTG_BDT_TypeDef *pUSB_OTG_BDT,u32 dataBufAdd);
void SetBDTAddress(uint32_t wRegValue);
uint32_t GetBDTAddress(void);
void SetBDByteCount(BDT_DATA_TypeDef * pBD, uint16_t byteCount);
uint16_t GetBDByteCount(BDT_DATA_TypeDef * pBD);
#endif /* __USB_REGS_H */

/******************* (C) COPYRIGHT 2018 MindMotion *****END OF FILE****/
