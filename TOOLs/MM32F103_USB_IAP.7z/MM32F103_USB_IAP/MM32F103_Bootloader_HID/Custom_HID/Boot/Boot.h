#ifndef   __BOOT_H_
#define    __BOOT_H_

#include "platform_config.h"
#include "usb_desc.h"
#include "usb_conf.h"

#define APP_SIZE  120  //120K flash

uint16_t DFU_read_state(void);

void Clear_USB_Send_Buffer(void);
void Clear_USB_Receive_Buffer(void);
void APP_Update(void);

void Bootloader_Erase_APP(void);


#endif



/***************************end of file****************************************************/



