/**
  ******************************************************************************
  * @file    usbio.h
  * $Author: wenyang.du
  * $Revision: 
  * $Date:: 
  * @brief   USB�ϲ㺯������.
  ******************************************************************************
  * @attention
  *
  *
  *
  *
  * 
  ******************************************************************************
  */
/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef _USBIO_H_
#define _USBIO_H_




#include "MM32F103.h"
#include "usb_desc.h"

//#define REPORT_COUNT     0x40

/* Exported Functions --------------------------------------------------------*/
extern uint32_t USB_SendData(uint8_t *data,uint32_t dataNum);
extern uint32_t USB_GetData(uint8_t *data,uint32_t dataNum);

extern uint8_t USB_Receive_Buffer[REPORT_COUNT];
extern uint8_t USB_Send_Buffer[REPORT_COUNT];

#endif //_USBIO_H_



/*********************************END OF FILE**********************************/






